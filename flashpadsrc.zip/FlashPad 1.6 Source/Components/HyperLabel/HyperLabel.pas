
{**********************************************************}
{                                                          }
{  HyperLabel Component Version 1.22                       }
{                                                          }
{  Author: DayDream Software                               }
{  Email: haoxg@21cn.com                                   }
{  URL: http://www.haoxg.net                               }
{  Last Modified Date: 2007-06-12                          }
{                                                          }
{**********************************************************}

unit HyperLabel;

interface

uses
  Windows, Messages, SysUtils, Classes, Controls, StdCtrls, Graphics, Forms;

const
  crHand = 101;

type

{ Classes }

  TCustomHyperLabel = class;

{ THoverStyle }

  THoverStyle = class(TPersistent)
  private
    FHyperLabel: TCustomHyperLabel;
    FColor: TColor;
    FStyle: TFontStyles;
    procedure SetStyle(Value: TFontStyles);
  public
    constructor Create(AHyperLabel: TCustomHyperLabel); virtual;
    destructor Destroy; override;
  published
    property Color: TColor read FColor write FColor;
    property Style: TFontStyles read FStyle write SetStyle;
  end;

{ TCustomHyperLabel }

  TCustomHyperLabel = class(TGraphicControl)
  private
    FAlignment: TAlignment;
    FAutoSize: Boolean;
    FLayout: TTextLayout;
    FHoverStyle: THoverStyle;
    FSaveStyle: THoverStyle;
    FIsHover: Boolean;
    FURL: string;
    FOnMouseLeave: TNotifyEvent;
    FOnMouseEnter: TNotifyEvent;

    function GetTransparent: Boolean;
    function GetAllowDblClick: Boolean;
    procedure SetAlignment(Value: TAlignment);
    procedure SetLayout(Value: TTextLayout);
    procedure SetTransparent(Value: Boolean);
    procedure SetAllowDblClick(Value: Boolean);

    procedure SaveStyle;
    procedure RestoreStyle;
    function GetHoverFontColor: TColor;

    procedure CMTextChanged(var Message: TMessage); message CM_TEXTCHANGED;
    procedure CMFontChanged(var Message: TMessage); message CM_FONTCHANGED;
    procedure CMMouseEnter(var Message: TMessage); message CM_MOUSEENTER;
    procedure CMMouseLeave(var Message: TMessage); message CM_MOUSELEAVE;
  protected
    procedure AdjustBounds; dynamic;
    procedure DoDrawText(var Rect: TRect; Flags: Longint); dynamic;
    procedure DoDrawUnderline(X1, X2, Y: Integer);
    function GetLabelText: string; virtual;
    procedure Loaded; override;
    procedure Paint; override;
    procedure SetAutoSize(Value: Boolean); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    property Canvas;
    property AutoSize: Boolean read FAutoSize write SetAutoSize default True;
    property HoverStyle: THoverStyle read FHoverStyle write FHoverStyle;
    property Alignment: TAlignment read FAlignment write SetAlignment default taLeftJustify;
    property Layout: TTextLayout read FLayout write SetLayout default tlTop;
    property Transparent: Boolean read GetTransparent write SetTransparent default True;
    property AllowDblClick: Boolean read GetAllowDblClick write SetAllowDblClick default True;
    property URL: string read FURL write FURL;
    
    property OnMouseEnter: TNotifyEvent read FOnMouseEnter write FOnMouseEnter;
    property OnMouseLeave: TNotifyEvent read FOnMouseLeave write FOnMouseLeave;
  end;

{ THyperLabel }

  THyperLabel = class(TCustomHyperLabel)
  published
    property HoverStyle;
    property Cursor default crHand;
    property Action;
    property Caption;
    property Align;
    property Alignment;
    property Anchors;
    property AutoSize;
    property BiDiMode;
    property Color;
    property Constraints;
    property DragCursor;
    property DragKind;
    property DragMode;
    property Enabled;
    property Font;
    property ParentBiDiMode;
    property ParentColor;
    property ParentFont;
    property ParentShowHint;
    property PopupMenu;
    property ShowHint;
    property Transparent;
    property AllowDblClick;
    property Layout;
    property Visible;
    property OnClick;
    property OnContextPopup;
    property OnDblClick;
    property OnDragDrop;
    property OnDragOver;
    property OnEndDock;
    property OnEndDrag;
    property OnMouseDown;
    property OnMouseMove;
    property OnMouseUp;
    property OnMouseEnter;
    property OnMouseLeave;
    property OnStartDock;
    property OnStartDrag;
  end;

procedure Register;

implementation

{$R Cursors.res}

procedure Register;
begin
  RegisterComponents('IrisMisc', [THyperLabel]);
end;

{ THoverStyle }

constructor THoverStyle.Create(AHyperLabel: TCustomHyperLabel);
begin
  inherited Create;
  FHyperLabel := AHyperLabel;
  FColor := clBlue;
  FStyle := [fsUnderline];
end;

destructor THoverStyle.Destroy;
begin
  inherited;
end;

procedure THoverStyle.SetStyle(Value: TFontStyles);
begin
  if FStyle <> Value then
  begin
    FStyle := Value;
    FHyperLabel.AdjustBounds;
  end;
end;

{ TCustomHyperLabel }

constructor TCustomHyperLabel.Create(AOwner: TComponent);
begin
  inherited;
  ControlStyle := ControlStyle + [csReplicatable];
  ControlStyle := ControlStyle - [csOpaque];
  Width := 65;
  Height := 18;
  Cursor := crHand;
  FAutoSize := True;
  FHoverStyle := THoverStyle.Create(Self);
end;

destructor TCustomHyperLabel.Destroy;
begin
  FHoverStyle.Free;
  inherited;
end;

function TCustomHyperLabel.GetTransparent: Boolean;
begin
  Result := not (csOpaque in ControlStyle);
end;

function TCustomHyperLabel.GetAllowDblClick: Boolean;
begin
  Result := (csDoubleClicks in ControlStyle);
end;

procedure TCustomHyperLabel.SetAlignment(Value: TAlignment);
begin
  if FAlignment <> Value then
  begin
    FAlignment := Value;
    Invalidate;
  end;
end;

procedure TCustomHyperLabel.SetLayout(Value: TTextLayout);
begin
  if FLayout <> Value then
  begin
    FLayout := Value;
    Invalidate;
  end;
end;

procedure TCustomHyperLabel.SetTransparent(Value: Boolean);
begin
  if Transparent <> Value then
  begin
    if Value then
      ControlStyle := ControlStyle - [csOpaque] else
      ControlStyle := ControlStyle + [csOpaque];
    Invalidate;
  end;
end;

procedure TCustomHyperLabel.SetAllowDblClick(Value: Boolean);
begin
  if Value then
    ControlStyle := ControlStyle + [csDoubleClicks]
  else
    ControlStyle := ControlStyle - [csDoubleClicks];
end;

procedure TCustomHyperLabel.SaveStyle;
begin
  FSaveStyle.Free;
  FSaveStyle := THoverStyle.Create(Self);
  FSaveStyle.FColor := Font.Color;
  FSaveStyle.FStyle := Font.Style;
end;

procedure TCustomHyperLabel.RestoreStyle;
begin
  if FSaveStyle <> nil then
  begin
    Font.Color := FSaveStyle.Color;
    Font.Style := FSaveStyle.Style;
    FSaveStyle.Free;
    FSaveStyle := nil;
  end;
end;

function TCustomHyperLabel.GetHoverFontColor: TColor;
begin
  if FHoverStyle.Color = clNone then
    Result := Font.Color
  else
    Result := FHoverStyle.Color;
end;

procedure TCustomHyperLabel.CMTextChanged(var Message: TMessage);
begin
  inherited;
  Invalidate;
  AdjustBounds;
end;

procedure TCustomHyperLabel.CMFontChanged(var Message: TMessage);
begin
  inherited;
  AdjustBounds;
end;

procedure TCustomHyperLabel.CMMouseEnter(var Message: TMessage);
begin
  if not (csDesigning in ComponentState) then
  begin
    FIsHover := True;
    SaveStyle;
    Font.Color := GetHoverFontColor;
    Font.Style := FHoverStyle.Style - [fsUnderline];
    Invalidate;
    if Assigned(FOnMouseEnter) then
      FOnMouseEnter(Self);
  end;
end;

procedure TCustomHyperLabel.CMMouseLeave(var Message: TMessage);
begin
  if not (csDesigning in ComponentState) then
  begin
    FIsHover := False;
    RestoreStyle;
    Invalidate;
    if Assigned(FOnMouseLeave) then
      FOnMouseLeave(Self);
  end;
end;

procedure TCustomHyperLabel.AdjustBounds;
var
  DC: HDC;
  X: Integer;
  R: TRect;
  AAlignment: TAlignment;
begin
  if not (csReading in ComponentState) and FAutoSize then
  begin
    R := Rect(0, 0, Width, Height);
    DC := GetDC(0);
    Canvas.Handle := DC;
    DoDrawText(R, (DT_EXPANDTABS or DT_CALCRECT));
    Canvas.Handle := 0;
    ReleaseDC(0, DC);
    X := Left;
    AAlignment := FAlignment;
    if UseRightToLeftAlignment then ChangeBiDiModeAlignment(AAlignment);
    if AAlignment = taRightJustify then Inc(X, Width - R.Right);
    if fsUnderline in FHoverStyle.Style then Inc(R.Bottom);
    SetBounds(X, Top, R.Right, R.Bottom);
  end;
end;

procedure TCustomHyperLabel.DoDrawText(var Rect: TRect; Flags: Integer);
var
  Text: string;
begin
  Text := GetLabelText;
  if (Flags and DT_CALCRECT <> 0) and ((Text = '')) then Text := Text + ' ';
  Flags := Flags or DT_NOPREFIX;
  Flags := DrawTextBiDiModeFlags(Flags);
  Canvas.Font := Font;
  if not Enabled then
  begin
    OffsetRect(Rect, 1, 1);
    Canvas.Font.Color := clBtnHighlight;
    DrawText(Canvas.Handle, PChar(Text), Length(Text), Rect, Flags);
    OffsetRect(Rect, -1, -1);
    Canvas.Font.Color := clBtnShadow;
    DrawText(Canvas.Handle, PChar(Text), Length(Text), Rect, Flags);
  end else
    DrawText(Canvas.Handle, PChar(Text), Length(Text), Rect, Flags);
end;

procedure TCustomHyperLabel.DoDrawUnderline(X1, X2, Y: Integer);
begin
  Canvas.Pen.Color := GetHoverFontColor;
  Canvas.Pen.Style := psSolid;
  Canvas.MoveTo(X1, Y);
  Canvas.LineTo(X2, Y);
end;

function TCustomHyperLabel.GetLabelText: string;
begin
  Result := Caption;
end;

procedure TCustomHyperLabel.Loaded;
begin
  inherited;
  AdjustBounds;
end;

procedure TCustomHyperLabel.Paint;
const
  Alignments: array[TAlignment] of Word = (DT_LEFT, DT_RIGHT, DT_CENTER);
var
  Rect, CalcRect: TRect;
  DrawStyle: Longint;
begin
  with Canvas do
  begin
    if not Transparent then
    begin
      Brush.Color := Self.Color;
      Brush.Style := bsSolid;
      FillRect(ClientRect);
    end;
    Brush.Style := bsClear;
    Rect := ClientRect;
    // DoDrawText takes care of BiDi alignments
    DrawStyle := DT_EXPANDTABS or Alignments[FAlignment];
    // Calculate vertical layout
    if FLayout <> tlTop then
    begin
      CalcRect := Rect;
      DoDrawText(CalcRect, DrawStyle or DT_CALCRECT);
      if FLayout = tlBottom then OffsetRect(Rect, 0, Height - CalcRect.Bottom)
      else OffsetRect(Rect, 0, (Height - CalcRect.Bottom) div 2);
    end;
    DoDrawText(Rect, DrawStyle);

    if FIsHover and (fsUnderline in FHoverStyle.Style) and Enabled then
    begin
      CalcRect := Rect;
      DoDrawText(CalcRect, DrawStyle or DT_CALCRECT);
      DoDrawUnderline(Rect.Left, Rect.Right, Rect.Top + (CalcRect.Bottom- CalcRect.Top));
    end;
  end;
end;

procedure TCustomHyperLabel.SetAutoSize(Value: Boolean);
begin
  if FAutoSize <> Value then
  begin
    FAutoSize := Value;
    AdjustBounds;
  end;
end;

procedure InitCursors;
const
  SHandCursor = 'HL_HAND_CURSOR';
var
  Cursor: HCURSOR;
begin
  Cursor := LoadCursor(HInstance, SHandCursor);
  Screen.Cursors[crHand] := Cursor;
end;

initialization
  InitCursors;

end.
