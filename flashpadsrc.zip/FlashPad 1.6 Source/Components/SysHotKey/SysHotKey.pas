
{**********************************************************}
{                                                          }
{  SysHotKey Component Version 1.0                         }
{                                                          }
{  Author: DayDream Software                               }
{  Email: haoxg@21cn.com                                   }
{  URL: http://www.haoxg.net                               }
{  Last Modified Date: 2008-02-19                          }
{                                                          }
{**********************************************************}

unit SysHotKey;

interface

{$WARN SYMBOL_DEPRECATED OFF}

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms;

type

{ Classes }

  TSysHotKey = class;

{ Types }

  TWMHotKey = record
    Msg: Cardinal;
    HotKey: Word;
    Modifiers: Integer;
    VirtualKey : Integer;
  end;

  THotKeyModifier = (moShift, moControl, moAlt, moWin);
  THotKeyModifiers = set of THotKeyModifier;

  TVirtualKey = (
    vkNone, vkCancel, vkBack, vkTab, vkClear, vkReturn, vkPause, vkCapital, vkEscape,
    vkSpace, vkPrior, vkNext, vkEnd, vkHome, vkLeft, vkUp, vkRight, vkDown,
    vkSelect, vkExecute, vkSnapshot, vkInsert, vkDelete, vkHelp,
    vk0, vk1, vk2, vk3, vk4, vk5, vk6, vk7, vk8, vk9,
    vkA, vkB, vkC, vkD, vkE, vkF, vkG, vkH, vkI, vkJ, vkK, vkL, vkM,
    vkN, vkO, vkP, vkQ, vkR, vkS, vkT, vkU, vkV, vkW, vkX, vkY, vkZ,
    vkNumpad0, vkNumpad1, vkNumpad2, vkNumpad3, vkNumpad4,
    vkNumpad5, vkNumpad6, vkNumpad7, vkNumpad8, vkNumpad9,
    vkMultiply, vkAdd, vkSeparator, vkSubtract, vkDecimal, vkDivide,
    vkF1, vkF2, vkF3, vkF4, vkF5, vkF6, vkF7, vkF8, vkF9, vkF10, vkF11, vkF12,
    vkF13, vkF14, vkF15, vkF16, vkF17, vkF18, vkF19, vkF20, vkF21, vkF22, vkF23, vkF24,
    vkNumlock, vkScroll, vkApps);

{ THotKeyItem }

  THotKeyEvent = procedure(Sender: TObject; HotKeyIndex: Word) of object;

  THotKeyItem = class(TCollectionItem)
  private
    FEnabled: Boolean;
    FModifiers: THotKeyModifiers;
    FRegistered: Boolean;
    FVirtualKey: TVirtualKey;
    FOnHotKey: TNotifyEvent;

    procedure SetEnabled(Value: Boolean);
    procedure SetModifiers(Value: THotKeyModifiers);
    procedure SetVirtualKey(Value: TVirtualKey);
    function GetVirtualKey: TVirtualKey;
    function GetSysHotKey: TSysHotKey;

    procedure RegisterHK;
    procedure UnregisterHK;
    procedure ReregisterHK;
  protected
    function GetDisplayName: string; override;
  public
    constructor Create(Collection: TCollection); override;
    destructor Destroy; override;
    procedure Assign(Source: TPersistent); override;

    property Registered: Boolean read FRegistered;
    function GetHotKeyName: string;
  published
    property Enabled: Boolean read FEnabled write SetEnabled default True;
    property Modifiers: THotKeyModifiers read FModifiers write SetModifiers default [];
    property VirtualKey: TVirtualKey read GetVirtualKey write SetVirtualKey default vkNone;
    property OnHotKey: TNotifyEvent read FOnHotKey write FOnHotKey;
  end;

{ THotKeys }

  THotKeys = class(TCollection)
  private
    FSysHotKey: TSysHotKey;
    
    function GetItem(Index: Integer): THotKeyItem;
    procedure SetItem(Index: Integer; Value: THotKeyItem);
  protected
    function GetOwner: TPersistent; override;
  public
    constructor Create(ASysHotKey: TSysHotKey);
    destructor Destroy; override;

    function Add: THotKeyItem;
    property HotKeys[Index: Integer]: THotKeyItem read GetItem write SetItem; default;
  end;

{ TSysHotKey }

  TSysHotKey = class(TComponent)
  private
    FHotKeys: THotKeys;
    FWindowHandle: HWnd;
    FOnHotKeyEvents: THotKeyEvent;

    procedure SetHotKeys(Value: THotKeys);
    procedure WndProc(var Msg: TMessage);
  protected
    procedure Loaded; override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    procedure SetAllEnabled;
    procedure SetAllDisabled;

    class function ShortCutToVirtualKey(Value: TShortCut): TVirtualKey;
    class function VirtualKeyToShortCut(Value: TVirtualKey): TShortCut;
  published
    property HotKeys: THotKeys read FHotKeys write SetHotKeys;
    property OnHotKeys: THotKeyEvent read FOnHotKeyEvents write FOnHotKeyEvents;
  end;

procedure Register;

implementation

var
  VirtualKeys: array[TVirtualKey] of LongWord = (
    $00, $03, $08, $09, $0C, $0D, $13, $14, $1B,
    $20, $21, $22, $23, $24, $25, $26, $27, $28,
    $29, $2B, $2C, $2D, $2E, $2F,
    $30, $31, $32, $33, $34, $35, $36, $37, $38, $39,
    $41, $42, $43, $44, $45, $46, $47, $48, $49, $4A,
    $4B, $4C, $4D, $4E, $4F, $50, $51, $52, $53, $54,
    $55, $56, $57, $58, $59, $5A,
    $60, $61, $62, $63, $64, $65, $66, $67, $68, $69,
    $6A, $6B, $6C, $6D, $6E, $6F,
    $70, $71, $72, $73, $74, $75, $76, $77, $78, $79, $7A, $7B,
    $7C, $7D, $7E, $7F, $80, $81, $82, $83, $84, $85, $86, $87,
    $90, $91, $5D);

  SVirtualKeyStr: array[TVirtualKey] of string = (
    'None', 'Cancel', 'Back', 'Tab', 'Clear', 'Return', 'Pause', 'Capital', 'Escape',
    'Space', 'Prior', 'Next', 'End', 'Home', 'Left', 'Up', 'Right', 'Down',
    'Select', 'Execute', 'Snapshot', 'Insert', 'Delete', 'Help',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
    'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    'Numpad0', 'Numpad1', 'Numpad2', 'Numpad3', 'Numpad4',
    'Numpad5', 'Numpad6', 'Numpad7', 'Numpad8', 'Numpad9',
    'Multiply', 'Add', 'Separator', 'Subtract', 'Decimal', 'Divide',
    'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12',
    'F13', 'F14', 'F15', 'F16', 'F17', 'F18', 'F19', 'F20', 'F21', 'F22', 'F23', 'F24',
    'Numlock', 'Scroll', 'Apps');

procedure Register;
begin
  RegisterComponents('IrisMisc', [TSysHotKey]);
end;

{ THotKeyItem }

constructor THotKeyItem.Create(Collection: TCollection);
begin
  inherited Create(Collection);
  FEnabled := True;
  FRegistered := False;
  FVirtualKey := vkNone;
end;

destructor THotKeyItem.Destroy;
begin
  SetEnabled(false);
  inherited Destroy;
end;

procedure THotKeyItem.SetEnabled(Value: Boolean);
begin
  if Value <> FEnabled then
  begin
    FEnabled := Value;

    if not (csDesigning in GetSysHotKey.ComponentState) then
      if FEnabled then
        RegisterHK
      else
        UnregisterHK;
  end;
end;

procedure THotKeyItem.SetModifiers(Value: THotKeyModifiers);
begin
  if Value <> FModifiers then
  begin
    FModifiers := Value;
    ReregisterHK;
  end;
end;

procedure THotKeyItem.SetVirtualKey(Value: TVirtualKey);
begin
  if Value <> FVirtualKey then
  begin
    FVirtualKey := Value;
    if Value = vkNone then Enabled := False;
    ReregisterHK;
  end;
end;

function THotKeyItem.GetVirtualKey: TVirtualKey;
begin
  Result := FVirtualKey;
end;

function THotKeyItem.GetSysHotKey: TSysHotKey;
begin
  Result := TSysHotKey(THotKeys(GetOwner).GetOwner);
end;

function THotKeyItem.GetDisplayName: string;
begin
  Result := '';
  if moShift    in Modifiers then Result := Result + 'Shift';
  if moControl  in Modifiers then Result := Result + 'Control';
  if moAlt      in Modifiers then Result := Result + 'Alt';
  if moWin      in Modifiers then Result := Result + 'Win';
  if Result = '' then
    Result := SVirtualKeyStr[VirtualKey]
  else
    Result := Result + '_' + SVirtualKeyStr[VirtualKey];

  if Result = '' then Result := inherited GetDisplayName;
end;

function THotKeyItem.GetHotKeyName: string;
begin
  Result := GetDisplayName;
end;

procedure THotKeyItem.Assign(Source: TPersistent);
begin
  if Source is THotKeyItem then
  begin
    Enabled := THotKeyItem(Source).Enabled;
    Modifiers := THotKeyItem(Source).Modifiers;
    VirtualKey := THotKeyItem(Source).VirtualKey;
  end else
    inherited Assign(Source);
end;

procedure THotKeyItem.RegisterHK;

  function ModToFlag(Modifiers : THotKeyModifiers): LongWord;
  begin
    Result := 0;
    if moShift   in Modifiers then Result := Result or MOD_SHIFT;
    if moControl in Modifiers then Result := Result or MOD_CONTROL;
    if moAlt     in Modifiers then Result := Result or MOD_ALT;
    if moWin     in Modifiers then Result := Result or MOD_WIN;
  end;

var
  Success: Boolean;
begin
  if not FRegistered then
  begin
    if VirtualKey <> vkNone then
    begin
      Success := RegisterHotKey(GetSysHotKey.FWindowHandle, Index,
        ModToFlag(Modifiers), VirtualKeys[FVirtualKey]);
      if Success then
        FRegistered := True;
    end;
  end;
end;

procedure THotKeyItem.UnregisterHK;
begin
  if FRegistered then
  begin
    UnregisterHotKey(GetSysHotKey.FWindowHandle, Index);
    FRegistered := False;
  end;
end;

procedure THotKeyItem.ReregisterHK;
begin
  if not (csDesigning in GetSysHotKey.ComponentState) then
    if FEnabled then
    begin
      if FRegistered then UnregisterHK;
      RegisterHK;
    end;
end;

{ THotKeys }

constructor THotKeys.Create(ASysHotKey: TSysHotKey);
begin
  inherited Create(THotKeyItem);
  FSysHotKey := ASysHotKey;
end;

destructor THotKeys.Destroy;
begin
  inherited Destroy;
end;

function THotKeys.GetItem(Index: Integer): THotKeyItem;
begin
  Result := THotKeyItem(inherited GetItem(Index));
end;

procedure THotKeys.SetItem(Index: Integer; Value: THotKeyItem);
begin
  inherited SetItem(Index, Value);
end;

function THotKeys.GetOwner: TPersistent;
begin
  Result := FSysHotKey;
end;

function THotKeys.Add: THotKeyItem;
begin
  Result := THotKeyItem(inherited Add);
end;

{ TSysHotKey }

constructor TSysHotKey.Create(AOwner: TComponent);
var
  I: Integer;
begin
  if AOwner =  nil then
    raise Exception.Create('The owner of TSysHotKey cannot be nil');

  for I := 0 to AOwner.ComponentCount - 1 do
    if AOwner.Components[I] is TSysHotKey then
      raise Exception.Create('No more than one TSysHotKey component on a form');

  inherited Create(AOwner);
  FHotKeys := THotKeys.Create(Self);
  FWindowHandle := AllocateHWnd(WndProc);
end;

destructor TSysHotKey.Destroy;
begin
  FHotKeys.Free;
  DeallocateHWnd(FWindowHandle);
  inherited Destroy;
end;

procedure TSysHotKey.SetHotKeys(Value: THotKeys);
begin
  FHotKeys.Assign(Value);
end;

procedure TSysHotKey.WndProc(var Msg: TMessage);
begin
  if Msg.Msg = WM_HOTKEY then
  begin
    with TWMHotKey(Msg) do
    begin
      if Assigned(HotKeys[HotKey].FOnHotKey) then
        HotKeys[HotKey].FOnHotKey(Self);
      if Assigned(FOnHotKeyEvents) then
        FOnHotKeyEvents(Self, HotKey);
    end;
  end else
    Msg.Result := DefWindowProc(FWindowHandle, Msg.Msg, Msg.wParam, Msg.lParam);
end;

procedure TSysHotKey.Loaded;
var
  I: Integer;
begin
  if not (csDesigning in ComponentState) then
    for I := 0 to HotKeys.Count - 1 do
      if HotKeys[I].Enabled then HotKeys[I].RegisterHK;
end;

procedure TSysHotKey.SetAllEnabled;
var
  I: Integer;
begin
  for I := 0 to HotKeys.Count - 1 do
    HotKeys[I].Enabled := true;
end;

procedure TSysHotKey.SetAllDisabled;
var
  I: Integer;
begin
  for I := 0 to HotKeys.Count - 1 do
    HotKeys[I].Enabled := false;
end;

class function TSysHotKey.ShortCutToVirtualKey(Value: TShortCut): TVirtualKey;
var
  I: LongWord;
begin
  for I := 0 to LongWord(High(VirtualKeys)) do
    if Value = VirtualKeys[TVirtualKey(I)] then
    begin
      Result := TVirtualKey(I);
      Exit;
    end;
  Result := vkNone;
end;

class function TSysHotKey.VirtualKeyToShortCut(Value: TVirtualKey): TShortCut;
begin
  Result := TShortCut(VirtualKeys[Value]);
end;

end.

