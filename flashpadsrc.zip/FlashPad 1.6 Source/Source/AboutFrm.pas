unit AboutFrm;

interface

uses
  Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, BaseFrm, HyperLabel;

type
  TAboutForm = class(TBaseForm)
    OkButton: TButton;
    Image1: TImage;
    SoftNameLabel: TLabel;
    Image3: TImage;
    Image4: TImage;
    CompanyLabel: TLabel;
    Bevel1: TBevel;
    VersionLabel: TLabel;
    WebsiteHyperLabel: THyperLabel;
    EmailHyperLabel: THyperLabel;
    Label1: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure WebsiteHyperLabelClick(Sender: TObject);
    procedure EmailHyperLabelClick(Sender: TObject);
    procedure OkButtonClick(Sender: TObject);
  private
  public
  end;

procedure ShowAboutForm;

implementation

uses Global, PubUtils, AppUtils;

{$R *.DFM}

procedure ShowAboutForm;
var
  Form: TAboutForm;
begin
  Form := TAboutForm.Create(GetMainForm);
  try
    Form.ShowModal;
  finally
    Form.Free;
  end;
end;

{ TAboutForm }

procedure TAboutForm.FormCreate(Sender: TObject);
begin
  SoftNameLabel.Caption := SSoftName;
  VersionLabel.Caption := SVersion;
  VersionLabel.Left := SoftNameLabel.BoundsRect.Right + 8;
  EmailHyperLabel.Caption := SEmail;
  WebsiteHyperLabel.Caption := SWebSite;
end;

procedure TAboutForm.WebsiteHyperLabelClick(Sender: TObject);
begin
  OpenURL(WebsiteHyperLabel.Caption);
end;

procedure TAboutForm.EmailHyperLabelClick(Sender: TObject);
begin
  OpenEmail(EmailHyperLabel.Caption);
end;

procedure TAboutForm.OkButtonClick(Sender: TObject);
begin
  Close;
end;

end.
