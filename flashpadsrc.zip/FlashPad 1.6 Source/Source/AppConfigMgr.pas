unit AppConfigMgr;

interface

uses
  Windows, SysUtils, Classes, Graphics, BaseConfigMgr, SysHotKey;

type

  TDblClickTitleActionType = (dctNoAction, dctDeletePage, dctChgPageTitle);

{ TAppConfigMgr }

  TAppConfigMgr = class(TBaseConfigMgr)
  private
    FRunOnStartup: Boolean;
    FMinOnClose: Boolean;
    FDblClickTitleActionType: TDblClickTitleActionType;
    FWordWrap: Boolean;
    FStayOnTop: Boolean;
    FTextFont: TFont;
    FBgColor: TColor;
    FPromptMinToTray: Boolean;
    FWinBounds: TRect;
    FWinMaximized: Boolean;
    FPageIndex: Integer;
    FHotKeyBase: TVirtualKey;
    FHotKeyModifiers: THotKeyModifiers;
    FInsertLineText: string;
    FInsertDateText: string;
    FInsertLineDateText: string;
    FInsertCustomList: TStrings;
  private
    function GetIniFileName: string;
    procedure SetInsertCustomList(Value: TStrings);

    procedure InitDefault;
    procedure GetValues;
    procedure SetValues;
  public
    constructor Create;
    destructor Destroy; override;

    procedure Load;
    procedure Save;

    property RunOnStartup: Boolean read FRunOnStartup write FRunOnStartup;
    property MinOnClose: Boolean read FMinOnClose write FMinOnClose;
    property DblClickTitleActionType: TDblClickTitleActionType read FDblClickTitleActionType write FDblClickTitleActionType;
    property WordWrap: Boolean read FWordWrap write FWordWrap;
    property StayOnTop: Boolean read FStayOnTop write FStayOnTop;
    property TextFont: TFont read FTextFont;
    property BgColor: TColor read FBgColor write FBgColor;
    property PromptMinToTray: Boolean read FPromptMinToTray write FPromptMinToTray;
    property WinBounds: TRect read FWinBounds write FWinBounds;
    property WinMaximized: Boolean read FWinMaximized write FWinMaximized;
    property PageIndex: Integer read FPageIndex write FPageIndex;
    property HotKeyBase: TVirtualKey read FHotKeyBase write FHotKeyBase;
    property HotKeyModifiers: THotKeyModifiers read FHotKeyModifiers write FHotKeyModifiers;
    property InsertLineText: string read FInsertLineText write FInsertLineText;
    property InsertDateText: string read FInsertDateText write FInsertDateText;
    property InsertLineDateText: string read FInsertLineDateText write FInsertLineDateText;
    property InsertCustomList: TStrings read FInsertCustomList write SetInsertCustomList;
  end;

var
  ConfigMgr: TAppConfigMgr;

implementation

uses PubUtils, AppUtils, Global;

const
  SSecDefault = 'Config';

{ TAppConfigMgr }

constructor TAppConfigMgr.Create;
begin
  inherited;
  FTextFont := TFont.Create;
  FInsertCustomList := TStringList.Create;
  InitDefault;
  Load;
end;

destructor TAppConfigMgr.Destroy;
begin
  Save;
  FTextFont.Free;
  FInsertCustomList.Free;
  inherited;
end;

function TAppConfigMgr.GetIniFileName: string;
begin
  Result := GetAppPath + SConfigFileName;
end;

procedure TAppConfigMgr.SetInsertCustomList(Value: TStrings);
begin
  FInsertCustomList.Assign(Value);
end;

procedure TAppConfigMgr.InitDefault;
begin
  FRunOnStartup := True;
  FMinOnClose := True;
  FDblClickTitleActionType:= dctDeletePage;
  FWordWrap := True;
  FStayOnTop := False;
  with FTextFont do
  begin
    Name := '����';
    Size := 9;
    Style := [];
    Color := clBlack;
    Charset := GB2312_CHARSET;
  end;
  FBgColor := clWindow;
  FPromptMinToTray := True;
  FillChar(FWinBounds, SizeOf(FWinBounds), 0);
  FWinMaximized := False;
  FPageIndex := 0;
  FHotKeyBase := vkZ;
  FHotKeyModifiers := [moAlt];
  FInsertLineText := 'crlf() + chars(''-'', 80) + crlf()';
  FInsertDateText := 'date() + '' '' + time()';
  FInsertLineDateText := 'crlf() + chars(''-'', 29) + '' '' + date() + '' '' + time() + '' '' + chars(''-'', 30) + crlf()';
  FInsertCustomList.Clear;
end;

procedure TAppConfigMgr.GetValues;
begin
  FRunOnStartup := GetBoolean(SSecDefault, 'RunOnStartup', FRunOnStartup);
  FMinOnClose := GetBoolean(SSecDefault, 'MinOnClose', FMinOnClose);
  FDblClickTitleActionType := TDblClickTitleActionType(GetInteger(SSecDefault, 'DblClickTitleActionType', Ord(FDblClickTitleActionType)));
  FWordWrap := GetBoolean(SSecDefault, 'WordWrap', FWordWrap);
  FStayOnTop := GetBoolean(SSecDefault, 'StayOnTop', FStayOnTop);

  FTextFont.Name := GetString(SSecDefault, 'FontName', FTextFont.Name);
  FTextFont.Size := GetInteger(SSecDefault, 'FontSize', FTextFont.Size);
  FTextFont.Style := TFontStyles(Byte(GetInteger(SSecDefault, 'FontStyle', Byte(FTextFont.Style))));
  FTextFont.Color := TColor(GetInteger(SSecDefault, 'FontColor', FTextFont.Color));
  FTextFont.Charset := GetInteger(SSecDefault, 'FontCharset', FTextFont.Charset);

  FBgColor := TColor(GetInteger(SSecDefault, 'BgColor', FBgColor));
  FPromptMinToTray := GetBoolean(SSecDefault, 'PromptMinToTray', FPromptMinToTray);

  FWinBounds.Left := GetInteger(SSecDefault, 'WinLeft', FWinBounds.Left);
  FWinBounds.Top := GetInteger(SSecDefault, 'WinTop', FWinBounds.Top);
  FWinBounds.Right := GetInteger(SSecDefault, 'WinRight', FWinBounds.Right);
  FWinBounds.Bottom := GetInteger(SSecDefault, 'WinBottom', FWinBounds.Bottom);

  FWinMaximized := GetBoolean(SSecDefault, 'WinMaximized', FWinMaximized);
  FPageIndex := GetInteger(SSecDefault, 'PageIndex', FPageIndex);

  FHotKeyBase := TVirtualKey(GetInteger(SSecDefault, 'HotKeyBase', Integer(FHotKeyBase)));
  FHotKeyModifiers := THotKeyModifiers(Byte(GetInteger(SSecDefault, 'HotKeyModifiers', Byte(FHotKeyModifiers))));

  FInsertLineText := GetString(SSecDefault, 'InsertLineText', FInsertLineText);
  FInsertDateText := GetString(SSecDefault, 'InsertDateText', FInsertDateText);
  FInsertLineDateText := GetString(SSecDefault, 'InsertLineDateText', FInsertLineDateText);
  FInsertCustomList.CommaText := string(Base16Decode(AnsiString(GetString(SSecDefault, 'InsertCustomList', ''))));
end;

procedure TAppConfigMgr.SetValues;
begin
  SetBoolean(SSecDefault, 'RunOnStartup', FRunOnStartup);
  SetBoolean(SSecDefault, 'MinOnClose', FMinOnClose);
  SetInteger(SSecDefault, 'DblClickTitleActionType', Ord(FDblClickTitleActionType));
  SetBoolean(SSecDefault, 'WordWrap', FWordWrap);
  SetBoolean(SSecDefault, 'StayOnTop', FStayOnTop);

  SetString(SSecDefault, 'FontName', FTextFont.Name);
  SetInteger(SSecDefault, 'FontSize', FTextFont.Size);
  SetInteger(SSecDefault, 'FontStyle', Byte(FTextFont.Style));
  SetInteger(SSecDefault, 'FontColor', FTextFont.Color);
  SetInteger(SSecDefault, 'FontCharset', FTextFont.Charset);

  SetInteger(SSecDefault, 'BgColor', FBgColor);
  SetBoolean(SSecDefault, 'PromptMinToTray', FPromptMinToTray);

  SetInteger(SSecDefault, 'WinLeft', FWinBounds.Left);
  SetInteger(SSecDefault, 'WinTop', FWinBounds.Top);
  SetInteger(SSecDefault, 'WinRight', FWinBounds.Right);
  SetInteger(SSecDefault, 'WinBottom', FWinBounds.Bottom);

  SetBoolean(SSecDefault, 'WinMaximized', FWinMaximized);
  SetInteger(SSecDefault, 'PageIndex', FPageIndex);

  SetInteger(SSecDefault, 'HotKeyBase', Integer(FHotKeyBase));
  SetInteger(SSecDefault, 'HotKeyModifiers', Byte(FHotKeyModifiers));

  SetString(SSecDefault, 'InsertLineText', FInsertLineText);
  SetString(SSecDefault, 'InsertDateText', FInsertDateText);
  SetString(SSecDefault, 'InsertLineDateText', FInsertLineDateText);
  SetString(SSecDefault, 'InsertCustomList', string(Base16Encode(AnsiString(FInsertCustomList.CommaText))));
end;

procedure TAppConfigMgr.Load;
begin
  LoadFromIniFile(GetIniFileName);
  GetValues;
end;

procedure TAppConfigMgr.Save;
begin
  SetValues;
  SaveToIniFile(GetIniFileName);
end;

initialization
  ConfigMgr := TAppConfigMgr.Create;

finalization
  ConfigMgr.Free;

end.
