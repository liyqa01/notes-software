unit AppUtils;

interface

uses
  Windows, SysUtils, Classes, Forms, StrUtils, Global;

procedure CheckCmdParams;
procedure CheckInstanceCount;
function SearchString(Str: WideString; SelStart, SelLength: Integer;
  SearchString: WideString; Options: TStringSearchOptions): Integer;
function GetMainForm: TForm;
function MultiLineToSingleLine(const S: string): string;
function SingleLineToMultiLine(const S: string): string;
function Base16Encode(const Src: AnsiString): AnsiString;
function Base16Decode(const Src: AnsiString): AnsiString;

implementation

uses MainFrm;

//-----------------------------------------------------------------------------
// ����: ���������в���������Ӧ�Ķ���
//-----------------------------------------------------------------------------
procedure CheckCmdParams;
begin
  if (ParamCount > 0) and (ParamStr(1) = SParamMinimize) then
    MainForm.Hide
  else
    MainForm.Show;
end;

//-----------------------------------------------------------------------------
// ����: ���Ƴ���ʵ��ĸ���
//-----------------------------------------------------------------------------
procedure CheckInstanceCount;

  function GetInstanceCount(var LastHandle: HWND): Integer;
  var
    Handle: HWND;
  begin
    Result := 0;
    Handle := GetDesktopWindow;
    Handle := GetWindow(Handle, GW_CHILD);
    while IsWindow(Handle) do
    begin
      // �жϴ˴������Ա�־
      if GetProp(Handle, PChar(SSoftName)) = Handle then
      begin
        Inc(Result);
        LastHandle := Handle;
      end;
      // ת�������б�����һ������.
      Handle := GetWindow(Handle, GW_HWNDNEXT);
    end;
  end;

const
  MaxInstanceCount = 1;
var
  Count: Integer;
  LastHandle: HWND;
begin
  Count := GetInstanceCount(LastHandle);
  if Count >= MaxInstanceCount then
  begin
    SetForegroundWindow(LastHandle);
    PostMessage(LastHandle, WM_SHOW_MAIN_WIN, 0, 0);
    Halt;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ַ�������
//-----------------------------------------------------------------------------
function SearchString(Str: WideString; SelStart, SelLength: Integer;
  SearchString: WideString; Options: TStringSearchOptions): Integer;
var
  SearchCount, I, StrLen: Integer;
  Direction: Shortint;

  function IsDelimiterChar(C: WideChar): Boolean;
  begin
    Result := (C >= 'a') and (C <= 'z') or
      (C >= 'A') and (C <= 'Z') or
      (C >= '0') and (C <= '9');
    Result := not Result;
  end;

  function FindNextWordStart(var Index: Integer): Boolean;
  begin
    { (True XOR N) is equivalent to (not N) }
    { (False XOR N) is equivalent to (N)    }
    { When Direction is forward (1), skip non delimiters, then skip delimiters. }
    { When Direction is backward (-1), skip delims, then skip non delims }
    while (SearchCount > 0) and
      ((Direction = 1) xor IsDelimiterChar(Str[Index])) do
    begin
      Inc(Index, Direction);
      Dec(SearchCount);
    end;
    while (SearchCount > 0) and
      ((Direction = -1) xor IsDelimiterChar(Str[Index])) do
    begin
      Inc(Index, Direction);
      Dec(SearchCount);
    end;
    Result := SearchCount > 0;
    if Direction = -1 then
    begin   { back up one char, to leave ptr on first non delim }
      Dec(Index, Direction);
      Inc(SearchCount);
    end;
  end;

begin
  Result := 0;
  StrLen := Length(Str);
  if StrLen <= 0 then Exit;
  if Length(SearchString) <= 0 then Exit;

  if soDown in Options then
  begin
    Direction := 1;
    Inc(SelStart, SelLength);  { start search past end of selection }
    SearchCount := StrLen - SelStart - Length(SearchString) + 1;
    if SearchCount < 0 then Exit;
    if Longint(SelStart) + SearchCount > StrLen then Exit;
  end else
  begin
    Direction := -1;
    Dec(SelStart, Length(SearchString));
    SearchCount := SelStart + 1;
  end;
  if (SelStart < 0) or (SelStart > StrLen) then Exit;
  Result := SelStart + 1;

  if not (soMatchCase in Options) then
  begin
    Str := WideUpperCase(Str);
    SearchString := WideUpperCase(SearchString);
  end;

  while SearchCount > 0 do
  begin
    if (soWholeWord in Options) and (Result <> SelStart + 1) then
      if not FindNextWordStart(Result) then Break;
    I := 0;
    while (Str[Result + I] = SearchString[I + 1]) do
    begin
      Inc(I);
      if I >= Length(SearchString) then
      begin
        if (not (soWholeWord in Options)) or (SearchCount = 0) or
          IsDelimiterChar(Str[Result + I]) then
          Exit;
        Break;
      end;
    end;
    Inc(Result, Direction);
    Dec(SearchCount);
  end;
  Result := 0;
end;

//-----------------------------------------------------------------------------
// ����: ���� MainForm
//-----------------------------------------------------------------------------
function GetMainForm: TForm;
begin
  Result := MainForm;
end;

//-----------------------------------------------------------------------------
// ����: �����ı� -> �����ı�
//-----------------------------------------------------------------------------
function MultiLineToSingleLine(const S: string): string;
var
  List: TStringList;
begin
  List := TStringList.Create;
  try
    List.Text := S;
    Result := List.CommaText;
  finally
    List.Free;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �����ı� -> �����ı�
//-----------------------------------------------------------------------------
function SingleLineToMultiLine(const S: string): string;
var
  List: TStringList;
begin
  List := TStringList.Create;
  try
    List.CommaText := S;
    Result := List.Text;
    while (Length(Result) > 0) and CharInSet(Result[Length(Result)], [#13, #10]) do
      Delete(Result, Length(Result), 1);
  finally
    List.Free;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ���ַ������� base16 ����
// ����:
//   Value - ��������ַ���
// ����:
//   �������ַ���
//-----------------------------------------------------------------------------
function Base16Encode(const Src: AnsiString): AnsiString;
const
  H: array[0..15] of AnsiChar = '0123456789ABCDEF';
var
  S: PByte;
  D: PAnsiChar;
  SrcBytes: Integer;
begin
  Result := '';
  SrcBytes := Length(Src);
  SetLength(Result, SrcBytes * 2);
  if SrcBytes = 0 then Exit;
  D := PAnsiChar(Result);
  S := PByte(Src);
  while SrcBytes > 0 do
  begin
    D^ := H[S^ shr  4]; Inc(D);
    D^ := H[S^ and $F]; Inc(D);
    Inc(S);
    Dec(SrcBytes);
  end;
end;

//-----------------------------------------------------------------------------
// ����: �� base16 ��������ݻ�ԭ���ַ���
// ����:
//   Value - ��������ַ���
// ����:
//   �������ַ���
//-----------------------------------------------------------------------------
function Base16Decode(const Src: AnsiString): AnsiString;
var
  D: PByte;
  V: Byte;
  S: PAnsiChar;
  SrcBytes: Integer;
begin
  Result := '';
  SrcBytes := Length(Src);
  SetLength(Result, (SrcBytes +1) div 2);
  D := PByte(Result);
  S := PAnsiChar(Src);
  while SrcBytes > 0 do
  begin
    V := Byte(UpCase(S^));
    Inc(S);
    if V > Byte('9') then D^ := V - Byte('A') + 10
      else D^ := V - Byte('0');
    V := Byte(UpCase(S^));
    Inc(S);
    D^ := D^ shl 4;
    if V > Byte('9') then D^ := D^ or (V - Byte('A') + 10)
      else D^ := D^ or (V - Byte('0'));
    Dec(SrcBytes, 2);
    Inc(D);
  end;
  SetLength(Result, PAnsiChar(D) - PAnsiChar(Result));
end;

end.
