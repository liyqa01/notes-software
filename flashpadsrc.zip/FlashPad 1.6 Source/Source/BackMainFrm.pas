unit BackMainFrm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs;

type
  TBackMainForm = class(TForm)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  BackMainForm: TBackMainForm;

implementation

{$R *.dfm}

end.
