unit BaseConfigMgr;

interface

uses
  Windows, SysUtils, Classes, IniFiles, Registry, Containers;

type

{ Classes }

  TBaseConfigMgr = class;
  TConfigIO = class;
  TIniConfigIO = class;
  TRegConfigIO = class;

{ TBaseConfigMgr }

  TBaseConfigMgr = class(TObject)
  private
    FSections: TStrHashTable;       // <Section, TPropertyList>
  private
    function FindPropList(const Section: string): TPropertyList;
    function AddSection(const Section: string): TPropertyList;
    procedure Load(IO: TConfigIO);
    procedure Save(IO: TConfigIO);
  protected
    function GetString(const Section, Key: string; const Default: string): string;
    function GetInteger(const Section, Key: string; Default: Integer): Integer;
    function GetBoolean(const Section, Key: string; const Default: Boolean): Boolean;
    function GetVariant(const Section, Key: string; const Default: Variant): Variant;
    
    procedure SetString(const Section, Key, Value: string);
    procedure SetInteger(const Section, Key: string; Value: Integer);
    procedure SetBoolean(const Section, Key: string; Value: Boolean);
    procedure SetVariant(const Section, Key: string; const Value: Variant);

    procedure DeleteSection(const Section: string);
    procedure GetSection(const Section: string; List: TPropertyList);

    procedure LoadFromIniFile(const FileName: string);
    procedure SaveToIniFile(const FileName: string);
    procedure LoadFromRegistry(RootKey: HKEY; const Path: string);
    procedure SaveToRegistry(RootKey: HKEY; const Path: string);
  public
    constructor Create;
    destructor Destroy; override;
    procedure Clear;
  end;

{ TConfigIO }

  TConfigIO = class(TObject)
  public
    procedure BeginUpdate; virtual;
    procedure EndUpdate; virtual;
    procedure GetSectionList(List: TStrings); virtual; abstract;
    procedure GetKeyList(const Section: string; List: TStrings); virtual; abstract;
    function Read(const Section, Key: string; const Default: string): string; virtual; abstract;
    procedure Write(const Section, Key, Value: string); virtual; abstract;
    procedure DeleteSection(const Section: string); virtual; abstract;
  end;

{ TIniConfigIO }

  TIniConfigIO = class(TConfigIO)
  private
    FFileName: string;
    FIniFile: TMemIniFile;
  public
    constructor Create(const FileName: string);
    procedure BeginUpdate; override;
    procedure EndUpdate; override;
    procedure GetSectionList(List: TStrings); override;
    procedure GetKeyList(const Section: string; List: TStrings); override;
    function Read(const Section, Key: string; const Default: string): string; override;
    procedure Write(const Section, Key, Value: string); override;
    procedure DeleteSection(const Section: string); override;
  end;

{ TRegConfigIO }

  TRegConfigIO = class(TConfigIO)
  private
    FRootKey: HKEY;
    FPath: string;
    FRegistry: TRegistry;
  public
    constructor Create(RootKey: HKEY; const Path: string);
    procedure BeginUpdate; override;
    procedure EndUpdate; override;
    procedure GetSectionList(List: TStrings); override;
    procedure GetKeyList(const Section: string; List: TStrings); override;
    function Read(const Section, Key: string; const Default: string): string; override;
    procedure Write(const Section, Key, Value: string); override;
    procedure DeleteSection(const Section: string); override;
  end;

implementation

{ TBaseConfigMgr }

constructor TBaseConfigMgr.Create;
begin
  inherited;
  FSections := TStrHashTable.Create(256, False);
end;

destructor TBaseConfigMgr.Destroy;
begin
  Clear;
  FSections.Free;
  inherited;
end;

procedure TBaseConfigMgr.Clear;
var
  HashItems: TStrHashItems;
  I: Integer;
begin
  FSections.GetItems(HashItems);
  for I := 0 to Length(HashItems) - 1 do
    TPropertyList(HashItems[I].Value).Free;
  FSections.Clear;
end;

function TBaseConfigMgr.FindPropList(const Section: string): TPropertyList;
begin
  if not FSections.GetValue(Section, Integer(Result)) then
    Result := nil;
end;

function TBaseConfigMgr.AddSection(const Section: string): TPropertyList;
begin
  Result := FindPropList(Section);
  if Result = nil then
  begin
    Result := TPropertyList.Create;
    FSections.Add(Section, Integer(Result));
  end;
end;

procedure TBaseConfigMgr.Load(IO: TConfigIO);
var
  SectionList, KeyList: TStringList;
  SecIndex, KeyIndex: Integer;
  Section, Key, Value: string;
begin
  SectionList := TStringList.Create;
  KeyList := TStringList.Create;
  try
    Clear;
    IO.BeginUpdate;
    try
      IO.GetSectionList(SectionList);
      for SecIndex := 0 to SectionList.Count - 1 do
      begin
        Section := SectionList[SecIndex];
        KeyList.Clear;
        IO.GetKeyList(Section, KeyList);
        for KeyIndex := 0 to KeyList.Count - 1 do
        begin
          Key := KeyList[KeyIndex];
          Value := IO.Read(Section, Key, '');
          SetString(Section, Key, Value);
        end;
      end;
    finally
      IO.EndUpdate;
    end;
  finally
    SectionList.Free;
    KeyList.Free;
  end;
end;

procedure TBaseConfigMgr.Save(IO: TConfigIO);
var
  HashItems: TStrHashItems;
  PropList: TPropertyList;
  SecIndex, KeyIndex: Integer;
  Section, Key, Value: string;
begin
  IO.BeginUpdate;
  try
    FSections.GetItems(HashItems);
    for SecIndex := 0 to Length(HashItems) - 1 do
    begin
      Section := HashItems[SecIndex].Key;
      IO.DeleteSection(Section);
      PropList := TPropertyList(HashItems[SecIndex].Value);
      for KeyIndex := 0 to PropList.Count - 1 do
      begin
        Key := PropList.Items[KeyIndex].Name;
        Value := PropList.Items[KeyIndex].Value;
        IO.Write(Section, Key, Value);
      end;
    end;
  finally
    IO.EndUpdate;
  end;
end;

function TBaseConfigMgr.GetString(const Section, Key: string;
  const Default: string): string;
var
  PropList: TPropertyList;
begin
  PropList := FindPropList(Section);
  if (PropList = nil) or not PropList.GetValue(Key, Result) then
    Result := Default;
end;

function TBaseConfigMgr.GetInteger(const Section, Key: string;
  Default: Integer): Integer;
var
  PropList: TPropertyList;
  ValueStr: string;
begin
  PropList := FindPropList(Section);
  if (PropList <> nil) and PropList.GetValue(Key, ValueStr) then
    Result := StrToIntDef(ValueStr, Default)
  else
    Result := Default;
end;

function TBaseConfigMgr.GetBoolean(const Section, Key: string;
  const Default: Boolean): Boolean;
var
  PropList: TPropertyList;
  ValueStr: string;
begin
  PropList := FindPropList(Section);
  if (PropList <> nil) and PropList.GetValue(Key, ValueStr) then
    Result := StrToBoolDef(ValueStr, Default)
  else
    Result := Default;
end;

function TBaseConfigMgr.GetVariant(const Section, Key: string;
  const Default: Variant): Variant;
var
  PropList: TPropertyList;
  ValueStr: string;
begin
  PropList := FindPropList(Section);
  if (PropList <> nil) and PropList.GetValue(Key, ValueStr) then
    Result := ValueStr
  else
    Result := Default;
end;

procedure TBaseConfigMgr.SetString(const Section, Key, Value: string);
var
  PropList: TPropertyList;
begin
  PropList := AddSection(Section);
  PropList.Add(Key, Value);
end;

procedure TBaseConfigMgr.SetInteger(const Section, Key: string; Value: Integer);
var
  PropList: TPropertyList;
begin
  PropList := AddSection(Section);
  PropList.Add(Key, IntToStr(Value));
end;

procedure TBaseConfigMgr.SetBoolean(const Section, Key: string; Value: Boolean);
var
  PropList: TPropertyList;
begin
  PropList := AddSection(Section);
  PropList.Add(Key, BoolToStr(Value, True));
end;

procedure TBaseConfigMgr.SetVariant(const Section, Key: string; const Value: Variant);
var
  PropList: TPropertyList;
begin
  PropList := AddSection(Section);
  PropList.Add(Key, Value);
end;

procedure TBaseConfigMgr.DeleteSection(const Section: string);
var
  PropList: TPropertyList;
begin
  // FSections �ж�Ӧ����ĿӦ������ֻ���� PropList ����Ϊ�գ�
  // �Ա� Save ʱ����ȷɾ���ļ��е� Section.
  PropList := FindPropList(Section);
  if PropList <> nil then
    PropList.Clear;
end;

procedure TBaseConfigMgr.GetSection(const Section: string; List: TPropertyList);
var
  PropList: TPropertyList;
begin
  List.Clear;
  PropList := FindPropList(Section);
  if PropList <> nil then
    List.Assign(PropList);
end;

procedure TBaseConfigMgr.LoadFromIniFile(const FileName: string);
var
  IO: TIniConfigIO;
begin
  IO := TIniConfigIO.Create(FileName);
  try
    Load(IO);
  finally
    IO.Free;
  end;
end;

procedure TBaseConfigMgr.SaveToIniFile(const FileName: string);
var
  IO: TIniConfigIO;
begin
  IO := TIniConfigIO.Create(FileName);
  try
    Save(IO);
  finally
    IO.Free;
  end;
end;

procedure TBaseConfigMgr.LoadFromRegistry(RootKey: HKEY; const Path: string);
var
  IO: TRegConfigIO;
begin
  IO := TRegConfigIO.Create(RootKey, Path);
  try
    Load(IO);
  finally
    IO.Free;
  end;
end;

procedure TBaseConfigMgr.SaveToRegistry(RootKey: HKEY; const Path: string);
var
  IO: TRegConfigIO;
begin
  IO := TRegConfigIO.Create(RootKey, Path);
  try
    Save(IO);
  finally
    IO.Free;
  end;
end;

{ TConfigIO }

procedure TConfigIO.BeginUpdate;
begin
  // nothing
end;

procedure TConfigIO.EndUpdate;
begin
  // nothing
end;

{ TIniConfigIO }

constructor TIniConfigIO.Create(const FileName: string);
begin
  inherited Create;
  FFileName := FileName;
end;

procedure TIniConfigIO.BeginUpdate;
begin
  FIniFile := TMemIniFile.Create(FFileName);
end;

procedure TIniConfigIO.EndUpdate;
begin
  FIniFile.UpdateFile;
  FIniFile.Free;
end;

procedure TIniConfigIO.GetSectionList(List: TStrings);
begin
  FIniFile.ReadSections(List);
end;

procedure TIniConfigIO.GetKeyList(const Section: string; List: TStrings);
begin
  FIniFile.ReadSection(Section, List);
end;

function TIniConfigIO.Read(const Section, Key: string; const Default: string): string;
begin
  Result := FIniFile.ReadString(Section, Key, Default);
end;

procedure TIniConfigIO.Write(const Section, Key, Value: string);
begin
  FIniFile.WriteString(Section, Key, Value);
end;

procedure TIniConfigIO.DeleteSection(const Section: string);
begin
  FIniFile.EraseSection(Section);
end;

{ TRegConfigIO }

constructor TRegConfigIO.Create(RootKey: HKEY; const Path: string);
begin
  inherited Create;
  FRootKey := RootKey;
  FPath := Path;
  if Copy(FPath, Length(FPath), 1) <> '\' then
    FPath := FPath + '\';
end;

procedure TRegConfigIO.BeginUpdate;
begin
  FRegistry := TRegistry.Create;
  FRegistry.RootKey := FRootKey;
end;

procedure TRegConfigIO.EndUpdate;
begin
  FRegistry.Free;
end;

procedure TRegConfigIO.GetSectionList(List: TStrings);
begin
  List.Clear;
  if FRegistry.OpenKey(FPath, False) then
    FRegistry.GetKeyNames(List);
end;

procedure TRegConfigIO.GetKeyList(const Section: string; List: TStrings);
begin
  List.Clear;
  if FRegistry.OpenKey(FPath + Section, False) then
    FRegistry.GetValueNames(List);
end;

function TRegConfigIO.Read(const Section, Key: string; const Default: string): string;
begin
  if FRegistry.OpenKey(FPath + Section, False) then
    Result := FRegistry.ReadString(Key)
  else
    Result := Default;
end;

procedure TRegConfigIO.Write(const Section, Key, Value: string);
begin
  if FRegistry.OpenKey(FPath + Section, True) then
    FRegistry.WriteString(Key, Value);
end;

procedure TRegConfigIO.DeleteSection(const Section: string);
begin
  if FRegistry.OpenKey(FPath, False) then
    FRegistry.DeleteKey(Section);
end;

end.
