unit BaseFrm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs;

type
  TBaseForm = class(TForm)
  private
  public
  end;

implementation

{$R *.dfm}

end.
