inherited ConfigForm: TConfigForm
  BorderStyle = bsDialog
  Caption = #35774#32622
  ClientHeight = 297
  ClientWidth = 302
  Position = poOwnerFormCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  ExplicitWidth = 308
  ExplicitHeight = 322
  PixelsPerInch = 96
  TextHeight = 12
  object OkButton: TButton
    Left = 140
    Top = 270
    Width = 75
    Height = 21
    Anchors = [akRight, akBottom]
    Caption = #30830#23450
    Default = True
    TabOrder = 1
    OnClick = OkButtonClick
  end
  object CancelButton: TButton
    Left = 221
    Top = 270
    Width = 75
    Height = 21
    Anchors = [akRight, akBottom]
    Cancel = True
    Caption = #21462#28040
    TabOrder = 2
    OnClick = CancelButtonClick
  end
  object PageControl: TPageControl
    AlignWithMargins = True
    Left = 6
    Top = 6
    Width = 290
    Height = 258
    Margins.Left = 6
    Margins.Top = 6
    Margins.Right = 6
    Margins.Bottom = 33
    ActivePage = GeneralTabSheet
    Align = alClient
    TabOrder = 0
    object GeneralTabSheet: TTabSheet
      Caption = #24120#35268
      object GroupBox1: TGroupBox
        Left = 10
        Top = 8
        Width = 261
        Height = 69
        Caption = #24120#35268#36873#39033
        TabOrder = 0
        object RunOnStartupCheckBox: TCheckBox
          Left = 13
          Top = 19
          Width = 137
          Height = 17
          Caption = #31995#32479#21551#21160#26102#33258#21160#36816#34892
          Checked = True
          State = cbChecked
          TabOrder = 0
        end
        object MinOnCloseCheckBox: TCheckBox
          Left = 13
          Top = 40
          Width = 205
          Height = 17
          Caption = #28857#20987#20027#31383#21475#30340#20851#38381#25353#38062#26102#26368#23567#21270
          Checked = True
          State = cbChecked
          TabOrder = 1
        end
      end
      object DblClickTitleRadioGroup: TRadioGroup
        Left = 10
        Top = 88
        Width = 261
        Height = 50
        Caption = #21452#20987#39029#38754#26631#39064#26102
        Columns = 3
        ItemIndex = 1
        Items.Strings = (
          #26080#21160#20316
          #21024#38500#39029#38754
          #20462#25913#26631#39064)
        TabOrder = 1
      end
    end
    object HotKeyTabSheet: TTabSheet
      Caption = #28909#38190
      ImageIndex = 1
      object GroupBox2: TGroupBox
        Left = 10
        Top = 8
        Width = 261
        Height = 92
        Caption = #26174#31034'/'#38544#34255#20027#31383#21475' '#28909#38190
        TabOrder = 0
        object Label1: TLabel
          Left = 14
          Top = 25
          Width = 42
          Height = 12
          Caption = #22522#26412#38190':'
        end
        object Label2: TLabel
          Left = 14
          Top = 47
          Width = 42
          Height = 12
          Caption = #32452#21512#38190':'
        end
        object HotKeyModCheckListBox: TCheckListBox
          Left = 62
          Top = 47
          Width = 186
          Height = 29
          Columns = 2
          ItemHeight = 12
          Items.Strings = (
            'Ctrl'
            'Alt'
            'Shift'
            'Win')
          TabOrder = 1
        end
        object BaseHotKey: THotKey
          Left = 62
          Top = 21
          Width = 186
          Height = 19
          InvalidKeys = [hcNone, hcShift, hcCtrl, hcAlt, hcShiftCtrl, hcShiftAlt, hcCtrlAlt, hcShiftCtrlAlt]
          Modifiers = []
          TabOrder = 0
        end
      end
    end
    object TabSheet1: TTabSheet
      Caption = #25554#20837#25991#26412
      ImageIndex = 2
      object Label3: TLabel
        Left = 10
        Top = 134
        Width = 42
        Height = 12
        Caption = #33258#23450#20041':'
      end
      object Bevel1: TBevel
        Left = 58
        Top = 138
        Width = 213
        Height = 10
        Shape = bsTopLine
      end
      object InsLineEdit: TLabeledEdit
        Left = 10
        Top = 22
        Width = 261
        Height = 20
        EditLabel.Width = 42
        EditLabel.Height = 12
        EditLabel.Caption = #20998#38548#34892':'
        TabOrder = 0
      end
      object InsDateEdit: TLabeledEdit
        Left = 10
        Top = 62
        Width = 261
        Height = 20
        EditLabel.Width = 54
        EditLabel.Height = 12
        EditLabel.Caption = #26085#26399#26102#38388':'
        TabOrder = 1
      end
      object InsLineDateEdit: TLabeledEdit
        Left = 10
        Top = 102
        Width = 261
        Height = 20
        EditLabel.Width = 90
        EditLabel.Height = 12
        EditLabel.Caption = #26085#26399#26102#38388#20998#38548#34892':'
        TabOrder = 2
      end
      object InsCustomListBox: TListBox
        Left = 10
        Top = 152
        Width = 211
        Height = 67
        ItemHeight = 12
        TabOrder = 3
        OnDblClick = InsCustomModifyButtonClick
      end
      object InsCustomAddButton: TButton
        Left = 226
        Top = 152
        Width = 45
        Height = 21
        Caption = #28155#21152
        TabOrder = 4
        OnClick = InsCustomAddButtonClick
      end
      object InsCustomDeleteButton: TButton
        Left = 226
        Top = 198
        Width = 45
        Height = 21
        Caption = #21024#38500
        TabOrder = 6
        OnClick = InsCustomDeleteButtonClick
      end
      object InsCustomModifyButton: TButton
        Left = 226
        Top = 175
        Width = 45
        Height = 21
        Caption = #20462#25913
        TabOrder = 5
        OnClick = InsCustomModifyButtonClick
      end
    end
  end
end
