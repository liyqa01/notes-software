unit ConfigFrm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, BaseFrm, StdCtrls, CheckLst, ComCtrls, SysHotKey, ExtCtrls, Menus;

type

  TConfigPageType = (cptGeneral, cptHotKey, cptInsText);

  TConfigForm = class(TBaseForm)
    OkButton: TButton;
    CancelButton: TButton;
    PageControl: TPageControl;
    GeneralTabSheet: TTabSheet;
    HotKeyTabSheet: TTabSheet;
    GroupBox1: TGroupBox;
    RunOnStartupCheckBox: TCheckBox;
    MinOnCloseCheckBox: TCheckBox;
    GroupBox2: TGroupBox;
    Label1: TLabel;
    Label2: TLabel;
    HotKeyModCheckListBox: TCheckListBox;
    BaseHotKey: THotKey;
    DblClickTitleRadioGroup: TRadioGroup;
    TabSheet1: TTabSheet;
    InsLineEdit: TLabeledEdit;
    InsDateEdit: TLabeledEdit;
    InsLineDateEdit: TLabeledEdit;
    InsCustomListBox: TListBox;
    InsCustomAddButton: TButton;
    InsCustomDeleteButton: TButton;
    InsCustomModifyButton: TButton;
    Label3: TLabel;
    Bevel1: TBevel;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure OkButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure InsCustomAddButtonClick(Sender: TObject);
    procedure InsCustomModifyButtonClick(Sender: TObject);
    procedure InsCustomDeleteButtonClick(Sender: TObject);
  private
    procedure SetDataToUI;
    procedure GetDataFromUI;
  public
  end;

function ShowConfigForm(PageType: TConfigPageType = cptGeneral): Boolean;

implementation

uses Global, AppConfigMgr, AppUtils, MsgBox, InputMemoFrm;

{$R *.dfm}

function ShowConfigForm(PageType: TConfigPageType): Boolean;
var
  Form: TConfigForm;
begin
  Form := TConfigForm.Create(GetMainForm);
  try
    Form.PageControl.ActivePageIndex := Ord(PageType);
    Form.SetDataToUI;
    Result := (Form.ShowModal = mrOk);
    if Result then Form.GetDataFromUI;
  finally
    Form.Free;
  end;
end;

{ TConfigForm }

procedure TConfigForm.FormCreate(Sender: TObject);
begin
  PageControl.ActivePageIndex := 0;
  ActiveControl := RunOnStartupCheckBox;
end;

procedure TConfigForm.FormDestroy(Sender: TObject);
begin
//
end;

procedure TConfigForm.SetDataToUI;
begin
  RunOnStartupCheckBox.Checked := ConfigMgr.RunOnStartup;
  MinOnCloseCheckBox.Checked := ConfigMgr.MinOnClose;
  DblClickTitleRadioGroup.ItemIndex := Ord(ConfigMgr.DblClickTitleActionType);
  BaseHotKey.HotKey := TSysHotKey.VirtualKeyToShortCut(ConfigMgr.HotKeyBase);
  HotKeyModCheckListBox.Checked[0] := moControl in ConfigMgr.HotKeyModifiers;
  HotKeyModCheckListBox.Checked[1] := moAlt in ConfigMgr.HotKeyModifiers;
  HotKeyModCheckListBox.Checked[2] := moShift in ConfigMgr.HotKeyModifiers;
  HotKeyModCheckListBox.Checked[3] := moWin in ConfigMgr.HotKeyModifiers;
  InsLineEdit.Text := ConfigMgr.InsertLineText;
  InsDateEdit.Text := ConfigMgr.InsertDateText;
  InsLineDateEdit.Text := ConfigMgr.InsertLineDateText;
  InsCustomListBox.Items := ConfigMgr.InsertCustomList;
end;

procedure TConfigForm.GetDataFromUI;
begin
  ConfigMgr.RunOnStartup := RunOnStartupCheckBox.Checked;
  ConfigMgr.MinOnClose := MinOnCloseCheckBox.Checked;
  ConfigMgr.DblClickTitleActionType := TDblClickTitleActionType(DblClickTitleRadioGroup.ItemIndex);
  ConfigMgr.HotKeyBase := TSysHotKey.ShortCutToVirtualKey(BaseHotKey.HotKey);
  ConfigMgr.HotKeyModifiers := [];
  if HotKeyModCheckListBox.Checked[0] then
    ConfigMgr.HotKeyModifiers := ConfigMgr.HotKeyModifiers + [moControl];
  if HotKeyModCheckListBox.Checked[1] then
    ConfigMgr.HotKeyModifiers := ConfigMgr.HotKeyModifiers + [moAlt];
  if HotKeyModCheckListBox.Checked[2] then
    ConfigMgr.HotKeyModifiers := ConfigMgr.HotKeyModifiers + [moShift];
  if HotKeyModCheckListBox.Checked[3] then
    ConfigMgr.HotKeyModifiers := ConfigMgr.HotKeyModifiers + [moWin];
  ConfigMgr.InsertLineText := InsLineEdit.Text;
  ConfigMgr.InsertDateText := InsDateEdit.Text;
  ConfigMgr.InsertLineDateText := InsLineDateEdit.Text;
  ConfigMgr.InsertCustomList := InsCustomListBox.Items;
end;

procedure TConfigForm.OkButtonClick(Sender: TObject);
begin
  ModalResult := mrOk;
end;

procedure TConfigForm.CancelButtonClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

procedure TConfigForm.InsCustomAddButtonClick(Sender: TObject);
var
  S: string;
begin
  if ShowInputMemoForm(Self, '����', '�������Զ����ı�:', S, False) then
  begin
    S := MultiLineToSingleLine(S);
    InsCustomListBox.Items.Add(S);
  end;
end;

procedure TConfigForm.InsCustomModifyButtonClick(Sender: TObject);
var
  I: Integer;
  S: string;
begin
  I := InsCustomListBox.ItemIndex;
  if I >= 0 then
  begin
    S := InsCustomListBox.Items[I];
    S := SingleLineToMultiLine(S);
    if ShowInputMemoForm(Self, '�޸�', '�������Զ����ı�:', S, False) then
    begin
      S := MultiLineToSingleLine(S);
      InsCustomListBox.Items[I] := S;
    end;
  end;
end;

procedure TConfigForm.InsCustomDeleteButtonClick(Sender: TObject);
var
  I, R: Integer;
begin
  I := InsCustomListBox.ItemIndex;
  if I >= 0 then
  begin
    R := ShowMsgBox(Self, 'ȷʵɾ����',
      mtConfirmation, [mbYes, mbNo], mdDefBtn1);
    if R = mrYes then
      InsCustomListBox.Items.Delete(I);
  end;
end;

end.
