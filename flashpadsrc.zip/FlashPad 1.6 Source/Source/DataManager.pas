unit DataManager;

interface

{$WARN SYMBOL_PLATFORM OFF}

uses
  Windows, SysUtils, Classes, Global;

type

  PPageItem = ^TPageItem;
  TPageItem = record
    PageIndex: Integer;
    FileName: string;
    PageTitle: string;
    PageText: string;
  end;
  TPageItems = array of TPageItem;

{ TDataManager }

  TDataManager = class(TObject)
  private
    FFileNames: TStringList;        // �±�Ϊ PageIndex
  private
    procedure Initialize;
    procedure ReorderPages;
  public
    constructor Create;
    destructor Destroy; override;

    function AddPage(const PageTitle: string): Integer;
    procedure UpdatePage(PageIndex: Integer; const PageTitle, PageText: string);
    procedure RemovePage(PageIndex: Integer; RemoveToRecycle: Boolean);
    procedure RenamePage(PageIndex: Integer; const NewPageTitle: string);
    procedure MovePage(CurPageIndex, NewPageIndex: Integer);
    procedure GetPageList(var List: TPageItems);
  end;

var
  DataMgr: TDataManager;

implementation

uses PubUtils;

{ TDataManager }

constructor TDataManager.Create;
begin
  inherited;
  FFileNames := TStringList.Create;
  Initialize;
end;

destructor TDataManager.Destroy;
begin
  FFileNames.Free;
  inherited;
end;

procedure TDataManager.Initialize;

  function ReadPageIndexFromFile(const FileName: string; var PageIndex: Integer): Boolean;
  const
    MaxReadBytes = 16;
  var
    FileStream: TFileStream;
    BufStr: AnsiString;
    S: string;
    N, I: Integer;
  begin
    FileStream := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);
    try
      SetLength(BufStr, MaxReadBytes);
      N := FileStream.Read(BufStr[1], MaxReadBytes);
      SetLength(BufStr, N);

      if (Length(BufStr) >= 2) and (PWord(@BufStr[1])^ = $FEFF) then  // Unicode BOM
      begin
        Delete(BufStr, 1, 2);
        S := WideCharToString(PWideChar(PAnsiChar(BufStr)));
      end else
        S := string(BufStr);

      I := Pos(#13, S);
      if I > 0 then SetLength(S, I - 1);
      I := Pos(#10, S);
      if I > 0 then SetLength(S, I - 1);
      Result := IsInt(S);
      if Result then
        PageIndex := StrToIntDef(S, 0);
    finally
      FileStream.Free;
    end;
  end;

var
  Sr: TSearchRec;
  DataPath, FileName, S: string;
  IndexList: array of Integer;
  I, J, PageIndex: Integer;
begin
  FFileNames.Clear;
  DataPath := GetAppSubPath(SDataDirName);

  if FindFirst(DataPath + '*.' + SDataFileExt, faAnyFile and not faHidden, Sr) = 0 then
  try
    repeat
      if (Sr.Attr and faDirectory) = 0 then
      begin
        FileName := DataPath + Sr.Name;
        FFileNames.Add(FileName);
      end;
    until (FindNext(Sr) <> 0);
  finally
    FindClose(Sr);
  end;

  SetLength(IndexList, FFileNames.Count);
  for I := 0 to FFileNames.Count - 1 do
  begin
    PageIndex := 0;
    ReadPageIndexFromFile(FFileNames[I], PageIndex);
    IndexList[I] := PageIndex;
  end;

  for I := 0 to Length(IndexList) - 2 do
    for J := I + 1 to Length(IndexList) - 1 do
      if IndexList[I] > IndexList[J] then
      begin
        S := FFileNames[I];
        FFileNames[I] := FFileNames[J];
        FFileNames[J] := S;
        Swap(IndexList[I], IndexList[J]);
      end;

  for I := 0 to Length(IndexList) - 1 do
    if IndexList[I] <> I then
    begin
      ReorderPages;
      Break;
    end;
end;

procedure TDataManager.ReorderPages;
var
  I: Integer;
  FileLines: TStringList;
begin
  FileLines := TStringList.Create;
  try
    for I := 0 to FFileNames.Count - 1 do
    begin
      FileLines.LoadFromFile(FFileNames[I]);
      FileLines[0] := IntToStr(I);
      FileLines.SaveToFile(FFileNames[I], TEncoding.Unicode);
    end;
  finally
    FileLines.Free;
  end;
end;

function TDataManager.AddPage(const PageTitle: string): Integer;

  function MakeUniqueFileNameAtPath(const Path: string): string;
  var
    Guid: TGUID;
  begin
    while True do
    begin
      CreateGuid(Guid);
      Result := PathWithSlash(Path) + GuidToString(Guid) + '.' + SDataFileExt;
      if not FileExists(Result) then Break;
    end;
  end;

var
  FileName: string;
begin
  FileName := MakeUniqueFileNameAtPath(GetAppSubPath(SDataDirName));
  FFileNames.Add(FileName);
  Result := FFileNames.Count - 1;
  UpdatePage(Result, PageTitle, '');
end;

procedure TDataManager.UpdatePage(PageIndex: Integer;
  const PageTitle, PageText: string);
var
  FileName: string;
  FileLines: TStringList;
begin
  if (PageIndex >= 0) and (PageIndex < FFileNames.Count) then
  begin
    FileName := FFileNames[PageIndex];
    FileLines := TStringList.Create;
    try
      FileLines.Text := PageText;
      FileLines.Insert(0, IntToStr(PageIndex));
      FileLines.Insert(1, PageTitle);
      FileLines.Insert(2, '');

      ForceDirectories(ExtractFilePath(FileName));
      FileLines.SaveToFile(FileName, TEncoding.Unicode);
    finally
      FileLines.Free;
    end;
  end;
end;

procedure TDataManager.RemovePage(PageIndex: Integer; RemoveToRecycle: Boolean);
var
  FileName: string;
begin
  if (PageIndex >= 0) and (PageIndex < FFileNames.Count) then
  begin
    FileName := FFileNames[PageIndex];
    if RemoveToRecycle then
      DeleteFileToRecycle(FileName)
    else
      DeleteFile(FileName);
    FFileNames.Delete(PageIndex);
    ReorderPages;
  end;
end;

procedure TDataManager.RenamePage(PageIndex: Integer; const NewPageTitle: string);
var
  FileLines: TStringList;
begin
  if (PageIndex >= 0) and (PageIndex < FFileNames.Count) then
  begin
    FileLines := TStringList.Create;
    try
      FileLines.LoadFromFile(FFileNames[PageIndex]);
      if FileLines.Count >= 2 then
        FileLines[1] := NewPageTitle;
      FileLines.SaveToFile(FFileNames[PageIndex], TEncoding.Unicode);
    finally
      FileLines.Free;
    end;
  end;
end;

procedure TDataManager.MovePage(CurPageIndex, NewPageIndex: Integer);
begin
  if (CurPageIndex >= 0) and (CurPageIndex < FFileNames.Count) and
     (NewPageIndex >= 0) and (NewPageIndex < FFileNames.Count) and
     (CurPageIndex <> NewPageIndex) then
  begin
    FFileNames.Move(CurPageIndex, NewPageIndex);
    ReorderPages;
  end;
end;

procedure TDataManager.GetPageList(var List: TPageItems);
var
  I: Integer;
  FileLines: TStringList;
begin
  FileLines := TStringList.Create;
  try
    SetLength(List, FFileNames.Count);
    for I := 0 to Length(List) - 1 do
    begin
      List[I].PageIndex := I;
      List[I].FileName := FFileNames[I];

      FileLines.LoadFromFile(FFileNames[I]);
      List[I].PageTitle := FileLines[1];

      FileLines.Delete(0);
      FileLines.Delete(0);
      FileLines.Delete(0);

      List[I].PageText := FileLines.Text;
    end;
  finally
    FileLines.Free;
  end;
end;

initialization
  DataMgr := TDataManager.Create;

finalization
  DataMgr.Free;

end.
