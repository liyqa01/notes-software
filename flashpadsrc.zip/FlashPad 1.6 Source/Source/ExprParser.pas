unit ExprParser;

interface

uses
  Classes, SysUtils, Math, StrUtils;

type

{ Types }

  // �ʷ���λ
  TExprToken = (
    etUnknown, etSymbol, etNumber, etString, etLParen, etRParen,
    etEQ, etNE, etGE, etLE, etGT, etLT, etAdd, etSub, etMul, etDiv,
    etComma, etEnd
    );

  // ����ʽ������
  TExprOperator = (
    eoUnknown, eoEQ, eoNE, eoGE, eoLE, eoGT, eoLT, eoNot, eoAnd, eoOr,
    eoAdd, eoSub, eoMul, eoDiv
    );

  // ����
  TExprFuncType = (
    efUnknown, efUpper, efLower, efSubStr, efTrim, efTrimLeft, efTrimRight,
    efAscii, efChar, efLeft, efRight, efLen, efChars, efCrLf,
    efDate, efTime, efNow, efAbs, efPi, efRound, efPower, efSqrt, efFloor
    );

  // ����ʽ�ڵ�����
  TExprNodeKind = (nkConstant, nkFunction, nkOperator);

  // ��������
  TExprDataType = (dtUnknown, dtString, dtInteger, dtFloat, dtBoolean);

  TStrCompOption = (scCaseInsensitive);
  TStrCompOptions = set of TStrCompOption;

{ Classes }

  TExprNode = class;
  TExprNodes = class;
  TExprScanner = class;
  TExprParser = class;
  TExprFunctions = class;

{ Exception Classes }

  EExprException = class(Exception)
  private
    FErrorCode: Integer;
  public
    constructor Create(ErrorCode: Integer; const Message: string);
    destructor Destroy; override;
    property ErrorCode: Integer read FErrorCode;
  end;

{ TExprNode }

  TExprNode = class(TObject)
  private
    FExprNodes: TExprNodes;
    FNext: TExprNode;
    FKind: TExprNodeKind;
    FOperator: TExprOperator;
    FFuncType: TExprFuncType;
    FSymbol: string;
    FData: PChar;
    FDataSize: Integer;
    FDataType: TExprDataType;
    FLeft: TExprNode;
    FRight: TExprNode;
    FArgs: TList;
  private
    procedure SetDataSize(Size: Integer);
  public
    constructor Create(ExprNodes: TExprNodes);
    destructor Destroy; override;

    procedure Evaluate(Options: TStrCompOptions);
    procedure EvaluateOperator(ResultNode: TExprNode; ExprOperator: TExprOperator;
      LeftNode, RightNode: TExprNode; ArgNodes: TList; Options: TStrCompOptions);
    procedure EvaluateFunction(ResultNode: TExprNode; FuncType: TExprFuncType; ArgNodes: TList);

    function IsIntegerType: Boolean;
    function IsFloatType: Boolean;
    function IsStringType: Boolean;
    function IsBooleanType: Boolean;
    function IsNumericType: Boolean;
    function IsTemporalStringType: Boolean;

    function GetNumericValue: Double;
    procedure SetNumbericValue(DataType: TExprDataType; Value: Double);

    function AsValue: Variant;
    function AsValueString: string;
    function AsDisplayString: string;

    property DataSize: Integer read FDataSize write SetDataSize;
  end;

{ TExprNodes }

  TExprNodes = class(TObject)
  private
    FExprParser: TExprParser;
    FNodes: TExprNode;
    FRoot: TExprNode;
  public
    constructor Create(AExprParser: TExprParser);
    destructor Destroy; override;
    procedure Clear;
    function NewNode(NodeKind: TExprNodeKind; DataType: TExprDataType;
      ADataSize: Integer; ExprOperator: TExprOperator; Left, Right: TExprNode): TExprNode;
    function NewFuncNode(const FuncName: string): TExprNode;

    property Root: TExprNode read FRoot write FRoot;
  end;

{ TExprScanner - ����ʽ�ʷ������� }

  TExprScanner = class(TObject)
  private
    FSourceText: string;
    FTokenString: string;
    FToken: TExprToken;
    FPrevToken: TExprToken;
    FSourcePtr: PChar;
    FTokenPtr: PChar;

    procedure SetSourceText(const Value: string);
    function GetTokenDisplayStr: string;
    procedure Skip(var P: PChar; ChrSet: TSysCharSet);
  protected
    function SkipBeforeGetToken(SourcePtr: PChar): PChar; virtual;
    function DoGetNextToken(SourcePtr: PChar; var Token: TExprToken;
      var TokenString: string): PChar; virtual;
  public
    constructor Create;
    destructor Destroy; override;

    procedure GetNextToken;
    procedure PeekNextToken(var Token: TExprToken; var TokenString: string);
    procedure Rewind;
    function TokenSymbolIs(const S: string): Boolean;

    property SourceText: string read FSourceText write SetSourceText;
    property Token: TExprToken read FToken;
    property TokenString: string read FTokenString;
    property TokenDisplayStr: string read GetTokenDisplayStr;
  end;

{ TExprParser - ����ʽ�﷨������ }

  TExprParser = class(TObject)
  protected
    FScanner: TExprScanner;
    FExprNodes: TExprNodes;
    FStrCompOptions: TStrCompOptions;

    function ParseStart: TExprNode;
    function ParseExpr1: TExprNode;
    function ParseExpr2: TExprNode;
    function ParseExpr3: TExprNode;
    function ParseExpr4: TExprNode;
    function ParseExpr5: TExprNode;
    function ParseExpr6: TExprNode;
    function ParseExpr7: TExprNode;
    procedure ParseFinished;
    procedure CheckTypeForArithOp(Node: TExprNode);
    procedure CheckTypeForLogicOp(Node: TExprNode);
    procedure CheckTypeForRelationOp(Node: TExprNode);
    procedure CheckTypeForFunction(Node: TExprNode);

    function GetVariableDataType(const Name: string): TExprDataType;
    function GetVariableValue(const Name: string): Variant;
  protected
    procedure Parse(const ExprText: string);
    procedure Evaluate;
  public
    constructor Create;
    destructor Destroy; override;

    procedure Execute(const ExprText: string);

    function GetResultValue: Variant;
    function GetResultAsString: string;
    function GetResultForDisplay: string;

    property StrCompOptions: TStrCompOptions read FStrCompOptions write FStrCompOptions;
  end;

{ TExprFunctions - ����ʽ���� }

  TExprFunctions = class(TObject)
  public
    class function GetFunctionName(FuncType: TExprFuncType): string;
    class function GetFunctionType(const FuncName: string): TExprFuncType;
    class function FunctionExists(const FuncName: string): Boolean;
    class function GetFuncDataType(FuncType: TExprFuncType): TExprDataType;
    class procedure CheckTypeForFunction(FuncType: TExprFuncType; ArgNodes: TList);
    class procedure EvaluateFunction(ResultNode: TExprNode; FuncType: TExprFuncType; ArgNodes: TList);
  end;

implementation

const
  SStrQuoteChar = '''';
  SCrLf = #13#10;

  // Error Codes
  ieExprInvalid                 = 4000;
  ieExprInvalidChar             = 4001;
  ieExprUntermVariableName      = 4002;
  ieExprUntermStrConst          = 4003;
  ieExprTerminationError        = 4004;
  ieExprNoLParen                = 4005;
  ieExprNoRParen                = 4006;
  ieExprNoRParenOrComma         = 4007;
  ieExprExpected                = 4008;
  ieExprTypeMismatch            = 4009;
  ieExprFuncArgCountError       = 4010;

  // Error Messages
  SExprInvalid = '����ʽ�﷨����';
  SExprInvalidChar = '����ʽ�г��ֲ���ȷ���ַ� ''%s''��';
  SExprUntermVariableName = '������ȱ���ս����';
  SExprUntermStrConst = '�ַ���ȱ���ս����';
  SExprTerminationError = '����ʽ��ĩβ�﷨����';
  SExprNoLParen = '�˴� "%s" ӦΪ ''(''��';
  SExprNoRParen = '�˴� "%s" ӦΪ '')''��';
  SExprNoRParenOrComma = '�˴� "%s" ӦΪ '')'' �� '',''��';
  SExprExpected = '�˴� %s ���﷨����';
  SExprTypeMismatch = '���Ͳ�ƥ�䡣';
  SExprFuncArgCountError = '����������������';

{ Misc Routines }

//-----------------------------------------------------------------------------
// ����: �׳�һ�����ݿ��쳣
//-----------------------------------------------------------------------------
procedure RaiseExprError(ErrorCode: Integer; const Message: string);
begin
  raise EExprException.Create(ErrorCode,
    Format('����ʽ����: %s', [Message]));
end;

//-----------------------------------------------------------------------------
// ����: �׳�һ�����ݿ��쳣
//-----------------------------------------------------------------------------
procedure RaiseExprErrorFmt(ErrorCode: Integer; const Message: string;
  const Args: array of const);
begin
  RaiseExprError(ErrorCode, Format(Message, Args));
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� S �ǲ���һ����������
//-----------------------------------------------------------------------------
function IsInt(const S: string): Boolean;
var
  E, R: Integer;
begin
  Val(S, R, E);
  Result := E = 0;
  E := R; // avoid hints
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� S �ǲ���һ������������
//-----------------------------------------------------------------------------
function IsFloat(const S: string): boolean;
var
  V: Extended;
begin
  Result := TextToFloat(PChar(S), V, fvExtended);
end;

//-----------------------------------------------------------------------------
// ����: �൱��C�����е� exp ? v1 : v2
//-----------------------------------------------------------------------------
function Iif(Value: Boolean; Value1, Value2: Variant): Variant;
begin
  if Value then Result := Value1
  else Result := Value2;
end;

//-----------------------------------------------------------------------------
// ����: У���ȽϽ��ֵ
//-----------------------------------------------------------------------------
function VerifyCompareResult(Value: Integer): Integer;
begin
  Result := Value;
  if Result > 0 then
    Result := 1
  else if Result < 0 then
    Result := -1;
end;

//-----------------------------------------------------------------------------
// ����: �Ƚ��ַ���
// ����:
//   S1              - �ַ���һ
//   S2              - �ַ�����
//   CaseInsensitive - �Ƿ���Դ�Сд
// ����:
//   -1    - S1 < S2
//    0    - S1 = S2
//    1    - S1 > S2
//-----------------------------------------------------------------------------
function CompareExprStr(const S1, S2: string; CaseInsensitive: Boolean): Integer;
begin
  if CaseInsensitive then
    Result := CompareText(S1, S2)
  else
    Result := CompareStr(S1, S2);
  Result := VerifyCompareResult(Result);
end;

//-----------------------------------------------------------------------------
// ����: ȡ���������͵Ĵ�С
//-----------------------------------------------------------------------------
function GetDataTypeSize(DataType: TExprDataType): Integer;
begin
  Result := 0;
  case DataType of
    dtBoolean:     Result := SizeOf(Boolean);
    dtInteger:     Result := SizeOf(Int64);
    dtFloat:       Result := SizeOf(Double);
  end;
end;

{ EExprException }

constructor EExprException.Create(ErrorCode: Integer; const Message: string);
begin
  inherited Create(Message);
  FErrorCode := ErrorCode;
end;

destructor EExprException.Destroy;
begin
  inherited;
end;

{ TExprNode }

constructor TExprNode.Create(ExprNodes: TExprNodes);
begin
  FExprNodes := ExprNodes;
  FArgs := nil;
end;

destructor TExprNode.Destroy;
begin
  if FArgs <> nil then FArgs.Free;
  SetDataSize(0);
  inherited;
end;

procedure TExprNode.SetDataSize(Size: Integer);
begin
  if Size < 0 then Size := 0;
  if FDataSize <> Size then
  begin
    if Size > 0 then
    begin
      if FDataSize = 0 then
        FData := AllocMem(Size)
      else
        ReallocMem(FData, Size);
    end else
    begin
      FreeMem(FData);
    end;
    FDataSize := Size;
  end;
end;

procedure TExprNode.Evaluate(Options: TStrCompOptions);
var
  I: Integer;
begin
  case FKind of
    nkFunction:
      begin
        if FArgs <> nil then
        begin
          for I := 0 to FArgs.Count - 1 do
            TExprNode(FArgs[I]).Evaluate(Options);
        end;
        EvaluateFunction(Self, FFuncType, FArgs);
      end;
    nkOperator:
      begin
        case FOperator of
          eoOr:
            begin
              FLeft.Evaluate(Options);
              if not PBoolean(FLeft.FData)^ then FRight.Evaluate(Options);
              EvaluateOperator(Self, FOperator, FLeft, FRight, nil, Options);
            end;
          eoAnd:
            begin
              FLeft.Evaluate(Options);
              if PBoolean(FLeft.FData)^ then FRight.Evaluate(Options);
              EvaluateOperator(Self, FOperator, FLeft, FRight, nil, Options);
            end;
          eoNot:
            begin
              FLeft.Evaluate(Options);
              EvaluateOperator(Self, FOperator, FLeft, FRight, nil, Options);
            end;
          eoEQ, eoNE, eoGT, eoLT, eoGE, eoLE,
          eoAdd, eoSub, eoMul, eoDiv:
            begin
              FLeft.Evaluate(Options);
              FRight.Evaluate(Options);
              EvaluateOperator(Self, FOperator, FLeft, FRight, nil, Options);
            end;
        end;
      end;
  end;
end;

procedure TExprNode.EvaluateOperator(ResultNode: TExprNode; ExprOperator: TExprOperator;
  LeftNode, RightNode: TExprNode; ArgNodes: TList; Options: TStrCompOptions);
begin
  case ExprOperator of
    eoOr:
      begin
        if PBoolean(LeftNode.FData)^ then
          PBoolean(ResultNode.FData)^ := True
        else
          PBoolean(ResultNode.FData)^ := PBoolean(RightNode.FData)^;
      end;
    eoAnd:
      begin
        if PBoolean(LeftNode.FData)^ then
          PBoolean(ResultNode.FData)^ := PBoolean(RightNode.FData)^
        else
          PBoolean(ResultNode.FData)^ := False;
      end;
    eoNot:
      begin
        PBoolean(ResultNode.FData)^ := not PBoolean(LeftNode.FData)^;
      end;
    eoEQ:   //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtBoolean:
            PBoolean(ResultNode.FData)^ := PBoolean(LeftNode.FData)^ = PBoolean(RightNode.FData)^;
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ = PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ = PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ = PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ = PDouble(RightNode.FData)^;
            end;
          dtString:
            case RightNode.FDataType of
              dtString:
                PBoolean(ResultNode.FData)^ := CompareExprStr(
                  LeftNode.FData, RightNode.FData,
                  scCaseInsensitive in Options) = 0;
            end;
        end;
      end;
    eoNE:   //-----------------------------------------------------------------
      begin
        EvaluateOperator(ResultNode, eoEQ, LeftNode, RightNode, nil, Options);
        PBoolean(ResultNode.FData)^ := not PBoolean(ResultNode.FData)^;
      end;
    eoGT:   //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtBoolean:
            PBoolean(ResultNode.FData)^ := PBoolean(LeftNode.FData)^ > PBoolean(RightNode.FData)^;
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ > PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ > PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ > PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ > PDouble(RightNode.FData)^;
            end;
          dtString:
            case RightNode.FDataType of
              dtString:
                PBoolean(ResultNode.FData)^ := CompareExprStr(
                  LeftNode.FData, RightNode.FData,
                  scCaseInsensitive in Options) > 0;
            end;
        end;
      end;
    eoLT:   //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtBoolean:
            PBoolean(ResultNode.FData)^ := PBoolean(LeftNode.FData)^ < PBoolean(RightNode.FData)^;
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ < PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PInt64(LeftNode.FData)^ < PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ < PInt64(RightNode.FData)^;
              dtFloat:
                PBoolean(ResultNode.FData)^ := PDouble(LeftNode.FData)^ < PDouble(RightNode.FData)^;
            end;
          dtString:
            case RightNode.FDataType of
              dtString:
                PBoolean(ResultNode.FData)^ := CompareExprStr(
                  LeftNode.FData, RightNode.FData,
                  scCaseInsensitive in Options) < 0;
            end;
        end;
      end;
    eoGE:   //-----------------------------------------------------------------
      begin
        EvaluateOperator(ResultNode, eoLT, LeftNode, RightNode, nil, Options);
        PBoolean(ResultNode.FData)^ := not PBoolean(ResultNode.FData)^;
      end;
    eoLE:   //-----------------------------------------------------------------
      begin
        EvaluateOperator(ResultNode, eoGT, LeftNode, RightNode, nil, Options);
        PBoolean(ResultNode.FData)^ := not PBoolean(ResultNode.FData)^;
      end;
    eoAdd:  //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PInt64(ResultNode.FData)^ := PInt64(LeftNode.FData)^ + PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PInt64(LeftNode.FData)^ + PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ + PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ + PDouble(RightNode.FData)^;
            end;
          dtString:
            case RightNode.FDataType of
              dtString:
                begin
                  ResultNode.DataSize := (StrLen(LeftNode.FData) + StrLen(RightNode.FData) + 1) * SizeOf(Char);
                  StrCopy(ResultNode.FData, LeftNode.FData);
                  StrCat(ResultNode.FData, RightNode.FData);
                end;
            end;
        end;
      end;
    eoSub:  //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PInt64(ResultNode.FData)^ := PInt64(LeftNode.FData)^ - PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PInt64(LeftNode.FData)^ - PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ - PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ - PDouble(RightNode.FData)^;
            end;
        end;
      end;
    eoMul:  //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PInt64(ResultNode.FData)^ := PInt64(LeftNode.FData)^ * PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PInt64(LeftNode.FData)^ * PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ * PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ * PDouble(RightNode.FData)^;
            end;
        end;
      end;
    eoDiv:  //-----------------------------------------------------------------
      begin
        case LeftNode.FDataType of
          dtInteger:
            case RightNode.FDataType of
              dtInteger:
                PDouble(ResultNode.FData)^ := PInt64(LeftNode.FData)^ / PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PInt64(LeftNode.FData)^ / PDouble(RightNode.FData)^;
            end;
          dtFloat:
            case RightNode.FDataType of
              dtInteger:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ / PInt64(RightNode.FData)^;
              dtFloat:
                PDouble(ResultNode.FData)^ := PDouble(LeftNode.FData)^ / PDouble(RightNode.FData)^;
            end;
        end;
      end;
  end;
end;

procedure TExprNode.EvaluateFunction(ResultNode: TExprNode;
  FuncType: TExprFuncType; ArgNodes: TList);
begin
  TExprFunctions.EvaluateFunction(ResultNode, FuncType, ArgNodes);
end;

function TExprNode.IsIntegerType: Boolean;
begin
  Result := FDataType in [dtInteger];
end;

function TExprNode.IsFloatType: Boolean;
begin
  Result := FDataType in [dtFloat];
end;

function TExprNode.IsStringType: Boolean;
begin
  Result := (FDataType in [dtString]);
end;

function TExprNode.IsBooleanType: Boolean;
begin
  Result := (FDataType in [dtBoolean]);
end;

function TExprNode.IsNumericType: Boolean;
begin
  Result := IsIntegerType or IsFloatType;
end;

function TExprNode.IsTemporalStringType: Boolean;
var
  TempStr: string;
begin
  TempStr := FData;
  Result := IsStringType and (FKind = nkConstant);
  if Result then
  begin
    Result := True;
    try
      StrToDateTime(TempStr);
    except
      Result := False;
    end;
  end;
end;

function TExprNode.GetNumericValue: Double;
begin
  if IsIntegerType then
    Result := PInt64(FData)^
  else if IsFloatType then
    Result := PDouble(FData)^
  else
    Result := 0;
end;

procedure TExprNode.SetNumbericValue(DataType: TExprDataType; Value: Double);
begin
  Assert(DataType in [dtInteger, dtFloat]);

  FDataType := DataType;
  DataSize := GetDataTypeSize(DataType);

  if DataType = dtInteger then
    PInt64(FData)^ := Trunc(Value)
  else if DataType = dtFloat then
    PDouble(FData)^ := Value;
end;

function TExprNode.AsValue: Variant;
begin
  Result := '';
  if (FData <> nil) and (FDataSize > 0) then
  begin
    case FDataType of
      dtString:    Result := string(PChar(FData));
      dtInteger:   Result := PInt64(FData)^;
      dtFloat:     Result := PDouble(FData)^;
      dtBoolean:   Result := PBoolean(FData)^;
    end;
  end;
end;

function TExprNode.AsValueString: string;
begin
  Result := string(AsValue);
end;

function TExprNode.AsDisplayString: string;
begin
  Result := AsValueString;
  if IsStringType then
    Result := QuotedStr(Result);
end;

{ TExprNodes }

constructor TExprNodes.Create(AExprParser: TExprParser);
begin
  FExprParser := AExprParser;
  FNodes := nil;
  FRoot := nil;
end;

destructor TExprNodes.Destroy;
begin
  Clear;
  inherited;
end;

procedure TExprNodes.Clear;
var
  Node: TExprNode;
begin
  while FNodes <> nil do
  begin
    Node := FNodes;
    FNodes := Node.FNext;
    Node.Free;
  end;
  FNodes := nil;
end;

function TExprNodes.NewNode(NodeKind: TExprNodeKind; DataType: TExprDataType;
  ADataSize: Integer; ExprOperator: TExprOperator; Left, Right: TExprNode): TExprNode;
begin
  Result := TExprNode.Create(Self);
  with Result do
  begin
    FNext := FNodes;

    FKind := NodeKind;
    FDataType := DataType;
    DataSize := ADataSize;
    FOperator := ExprOperator;
    FLeft := Left;
    FRight := Right;
  end;
  FNodes := Result;
end;

function TExprNodes.NewFuncNode(const FuncName: string): TExprNode;
begin
  Result := TExprNode.Create(Self);
  with Result do
  begin
    FNext := FNodes;

    FKind := nkFunction;
    FFuncType := TExprFunctions.GetFunctionType(FuncName);
    FDataType := TExprFunctions.GetFuncDataType(FFuncType);
    DataSize := 0;
    FSymbol := FuncName;
    FOperator := eoUnknown;
    FLeft := nil;
    FRight := nil;
  end;
  FNodes := Result;
end;

{ TExprScanner }

constructor TExprScanner.Create;
begin
  inherited;
end;

destructor TExprScanner.Destroy;
begin
  inherited;
end;

procedure TExprScanner.SetSourceText(const Value: string);
begin
  FSourceText := Value;
  FSourcePtr := PChar(FSourceText);
end;

function TExprScanner.GetTokenDisplayStr: string;
begin
  if FSourcePtr = FTokenPtr then
    Result := FSourceText
  else
    SetString(Result, FTokenPtr, FSourcePtr - FTokenPtr);
  Result := '''' + Result + '''';
end;

procedure TExprScanner.Skip(var P: PChar; ChrSet: TSysCharSet);
begin
  while True do
  begin
    if CharInSet(P^, ChrSet) then
      Inc(P)
    else
      Exit;
  end;
end;

function TExprScanner.SkipBeforeGetToken(SourcePtr: PChar): PChar;
var
  P: PChar;
begin
  P := SourcePtr;
  while (P^ <> #0) and (P^ <= ' ') do Inc(P);
  Result := P;
end;

function TExprScanner.DoGetNextToken(SourcePtr: PChar; var Token: TExprToken;
  var TokenString: string): PChar;
var
  P, TokenStart: PChar;
  L: Integer;
  StrBuf: array[0..255] of Char;
begin
  P := SourcePtr;
  case Char(P^) of
    'A'..'Z', 'a'..'z', '_':
      begin
        TokenStart := P;
        Skip(P, ['A'..'Z', 'a'..'z', '0'..'9', '_']);
        SetString(TokenString, TokenStart, P - TokenStart);
        Token := etSymbol;
      end;
    SStrQuoteChar:
      begin
        Inc(P);
        L := 0;
        while True do
        begin
          if P^ = #0 then RaiseExprError(ieExprUntermStrConst, SExprUntermStrConst);
          if P^ = SStrQuoteChar then
          begin
            Inc(P);
            if P^ <> SStrQuoteChar then Break;
          end;
          if L < SizeOf(StrBuf) then
          begin
            StrBuf[L] := P^;
            Inc(L);
          end;
          Inc(P);
        end;
        SetString(TokenString, StrBuf, L);
        Token := etString;
      end;
    '-', '0'..'9':
      begin
        if (P^ = '-') and
           ((FPrevToken = etString) or (FPrevToken = etNumber) or
           (FPrevToken = etSymbol) or (FPrevToken = etRParen)) then
        begin
          Token := etSub;
          Inc(P);
        end else
        begin
          TokenStart := P;
          Inc(P);
          while CharInSet(P^, ['0'..'9', DecimalSeparator, 'e', 'E', '+', '-']) do
          begin
            if CharInSet(P^, ['+', '-']) and not CharInSet((P-1)^, ['e', 'E'] )
              and (P <> TokenStart) then Break;
            Inc(P);
          end;
          if ((P-1)^ = ',') and (DecimalSeparator = ',') and (P^ = ' ') then Dec(P);
          SetString(TokenString, TokenStart, P - TokenStart);
          Token := etNumber;
        end;
      end;
    '(':
      begin
        Inc(P);
        Token := etLParen;
      end;
    ')':
      begin
        Inc(P);
        Token := etRParen;
      end;
    '<':
      begin
        Inc(P);
        case P^ of
          '=':
            begin
              Inc(P);
              Token := etLE;
            end;
          '>':
            begin
              Inc(P);
              Token := etNE;
            end;
        else
          Token := etLT;
        end;
      end;
    '=':
      begin
        Inc(P);
        Token := etEQ;
      end;
    '>':
      begin
        Inc(P);
        if P^ = '=' then
        begin
          Inc(P);
          Token := etGE;
        end else
          Token := etGT;
      end;
    '+':
      begin
        Inc(P);
        Token := etAdd;
      end;
    '*':
      begin
        Inc(P);
        Token := etMul;
      end;
    '/':
      begin
        Inc(P);
        Token := etDiv;
      end;
    ',':
      begin
        Inc(P);
        Token := etComma;
      end;
    #0:
      Token := etEnd;
    else
      RaiseExprErrorFmt(ieExprInvalidChar, SExprInvalidChar, [P^]);
  end;
  Result := P;
end;

procedure TExprScanner.GetNextToken;
begin
  FPrevToken := FToken;
  FTokenString := '';
  FTokenPtr := SkipBeforeGetToken(FSourcePtr);
  FSourcePtr := DoGetNextToken(FTokenPtr, FToken, FTokenString);
end;

procedure TExprScanner.PeekNextToken(var Token: TExprToken;
  var TokenString: string);
var
  SourcePtr: PChar;
begin
  Token := etUnknown;
  TokenString := '';

  SourcePtr := FSourcePtr;
  SourcePtr := SkipBeforeGetToken(SourcePtr);
  DoGetNextToken(SourcePtr, Token, TokenString);
end;

procedure TExprScanner.Rewind;
begin
  FSourcePtr := PChar(FSourceText);
  FTokenPtr := FSourcePtr;
  FTokenString := '';
  FPrevToken := etUnknown;
end;

function TExprScanner.TokenSymbolIs(const S: string): Boolean;
begin
  Result := (FToken = etSymbol) and SameText(FTokenString, S);
end;

{ TExprParser }

constructor TExprParser.Create;
begin
  inherited;
  FScanner := TExprScanner.Create;
  FExprNodes := TExprNodes.Create(Self);
end;

destructor TExprParser.Destroy;
begin
  FExprNodes.Free;
  FScanner.Free;
  inherited;
end;

function TExprParser.ParseStart: TExprNode;
begin
  Result := ParseExpr1;
end;

function TExprParser.ParseExpr1: TExprNode;
begin
  Result := ParseExpr2;
  while FScanner.TokenSymbolIs('OR') do
  begin
    FScanner.GetNextToken;
    Result := FExprNodes.NewNode(nkOperator, dtBoolean,
      GetDataTypeSize(dtBoolean), eoOr, Result, ParseExpr2);
    CheckTypeForLogicOp(Result);
  end;
end;

function TExprParser.ParseExpr2: TExprNode;
begin
  Result := ParseExpr3;
  while FScanner.TokenSymbolIs('AND') do
  begin
    FScanner.GetNextToken;
    Result := FExprNodes.NewNode(nkOperator, dtBoolean,
      GetDataTypeSize(dtBoolean), eoAnd, Result, ParseExpr3);
    CheckTypeForLogicOp(Result);
  end;
end;

function TExprParser.ParseExpr3: TExprNode;
begin
  if FScanner.TokenSymbolIs('NOT') then
  begin
    FScanner.GetNextToken;
    Result := FExprNodes.NewNode(nkOperator, dtBoolean,
      GetDataTypeSize(dtBoolean), eoNot, ParseExpr4, nil);
    CheckTypeForLogicOp(Result);
  end else
    Result := ParseExpr4;
end;

function TExprParser.ParseExpr4: TExprNode;
const
  Operators: array[etEQ..etLT] of TExprOperator = (
    eoEQ, eoNE, eoGE, eoLE, eoGT, eoLT);
var
  ExprOperator: TExprOperator;
  Left, Right: TExprNode;
begin
  Result := ParseExpr5;
  while FScanner.Token in [etEQ..etLT] do
  begin
    case FScanner.Token of
      etEQ..etLT:
        ExprOperator := Operators[FScanner.Token];
      else
        ExprOperator := eoUnknown;
    end;
    FScanner.GetNextToken;
    Left := Result;
    Right := ParseExpr5;
    Result := FExprNodes.NewNode(nkOperator, dtBoolean,
      GetDataTypeSize(dtBoolean), ExprOperator, Left, Right);
    case ExprOperator of
      eoEQ, eoNE, eoGE, eoLE, eoGT, eoLT:
        CheckTypeForRelationOp(Result);
    end;
  end;
end;

function TExprParser.ParseExpr5: TExprNode;
const
  Operators: array[etAdd..etDiv] of TExprOperator = (
    eoAdd, eoSub, eoMul, eoDiv);
var
  ExprOperator: TExprOperator;
  Left, Right: TExprNode;
begin
  Result := ParseExpr6;
  while FScanner.Token in [etAdd, etSub] do
  begin
    ExprOperator := Operators[FScanner.Token];
    Left := Result;
    FScanner.GetNextToken;
    Right := ParseExpr6;
    Result := FExprNodes.NewNode(nkOperator, dtUnknown, 0, ExprOperator, Left, Right);
    CheckTypeForArithOp(Result);
  end;
end;

function TExprParser.ParseExpr6: TExprNode;
const
  Operators: array[etAdd..etDiv] of TExprOperator = (
    eoAdd, eoSub, eoMul, eoDiv);
var
  ExprOperator: TExprOperator;
  Left, Right: TExprNode;
begin
  Result := ParseExpr7;
  while FScanner.Token in [etMul, etDiv] do
  begin
    ExprOperator := Operators[FScanner.Token];
    Left := Result;
    FScanner.GetNextToken;
    Right := ParseExpr7;
    Result := FExprNodes.NewNode(nkOperator, dtUnknown, 0, ExprOperator, Left, Right);
    CheckTypeForArithOp(Result);
  end;
end;

function TExprParser.ParseExpr7: TExprNode;

  function NextTokenIsLParen: Boolean;
  var
    Token: TExprToken;
    TokenString: string;
  begin
    FScanner.PeekNextToken(Token, TokenString);
    Result := (Token = etLParen);
  end;

var
  FuncName: string;
begin
  case FScanner.Token of
    etSymbol:
      if NextTokenIsLParen and TExprFunctions.FunctionExists(FScanner.TokenString) then
      begin
        FuncName := FScanner.TokenString;
        FScanner.GetNextToken;
        if FScanner.Token <> etLParen then
          RaiseExprErrorFmt(ieExprNoLParen, SExprNoLParen, [FScanner.TokenDisplayStr]);
        FScanner.GetNextToken;
        Result := FExprNodes.NewFuncNode(FuncName);
        if FScanner.Token <> etRParen then
        begin
          Result.FArgs := TList.Create;
          repeat
            Result.FArgs.Add(ParseStart);
            if (FScanner.Token <> etComma) and (FScanner.Token <> etRParen) then
              RaiseExprErrorFmt(ieExprNoRParenOrComma, SExprNoRParenOrComma, [FScanner.TokenDisplayStr]);
            if FScanner.Token = etComma then FScanner.GetNextToken;
          until (FScanner.Token = etRParen) or (FScanner.Token = etEnd);
        end else
          Result.FArgs := nil;
        CheckTypeForFunction(Result);
      end else
      if FScanner.TokenSymbolIs(DefaultTrueBoolStr) then
      begin
        Result := FExprNodes.NewNode(nkConstant, dtBoolean,
          GetDataTypeSize(dtBoolean), eoUnknown, nil, nil);
        PBoolean(Result.FData)^ := True;
      end else
      if FScanner.TokenSymbolIs(DefaultFalseBoolStr) then
      begin
        Result := FExprNodes.NewNode(nkConstant, dtBoolean,
          GetDataTypeSize(dtBoolean), eoUnknown, nil, nil);
        PBoolean(Result.FData)^ := False;
      end else
      begin
        RaiseExprErrorFmt(ieExprExpected, SExprExpected, [FScanner.TokenDisplayStr]);
        Result := nil;
      end;
    etNumber:
      begin
        if IsInt(FScanner.TokenString) then
        begin
          Result := FExprNodes.NewNode(nkConstant, dtInteger,
            GetDataTypeSize(dtInteger), eoUnknown, nil, nil);
          PInt64(Result.FData)^ := StrToInt(FScanner.TokenString);
        end else
        begin
          Result := FExprNodes.NewNode(nkConstant, dtFloat,
            GetDataTypeSize(dtFloat), eoUnknown, nil, nil);
          PDouble(Result.FData)^ := StrToFloat(FScanner.TokenString);
        end;
      end;
    etString:
      begin
        Result := FExprNodes.NewNode(nkConstant, dtString,
          (Length(FScanner.TokenString) + 1) * SizeOf(Char), eoUnknown, nil, nil);
        StrPCopy(Result.FData, FScanner.TokenString);
      end;
    etLParen:
      begin
        FScanner.GetNextToken;
        Result := ParseStart;
        if FScanner.Token <> etRParen then
          RaiseExprErrorFmt(ieExprNoRParen, SExprNoRParen, [FScanner.TokenDisplayStr]);
      end;
  else
    RaiseExprErrorFmt(ieExprExpected, SExprExpected, [FScanner.TokenDisplayStr]);
    Result := nil;
  end;
  FScanner.GetNextToken;
end;

procedure TExprParser.ParseFinished;
begin
  if FScanner.Token <> etEnd then
    RaiseExprError(ieExprTerminationError, SExprTerminationError);
end;

procedure TExprParser.CheckTypeForArithOp(Node: TExprNode);

  function CompareNumTypePRI(DataType1, DataType2: TExprDataType): Integer;
  var
    Value: array[TExprDataType] of Integer;
  begin
    Value[dtInteger] := 1;
    Value[dtFloat] := 2;

    if Value[DataType1] > Value[DataType2] then
      Result := 1
    else if Value[DataType1] < Value[DataType2] then
      Result := -1
    else
      Result := 0;
  end;

var
  Match: Boolean;
  CompResult: Integer;
begin
  Match := True;
  with Node do
  begin
    if FLeft.IsNumericType then
    begin
      if FRight.IsNumericType then
      begin
        CompResult := CompareNumTypePRI(FLeft.FDataType, FRight.FDataType);
        if CompResult >= 0 then
        begin
          FDataType := FLeft.FDataType;
          DataSize := GetDataTypeSize(FLeft.FDataType);
        end else
        begin
          FDataType := FRight.FDataType;
          DataSize := GetDataTypeSize(FRight.FDataType);
        end;

        if FOperator = eoDiv then
        begin
          FDataType := dtFloat;
          DataSize := SizeOf(Double);
        end;
      end else
        Match := False;
    end
    else if FLeft.IsStringType then
    begin
      if FRight.IsStringType and (FOperator = eoAdd) then
        FDataType := dtString
      else
        Match := False;
    end
    else
      Match := False;
  end;
  if not Match then
    RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
end;

procedure TExprParser.CheckTypeForLogicOp(Node: TExprNode);
begin
  with Node do
  begin
    if FLeft <> nil then
      if not FLeft.IsBooleanType then
        RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
    if FRight <> nil then
      if not FRight.IsBooleanType then
        RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
  end;
end;

procedure TExprParser.CheckTypeForRelationOp(Node: TExprNode);
var
  Match: Boolean;
begin
  Match := True;
  with Node do
  begin
    if FLeft.IsNumericType then
    begin
      if not FRight.IsNumericType then
        Match := False;
    end
    else if FLeft.IsStringType then
    begin
      if not FRight.IsStringType then
        Match := False;
    end
    else if FLeft.IsBooleanType then
    begin
      if not FRight.IsBooleanType then
        Match := False;
      if (FOperator <> eoEQ) and (FOperator <> eoNE) then
        Match := False;
    end
    else
      Match := False;
  end;
  if not Match then
    RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
end;

procedure TExprParser.CheckTypeForFunction(Node: TExprNode);
begin
  TExprFunctions.CheckTypeForFunction(Node.FFuncType, Node.FArgs);
end;

function TExprParser.GetVariableDataType(const Name: string): TExprDataType;
begin
  Result := dtUnknown;
end;

function TExprParser.GetVariableValue(const Name: string): Variant;
begin
  Result := '';
end;

procedure TExprParser.Parse(const ExprText: string);
begin
  FExprNodes.Clear;
  FScanner.SourceText := ExprText;
  FScanner.GetNextToken;
  FExprNodes.Root := ParseStart;
  ParseFinished;
end;

procedure TExprParser.Evaluate;
begin
  FExprNodes.Root.Evaluate(FStrCompOptions);
end;

procedure TExprParser.Execute(const ExprText: string);
begin
  Parse(ExprText);
  Evaluate;
end;

function TExprParser.GetResultValue: Variant;
begin
  Result := FExprNodes.Root.AsValue;
end;

function TExprParser.GetResultAsString: string;
begin
  Result := FExprNodes.Root.AsValueString;
end;

function TExprParser.GetResultForDisplay: string;
begin
  Result := FExprNodes.Root.AsDisplayString;
end;

{ TExprFunctions }

class function TExprFunctions.GetFunctionName(FuncType: TExprFuncType): string;
begin
  case FuncType of
    efUpper:       Result := 'UPPER';
    efLower:       Result := 'LOWER';
    efSubStr:      Result := 'SUBSTR';
    efTrim:        Result := 'TRIM';
    efTrimLeft:    Result := 'TRIMLEFT';
    efTrimRight:   Result := 'TRIMRIGHT';
    efAscii:       Result := 'ASCII';
    efChar:        Result := 'CHAR';
    efLeft:        Result := 'LEFT';
    efRight:       Result := 'RIGHT';
    efLen:         Result := 'LEN';
    efChars:       Result := 'CHARS';
    efCrLf:        Result := 'CRLF';
    efDate:        Result := 'DATE';
    efTime:        Result := 'TIME';
    efNow:         Result := 'NOW';
    efAbs:         Result := 'ABS';
    efPi:          Result := 'PI';
    efRound:       Result := 'ROUND';
    efPower:       Result := 'POWER';
    efSqrt:        Result := 'SQRT';
    efFloor:       Result := 'FLOOR';
    else           Result := '';
  end;
end;

class function TExprFunctions.GetFunctionType(const FuncName: string): TExprFuncType;
var
  I: TExprFuncType;
begin
  for I := Low(TExprFuncType) to High(TExprFuncType) do
    if SameText(GetFunctionName(I), FuncName) then
    begin
      Result := I;
      Exit;
    end;
  Result := efUnknown;
end;

class function TExprFunctions.FunctionExists(const FuncName: string): Boolean;
begin
  Result := GetFunctionType(FuncName) <> efUnknown;
end;

class function TExprFunctions.GetFuncDataType(FuncType: TExprFuncType): TExprDataType;
begin
  Result := dtUnknown;
  case FuncType of
    efUpper, efLower, efSubStr, efTrim, efTrimLeft, efTrimRight,
    efChar, efLeft, efRight, efChars, efCrLf,
    efDate, efTime, efNow:
      Result := dtString;

    efAscii, efLen,
    efRound, efFloor:
      Result := dtInteger;

    efAbs, efPi, efPower, efSqrt:
      Result := dtFloat;
  end;
end;

class procedure TExprFunctions.CheckTypeForFunction(FuncType: TExprFuncType; ArgNodes: TList);

  procedure CheckArgCount(ArgNodes: TList; ArgCount: Integer);
  var
    RealArgCount: Integer;
  begin
    if ArgNodes = nil then
      RealArgCount := 0 else
      RealArgCount := ArgNodes.Count;

    if RealArgCount <> ArgCount then
      RaiseExprError(ieExprFuncArgCountError, SExprFuncArgCountError);
  end;

begin
  case FuncType of
    efDate, efTime, efNow, efPi, efCrLf:
      begin
        CheckArgCount(ArgNodes, 0);
      end;
    efUpper, efLower,
    efTrim, efTrimLeft, efTrimRight,
    efAscii, efLen:
      begin
        CheckArgCount(ArgNodes, 1);
        if not TExprNode(ArgNodes[0]).IsStringType then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
    efChar:
      begin
        CheckArgCount(ArgNodes, 1);
        if not TExprNode(ArgNodes[0]).IsIntegerType then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
    efAbs, efRound, efSqrt, efFloor:
      begin
        CheckArgCount(ArgNodes, 1);
        if not TExprNode(ArgNodes[0]).IsNumericType then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
    efLeft, efRight, efChars:
      begin
        CheckArgCount(ArgNodes, 2);
        if not (TExprNode(ArgNodes[0]).IsStringType and
                TExprNode(ArgNodes[1]).IsIntegerType) then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
    efPower:
      begin
        CheckArgCount(ArgNodes, 2);
        if not (TExprNode(ArgNodes[0]).IsNumericType and
                TExprNode(ArgNodes[1]).IsNumericType) then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
    efSubStr:
      begin
        CheckArgCount(ArgNodes, 3);
        if not (TExprNode(ArgNodes[0]).IsStringType and
                TExprNode(ArgNodes[1]).IsIntegerType and
                TExprNode(ArgNodes[2]).IsIntegerType) then
          RaiseExprError(ieExprTypeMismatch, SExprTypeMismatch);
      end;
  end;
end;

class procedure TExprFunctions.EvaluateFunction(ResultNode: TExprNode;
  FuncType: TExprFuncType; ArgNodes: TList);

  function Arg(Index: Integer): PChar;
  begin
    Result := TExprNode(ArgNodes[Index]).FData;
  end;

  function ArgNode(Index: Integer): TExprNode;
  begin
    Result := TExprNode(ArgNodes[Index]);
  end;

  procedure DoUpper;
  begin
    ResultNode.DataSize := (StrLen(Arg(0)) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, StrUpper(Arg(0)));
  end;

  procedure DoLower;
  begin
    ResultNode.DataSize := (StrLen(Arg(0)) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, StrLower(Arg(0)));
  end;

  procedure DoSubStr;
  var
    StartIdx, SubLen: Integer;
  begin
    StartIdx := PInt64(Arg(1))^;
    SubLen := PInt64(Arg(2))^;
    SubLen := Min(SubLen, Length(Arg(0)));
    SubLen := Max(SubLen, 0);

    ResultNode.DataSize := (SubLen + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(Copy(Arg(0), StartIdx, SubLen)));
  end;

  procedure DoTrim;
  begin
    ResultNode.DataSize := (StrLen(Arg(0)) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(Trim(string(Arg(0)))));
  end;

  procedure DoTrimLeft;
  begin
    ResultNode.DataSize := (StrLen(Arg(0)) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(TrimLeft(string(Arg(0)))));
  end;

  procedure DoTrimRight;
  begin
    ResultNode.DataSize := (StrLen(Arg(0)) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(TrimRight(string(Arg(0)))));
  end;

  procedure DoAscii;
  var
    P: PChar;
  begin
    P := Arg(0);
    ResultNode.DataSize := GetDataTypeSize(dtInteger);
    if Length(P) = 0 then
      PInt64(ResultNode.FData)^ := 0 else
      PInt64(ResultNode.FData)^ := Ord(Arg(0)[0]);
  end;

  procedure DoChar;
  begin
    ResultNode.DataSize := 2 * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(string(Chr(PInt64(Arg(0))^))));
  end;

  procedure DoLeft;
  var
    Src: PChar;
    Len: Integer;
  begin
    Src := Arg(0);
    Len := PInt64(Arg(1))^;
    Len := Min(Len, Length(Src));
    Len := Max(Len, 0);

    ResultNode.DataSize := (Len + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(LeftStr(Src, Len)));
  end;

  procedure DoRight;
  var
    Src: PChar;
    Len: Integer;
  begin
    Src := Arg(0);
    Len := PInt64(Arg(1))^;
    Len := Min(Len, Length(Src));
    Len := Max(Len, 0);

    ResultNode.DataSize := (Len + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(RightStr(Src, Len)));
  end;

  procedure DoLen;
  begin
    ResultNode.DataSize := GetDataTypeSize(dtInteger);
    PInt64(ResultNode.FData)^ := Length(Arg(0));
  end;

  procedure DoChars;
  var
    Src: PChar;
    SrcLen, Count, I: Integer;
    Result: string;
  begin
    Src := Arg(0);
    SrcLen := Length(Src);
    Count := Max(PInt64(Arg(1))^, 0);

    Result := '';
    for I := 0 to Count - 1 do
      Result := Result + Src;

    ResultNode.DataSize := (SrcLen * Count + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(Result));
  end;

  procedure DoCrLf;
  var
    S: string;
  begin
    S := SCrLf;
    ResultNode.DataSize := (Length(S) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(S));
  end;

  procedure DoDate;
  var
    S: string;
  begin
    S := FormatDateTime('yyyy-mm-dd', Now);
    ResultNode.DataSize := (Length(S) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(S));
  end;

  procedure DoTime;
  var
    S: string;
  begin
    S := FormatDateTime('hh:nn:ss', Now);
    ResultNode.DataSize := (Length(S) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(S));
  end;

  procedure DoNow;
  var
    S: string;
  begin
    S := FormatDateTime('yyyy-mm-dd hh:nn:ss', Now);
    ResultNode.DataSize := (Length(S) + 1) * SizeOf(Char);
    StrCopy(ResultNode.FData, PChar(S));
  end;

  procedure DoAbs;
  begin
    ResultNode.SetNumbericValue(ArgNode(0).FDataType, Abs(ArgNode(0).GetNumericValue));
  end;

  procedure DoPi;
  begin
    ResultNode.SetNumbericValue(dtFloat, Pi);
  end;

  procedure DoRound;
  begin
    ResultNode.SetNumbericValue(dtInteger, Round(ArgNode(0).GetNumericValue));
  end;

  procedure DoPower;
  var
    IsFloat: Boolean;
    DataType: TExprDataType;
  begin
    IsFloat := ArgNode(0).IsFloatType or ArgNode(1).IsFloatType;
    DataType := Iif(IsFloat, dtFloat, dtInteger);

    ResultNode.SetNumbericValue(DataType,
      Power(TExprNode(ArgNodes[0]).GetNumericValue,
      TExprNode(ArgNodes[1]).GetNumericValue));
  end;

  procedure DoSqrt;
  begin
    ResultNode.SetNumbericValue(dtFloat, Sqrt(TExprNode(ArgNodes[0]).GetNumericValue));
  end;

  procedure DoFloor;
  begin
    ResultNode.SetNumbericValue(dtFloat, Floor(TExprNode(ArgNodes[0]).GetNumericValue));
  end;

begin
  case FuncType of
    efUpper:     DoUpper;
    efLower:     DoLower;
    efSubStr:    DoSubStr;
    efTrim:      DoTrim;
    efTrimLeft:  DoTrimLeft;
    efTrimRight: DoTrimRight;
    efAscii:     DoAscii;
    efChar:      DoChar;
    efLeft:      DoLeft;
    efRight:     DoRight;
    efLen:       DoLen;
    efChars:     DoChars;
    efCrLf:      DoCrLf;
    efDate:      DoDate;
    efTime:      DoTime;
    efNow:       DoNow;
    efAbs:       DoAbs;
    efPi:        DoPi;
    efRound:     DoRound;
    efPower:     DoPower;
    efSqrt:      DoSqrt;
    efFloor:     DoFloor;
  end;
end;

end.
