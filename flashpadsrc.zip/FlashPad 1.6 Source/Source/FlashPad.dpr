program FlashPad;

{$WEAKLINKRTTI ON}
{$RTTI EXPLICIT METHODS([]) PROPERTIES([]) FIELDS([])}

uses
  Forms,
  BackMainFrm in 'BackMainFrm.pas' {BackMainForm},
  PubUtils in 'PubUtils.pas',
  BaseConfigMgr in 'BaseConfigMgr.pas',
  AppUtils in 'AppUtils.pas',
  AppConfigMgr in 'AppConfigMgr.pas',
  Global in 'Global.pas',
  Containers in 'Containers.pas',
  DataManager in 'DataManager.pas',
  BaseFrm in 'BaseFrm.pas' {BaseForm},
  InputFrm in 'InputFrm.pas' {InputForm},
  ConfigFrm in 'ConfigFrm.pas' {ConfigForm},
  AboutFrm in 'AboutFrm.pas' {AboutForm},
  MainFrm in 'MainFrm.pas' {MainForm},
  PadMemo in 'PadMemo.pas',
  PadTabSet in 'PadTabSet.pas',
  ShortcutsFrm in 'ShortcutsFrm.pas' {ShortcutsForm},
  ExprParser in 'ExprParser.pas',
  MsgBox in 'MsgBox.pas',
  InputMemoFrm in 'InputMemoFrm.pas' {InputMemoForm};

{$R *.res}

begin
  CheckInstanceCount;
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.ShowMainForm := False;
  Application.ModalPopupMode := pmAuto;
  Application.Title := 'FlashPad';
  Application.CreateForm(TBackMainForm, BackMainForm);
  Application.CreateForm(TMainForm, MainForm);
  CheckCmdParams;
  Application.Run;
end.
