unit Global;

interface

const
  SCompanyName = 'DayDream Software';
  SSoftName = 'FlashPad';
  SVersion = '1.6';
  SWebSite = 'http://www.haoxg.net';
  SEmail = 'haoxg@21cn.com';

  SReadmeFileName = 'Readme.txt';
  SConfigFileName = 'Config.ini';
  SDataDirName = 'Data';
  SDataFileExt = 'txt';
  SParamMinimize = '/min';

implementation

end.
