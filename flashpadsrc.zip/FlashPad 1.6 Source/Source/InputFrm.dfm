inherited InputForm: TInputForm
  Left = 490
  Top = 183
  BorderStyle = bsDialog
  BorderWidth = 6
  Caption = #36755#20837
  ClientHeight = 86
  ClientWidth = 256
  Position = poOwnerFormCenter
  ExplicitWidth = 274
  ExplicitHeight = 123
  DesignSize = (
    256
    86)
  PixelsPerInch = 96
  TextHeight = 12
  object PromptLabel: TLabel
    Left = 5
    Top = 6
    Width = 6
    Height = 12
    Caption = '#'
  end
  object OkButton: TButton
    Left = 50
    Top = 58
    Width = 75
    Height = 21
    Anchors = [akLeft, akBottom]
    Caption = #30830#23450
    Default = True
    TabOrder = 1
    OnClick = OkButtonClick
  end
  object CancelButton: TButton
    Left = 138
    Top = 58
    Width = 75
    Height = 21
    Anchors = [akLeft, akBottom]
    Cancel = True
    Caption = #21462#28040
    TabOrder = 2
    OnClick = CancelButtonClick
  end
  object ValueEdit: TEdit
    Left = 5
    Top = 25
    Width = 246
    Height = 20
    TabOrder = 0
    OnChange = ValueEditChange
  end
end
