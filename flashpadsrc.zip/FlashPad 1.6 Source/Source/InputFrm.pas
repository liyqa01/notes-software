unit InputFrm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, BaseFrm;

type
  TInputForm = class(TBaseForm)
    OkButton: TButton;
    CancelButton: TButton;
    PromptLabel: TLabel;
    ValueEdit: TEdit;
    procedure OkButtonClick(Sender: TObject);
    procedure CancelButtonClick(Sender: TObject);
    procedure ValueEditChange(Sender: TObject);
  private
    FAllowEmpty: Boolean;
  public
    procedure SetData(const Caption, Prompt, Value: string;
      AsPassword, AllowEmpty: Boolean);
    procedure GetData(var Value: string);
  end;

function ShowInputForm(OwnerForm: TForm; const Caption, Prompt: string;
  var Value: string; AsPassword: Boolean = False;
  AllowEmpty: Boolean = True): Boolean;

implementation

{$R *.DFM}

function ShowInputForm(OwnerForm: TForm; const Caption, Prompt: string;
  var Value: string; AsPassword, AllowEmpty: Boolean): Boolean;
var
  Form: TInputForm;
begin
  Form := TInputForm.Create(OwnerForm);
  try
    Form.SetData(Caption, Prompt, Value, AsPassword, AllowEmpty);
    Result := (Form.ShowModal = mrOk);
    if Result then Form.GetData(Value);
  finally
    Form.Free;
  end;
end;

{ TInputForm }

procedure TInputForm.SetData(const Caption, Prompt, Value: string;
  AsPassword, AllowEmpty: Boolean);
begin
  Self.Caption := Caption;
  PromptLabel.Caption := Prompt;

  FAllowEmpty := AllowEmpty;
  if AsPassword then ValueEdit.PasswordChar := '*';

  ValueEdit.Text := Value;
  ValueEditChange(nil);
end;

procedure TInputForm.GetData(var Value: string);
begin
  Value := ValueEdit.Text;
end;

procedure TInputForm.ValueEditChange(Sender: TObject);
begin
  if not FAllowEmpty then
    OkButton.Enabled := (Length(ValueEdit.Text) > 0);
end;

procedure TInputForm.OkButtonClick(Sender: TObject);
begin
  ModalResult := mrOk;
end;

procedure TInputForm.CancelButtonClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

end.
