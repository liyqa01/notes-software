inherited InputMemoForm: TInputMemoForm
  Left = 465
  Top = 247
  BorderIcons = [biSystemMenu, biMaximize]
  Caption = #36755#20837
  ClientHeight = 216
  ClientWidth = 314
  Constraints.MinHeight = 200
  Constraints.MinWidth = 250
  Position = poOwnerFormCenter
  ExplicitWidth = 322
  ExplicitHeight = 243
  PixelsPerInch = 96
  TextHeight = 12
  object PromptLabel: TLabel
    Left = 8
    Top = 10
    Width = 6
    Height = 12
    Caption = '#'
    Transparent = True
  end
  object OkButton: TButton
    Left = 147
    Top = 186
    Width = 75
    Height = 21
    Anchors = [akRight, akBottom]
    Caption = #30830#23450
    Default = True
    ModalResult = 1
    TabOrder = 1
  end
  object CancelButton: TButton
    Left = 231
    Top = 186
    Width = 75
    Height = 21
    Anchors = [akRight, akBottom]
    Cancel = True
    Caption = #21462#28040
    ModalResult = 2
    TabOrder = 2
  end
  object Memo: TMemo
    Left = 8
    Top = 29
    Width = 298
    Height = 149
    Anchors = [akLeft, akTop, akRight, akBottom]
    ScrollBars = ssVertical
    TabOrder = 0
    OnChange = MemoChange
  end
end
