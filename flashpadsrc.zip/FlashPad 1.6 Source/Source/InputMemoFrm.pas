unit InputMemoFrm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, BaseFrm, StdCtrls;

type
  TInputMemoForm = class(TBaseForm)
    PromptLabel: TLabel;
    OkButton: TButton;
    CancelButton: TButton;
    Memo: TMemo;
    procedure MemoChange(Sender: TObject);
  private
    FAllowEmpty: Boolean;
  public
    procedure SetData(const Caption, Prompt, Value: string;
      AllowEmpty: Boolean; MaxLength: Integer);
    procedure GetData(var Value: string);
  end;

function ShowInputMemoForm(OwnerForm: TForm; const Caption, Prompt: string;
  var Value: string; AllowEmpty: Boolean = True; MaxLength: Integer = 0): Boolean;

implementation

{$R *.dfm}

function ShowInputMemoForm(OwnerForm: TForm; const Caption, Prompt: string;
  var Value: string; AllowEmpty: Boolean; MaxLength: Integer): Boolean;
var
  Form: TInputMemoForm;
begin
  Form := TInputMemoForm.Create(OwnerForm);
  try
    Form.SetData(Caption, Prompt, Value, AllowEmpty, MaxLength);
    Result := (Form.ShowModal = mrOk);
    if Result then Form.GetData(Value);
  finally
    Form.Free;
  end;
end;

{ TInputMemoForm }

procedure TInputMemoForm.SetData(const Caption, Prompt, Value: string;
  AllowEmpty: Boolean; MaxLength: Integer);
begin
  Self.Caption := Caption;
  PromptLabel.Caption := Prompt;
  Memo.MaxLength := MaxLength;

  FAllowEmpty := AllowEmpty;

  Memo.Text := Value;
  MemoChange(nil);
end;

procedure TInputMemoForm.GetData(var Value: string);
begin
  Value := Memo.Lines.Text;
end;

procedure TInputMemoForm.MemoChange(Sender: TObject);
begin
  if not FAllowEmpty then
    OkButton.Enabled := (Length(Memo.Text) > 0);
end;

end.
