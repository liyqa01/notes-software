inherited MainForm: TMainForm
  Caption = 'FlashPad'
  ClientHeight = 361
  ClientWidth = 538
  Font.Charset = DEFAULT_CHARSET
  Font.Height = -11
  Font.Name = 'Tahoma'
  KeyPreview = True
  Menu = MainMenu
  Position = poDesigned
  ScreenSnap = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnKeyDown = FormKeyDown
  OnResize = FormResize
  OnShow = FormShow
  ExplicitWidth = 546
  ExplicitHeight = 407
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 538
    Height = 361
    Align = alClient
    BevelOuter = bvNone
    BorderWidth = 1
    Color = 7829367
    ParentBackground = False
    TabOrder = 0
    ExplicitHeight = 362
    object MemoPanel: TPanel
      Left = 1
      Top = 26
      Width = 536
      Height = 334
      Align = alClient
      BevelOuter = bvNone
      BorderWidth = 1
      Color = clWhite
      ParentBackground = False
      TabOrder = 0
      ExplicitHeight = 335
      object LayerList: TLayerList
        Left = 1
        Top = 1
        Width = 534
        Height = 332
        Align = alClient
        TabOrder = 0
        ExplicitHeight = 333
      end
    end
    object TabSetPanel: TPanel
      Left = 1
      Top = 1
      Width = 536
      Height = 25
      Align = alTop
      BevelOuter = bvNone
      ParentBackground = False
      TabOrder = 1
    end
  end
  object MainMenu: TMainMenu
    Left = 32
    Top = 40
    object FileMenu: TMenuItem
      Caption = #25991#20214'(&F)'
      object FileLoadFromFileItem: TMenuItem
        Action = LoadFromFileAction
      end
      object FileSaveToFileItem: TMenuItem
        Action = SaveToFileAction
      end
      object FileN1Item: TMenuItem
        Caption = '-'
      end
      object FilePrintItem: TMenuItem
        Action = PrintAction
        Visible = False
      end
      object FileN2Item: TMenuItem
        Caption = '-'
      end
      object FileHideItem: TMenuItem
        Action = HideAction
      end
      object FileN3Item: TMenuItem
        Caption = '-'
      end
      object FileExitItem: TMenuItem
        Action = ExitAction
      end
    end
    object EditMenu: TMenuItem
      Caption = #32534#36753'(&E)'
      object EditUndoItem: TMenuItem
        Action = UndoAction
      end
      object EditN1Item: TMenuItem
        Caption = '-'
      end
      object EditCutItem: TMenuItem
        Action = CutAction
      end
      object EditCopyItem: TMenuItem
        Action = CopyAction
      end
      object EditPasteItem: TMenuItem
        Action = PasteAction
      end
      object EditN2Item: TMenuItem
        Caption = '-'
      end
      object EditFindItem: TMenuItem
        Action = FindAction
      end
      object EditFindNextItem: TMenuItem
        Action = FindNextAction
      end
      object EditReplaceItem: TMenuItem
        Action = ReplaceAction
      end
      object EditN3Item: TMenuItem
        Caption = '-'
      end
      object EditSelectAllItem: TMenuItem
        Action = SelectAllAction
      end
    end
    object PageMenu: TMenuItem
      Caption = #39029#38754'(&P)'
      object PageNewPageItem: TMenuItem
        Action = NewPageAction
      end
      object PageDeletePageItem: TMenuItem
        Action = DeletePageAction
      end
      object PageN1Item: TMenuItem
        Caption = '-'
      end
      object PageChgPageTitleItem: TMenuItem
        Action = ChgPageTitleAction
      end
    end
    object FormatMenu: TMenuItem
      Caption = #26684#24335'(&O)'
      object FormatFontItem: TMenuItem
        Action = FontAction
      end
      object FormatBgColorItem: TMenuItem
        Action = BgColorAction
      end
      object FormatN1Item: TMenuItem
        Caption = '-'
      end
      object FormatWordWrapItem: TMenuItem
        Action = WordWrapAction
        AutoCheck = True
      end
    end
    object InsertMenu: TMenuItem
      Caption = #25554#20837'(&I)'
      OnClick = InsertMenuClick
      object InsertLineItem: TMenuItem
        Action = InsertLineAction
      end
      object InsertDateItem: TMenuItem
        Action = InsertDateAction
      end
      object InsertLineDateItem: TMenuItem
        Action = InsertLineDateAction
      end
      object InsertN1Item: TMenuItem
        Caption = '-'
      end
      object InsertN2Item: TMenuItem
        Caption = '-'
      end
      object InsertConfigItem: TMenuItem
        Action = InsertConfigAction
      end
    end
    object T2: TMenuItem
      Caption = #24037#20855'(&T)'
      object ToolsStayOnTopItem: TMenuItem
        Action = StayOnTopAction
        AutoCheck = True
      end
      object ToolsN1Item: TMenuItem
        Caption = '-'
      end
      object ToolsOptionsItem: TMenuItem
        Action = ConfigAction
      end
    end
    object HelpMenu: TMenuItem
      Caption = #24110#21161'(&H)'
      object HelpReadmeItem: TMenuItem
        Action = ReadmeAction
      end
      object HelpHotKeyItem: TMenuItem
        Action = HotKeyListAction
      end
      object HelpN1Item: TMenuItem
        Caption = '-'
      end
      object HelpAboutItem: TMenuItem
        Action = AboutAction
      end
    end
  end
  object ActionList: TActionList
    Left = 32
    Top = 88
    object LoadFromFileAction: TAction
      Category = 'File'
      Caption = #20174#25991#20214#36733#20837'(&L)'
      OnExecute = LoadFromFileActionExecute
    end
    object UndoAction: TEditUndo
      Category = 'Edit'
      Caption = #25764#38144'(&U)'
      ImageIndex = 3
      ShortCut = 16474
    end
    object CutAction: TEditCut
      Category = 'Edit'
      Caption = #21098#20999'(&X)'
      ImageIndex = 0
      ShortCut = 16472
    end
    object CopyAction: TEditCopy
      Category = 'Edit'
      Caption = #22797#21046'(&C)'
      ImageIndex = 1
      ShortCut = 16451
    end
    object PasteAction: TEditPaste
      Category = 'Edit'
      Caption = #31896#36148'(&P)'
      ImageIndex = 2
      ShortCut = 16470
    end
    object SelectAllAction: TEditSelectAll
      Category = 'Edit'
      Caption = #20840#36873'(&A)'
      ShortCut = 16449
    end
    object SaveToFileAction: TAction
      Category = 'File'
      Caption = #21478#23384#21040#25991#20214'(&S)'
      OnExecute = SaveToFileActionExecute
    end
    object PrintAction: TAction
      Category = 'File'
      Caption = #25171#21360'(&P)'
      ShortCut = 16464
      OnExecute = PrintActionExecute
    end
    object HideAction: TAction
      Category = 'File'
      Caption = #38544#34255'(&H)'
      ShortCut = 27
      OnExecute = HideActionExecute
    end
    object ExitAction: TAction
      Category = 'File'
      Caption = #36864#20986'(&X)'
      OnExecute = ExitActionExecute
    end
    object NewPageAction: TAction
      Category = 'Page'
      Caption = #26032#24314#39029#38754'(&N)'
      ShortCut = 115
      SecondaryShortCuts.Strings = (
        'Ctrl+N')
      OnExecute = NewPageActionExecute
    end
    object DeletePageAction: TAction
      Category = 'Page'
      Caption = #21024#38500#39029#38754'(&D)'
      ShortCut = 32814
      SecondaryShortCuts.Strings = (
        'Shift+Alt+Del')
      OnExecute = DeletePageActionExecute
    end
    object ChgPageTitleAction: TAction
      Category = 'Page'
      Caption = #20462#25913#39029#38754#26631#39064'(&M)'
      ShortCut = 113
      OnExecute = ChgPageTitleActionExecute
    end
    object FontAction: TAction
      Category = 'Format'
      Caption = #23383#20307'(&F)...'
      OnExecute = FontActionExecute
    end
    object BgColorAction: TAction
      Category = 'Format'
      Caption = #32972#26223#33394'(&B)...'
      OnExecute = BgColorActionExecute
    end
    object WordWrapAction: TAction
      Category = 'Format'
      AutoCheck = True
      Caption = #33258#21160#25442#34892'(&W)'
      Checked = True
      ShortCut = 16471
      OnExecute = WordWrapActionExecute
    end
    object InsertLineAction: TAction
      Category = 'Insert'
      Caption = #20998#38548#34892'(&L)'
      ShortCut = 16573
      OnExecute = InsertLineActionExecute
    end
    object InsertDateAction: TAction
      Category = 'Insert'
      Caption = #26085#26399#26102#38388'(&D)'
      ShortCut = 16452
      OnExecute = InsertDateActionExecute
    end
    object InsertLineDateAction: TAction
      Category = 'Insert'
      Caption = #26085#26399#26102#38388#20998#38548#34892'(&B)'
      ShortCut = 24765
      OnExecute = InsertLineDateActionExecute
    end
    object StayOnTopAction: TAction
      Category = 'Tools'
      AutoCheck = True
      Caption = #31383#21475#20445#25345#22312#26368#39030#23618'(&T)'
      ShortCut = 117
      OnExecute = StayOnTopActionExecute
    end
    object ConfigAction: TAction
      Category = 'Tools'
      Caption = #35774#32622'(&O)...'
      ShortCut = 119
      OnExecute = ConfigActionExecute
    end
    object FindAction: TAction
      Category = 'Edit'
      Caption = #26597#25214'(&F)...'
      ShortCut = 16454
      OnExecute = FindActionExecute
    end
    object FindNextAction: TAction
      Category = 'Edit'
      Caption = #26597#25214#19979#19968#20010'(&N)'
      ShortCut = 114
      OnExecute = FindNextActionExecute
    end
    object ReplaceAction: TAction
      Category = 'Edit'
      Caption = #26367#25442'(&R)...'
      ShortCut = 16466
      SecondaryShortCuts.Strings = (
        'Ctrl+H')
      OnExecute = ReplaceActionExecute
    end
    object NextPageAction: TAction
      Category = 'Page'
      Caption = #19979#19968#39029
      ShortCut = 16393
      OnExecute = NextPageActionExecute
    end
    object PrevPageAction: TAction
      Category = 'Page'
      Caption = #19978#19968#39029
      ShortCut = 24585
      OnExecute = PrevPageActionExecute
    end
    object ReadmeAction: TAction
      Category = 'Help'
      Caption = #36719#20214#35828#26126'(&R)...'
      OnExecute = ReadmeActionExecute
    end
    object HotKeyListAction: TAction
      Category = 'Help'
      Caption = #24555#25463#38190#21015#34920'(&S)...'
      OnExecute = HotKeyListActionExecute
    end
    object AboutAction: TAction
      Category = 'Help'
      Caption = #20851#20110'(&A)'
      OnExecute = AboutActionExecute
    end
    object InsertConfigAction: TAction
      Category = 'Insert'
      Caption = #25554#20837#25991#26412#35774#32622'(&C)...'
      OnExecute = InsertConfigActionExecute
    end
  end
  object ReplaceDialog: TReplaceDialog
    Options = [frDown, frHideWholeWord]
    OnFind = ReplaceDialogFind
    OnReplace = ReplaceDialogReplace
    Left = 120
    Top = 88
  end
  object FindDialog: TFindDialog
    Options = [frDown, frHideWholeWord]
    OnFind = FindDialogFind
    Left = 120
    Top = 40
  end
  object TrayIcon: TTrayIcon
    Icon.Data = {
      0000010001001010100001000400280100001600000028000000100000002000
      0000010004000000000080000000000000000000000000000000000000000000
      000000008000008000000080800080000000800080008080000080808000C0C0
      C0000000FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF000000
      00000000000000000000000000000000000000000000000007FFFFFFFFF00000
      07FFFFFFFFF0000007F888888FF0001011FFFFFFFFF000000FF888888FF01010
      11FFFFFFFFF000000FF888888FF0001011FFFFFFFFF000000FF8888F00001010
      11FFFFFF7F00000007FFFFFF700000000777777770000000000000000000FFFF
      0000FFFF0000F8000000F8000000F8000000F8000000D0000000F80000005000
      0000F8000000D0000000F800000050010000F8030000F8070000FFFF0000}
    PopupMenu = TrayPopupMenu
    Visible = True
    OnDblClick = TrayIconDblClick
    OnMouseDown = TrayIconMouseDown
    Left = 32
    Top = 136
  end
  object ApplicationEvents: TApplicationEvents
    OnMessage = ApplicationEventsMessage
    OnMinimize = ApplicationEventsMinimize
    OnRestore = ApplicationEventsRestore
    Left = 32
    Top = 184
  end
  object SaveTimer: TTimer
    OnTimer = SaveTimerTimer
    Left = 32
    Top = 232
  end
  object SysHotKey: TSysHotKey
    HotKeys = <
      item
        OnHotKey = SysHotKeyHotKeys0HotKey
      end>
    Left = 32
    Top = 280
  end
  object TabSetPopupMenu: TPopupMenu
    Left = 120
    Top = 136
    object TsPopNewPageItem: TMenuItem
      Action = NewPageAction
    end
    object TsPopDeletePageItem: TMenuItem
      Action = DeletePageAction
    end
    object TsPopN1Item: TMenuItem
      Caption = '-'
    end
    object TsPopChgPageTitleItem: TMenuItem
      Action = ChgPageTitleAction
    end
  end
  object TrayPopupMenu: TPopupMenu
    OnPopup = TrayPopupMenuPopup
    Left = 120
    Top = 184
    object TrayPopShowMainFormItem: TMenuItem
      Caption = #26174#31034#20027#31383#21475'(&S)'
      OnClick = TrayPopShowMainFormItemClick
    end
    object TrayPopN1Item: TMenuItem
      Caption = '-'
    end
    object TrayPopExitItem: TMenuItem
      Action = ExitAction
    end
  end
end
