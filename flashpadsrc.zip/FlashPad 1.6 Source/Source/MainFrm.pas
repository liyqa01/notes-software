unit MainFrm;

interface

{$R Resources.res}

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, BaseFrm, ExtCtrls, AppEvnts, ActnList, Menus, StdActns, Tabs,
  StrUtils, StdCtrls, ShellApi, ComCtrls, LayerList, SysHotKey,
  PadMemo, PadTabSet;

const
  DefWinWidth = 560;
  DefWinHeight = 430;

  WM_SHOW_MAIN_WIN = WM_USER + 100;

type
  TMainForm = class(TBaseForm)
    MainMenu: TMainMenu;
    ActionList: TActionList;
    ReplaceDialog: TReplaceDialog;
    FindDialog: TFindDialog;
    TrayIcon: TTrayIcon;
    ApplicationEvents: TApplicationEvents;
    SaveTimer: TTimer;
    FileMenu: TMenuItem;
    EditMenu: TMenuItem;
    PageMenu: TMenuItem;
    FormatMenu: TMenuItem;
    InsertMenu: TMenuItem;
    HelpMenu: TMenuItem;
    FileLoadFromFileItem: TMenuItem;
    FileSaveToFileItem: TMenuItem;
    FileN1Item: TMenuItem;
    FilePrintItem: TMenuItem;
    FileExitItem: TMenuItem;
    FileN2Item: TMenuItem;
    FileHideItem: TMenuItem;
    ToolsStayOnTopItem: TMenuItem;
    EditUndoItem: TMenuItem;
    EditN1Item: TMenuItem;
    EditCutItem: TMenuItem;
    EditCopyItem: TMenuItem;
    EditPasteItem: TMenuItem;
    EditN2Item: TMenuItem;
    EditFindItem: TMenuItem;
    EditFindNextItem: TMenuItem;
    EditReplaceItem: TMenuItem;
    EditN3Item: TMenuItem;
    EditSelectAllItem: TMenuItem;
    PageNewPageItem: TMenuItem;
    PageDeletePageItem: TMenuItem;
    PageN1Item: TMenuItem;
    PageChgPageTitleItem: TMenuItem;
    FormatFontItem: TMenuItem;
    FormatBgColorItem: TMenuItem;
    FormatN1Item: TMenuItem;
    FormatWordWrapItem: TMenuItem;
    InsertLineItem: TMenuItem;
    InsertDateItem: TMenuItem;
    InsertLineDateItem: TMenuItem;
    HelpAboutItem: TMenuItem;
    T2: TMenuItem;
    ToolsN1Item: TMenuItem;
    ToolsOptionsItem: TMenuItem;
    FileN3Item: TMenuItem;
    NextPageAction: TAction;
    ReplaceAction: TAction;
    FindNextAction: TAction;
    FindAction: TAction;
    AboutAction: TAction;
    ConfigAction: TAction;
    StayOnTopAction: TAction;
    InsertLineDateAction: TAction;
    InsertDateAction: TAction;
    InsertLineAction: TAction;
    WordWrapAction: TAction;
    BgColorAction: TAction;
    FontAction: TAction;
    ChgPageTitleAction: TAction;
    DeletePageAction: TAction;
    NewPageAction: TAction;
    ExitAction: TAction;
    HideAction: TAction;
    PrintAction: TAction;
    SaveToFileAction: TAction;
    LoadFromFileAction: TAction;
    PrevPageAction: TAction;
    ReadmeAction: TAction;
    HotKeyListAction: TAction;
    HelpN1Item: TMenuItem;
    HelpReadmeItem: TMenuItem;
    HelpHotKeyItem: TMenuItem;
    SysHotKey: TSysHotKey;
    CutAction: TEditCut;
    CopyAction: TEditCopy;
    PasteAction: TEditPaste;
    SelectAllAction: TEditSelectAll;
    UndoAction: TEditUndo;
    TabSetPopupMenu: TPopupMenu;
    TsPopNewPageItem: TMenuItem;
    TsPopDeletePageItem: TMenuItem;
    TsPopN1Item: TMenuItem;
    TsPopChgPageTitleItem: TMenuItem;
    Panel1: TPanel;
    MemoPanel: TPanel;
    LayerList: TLayerList;
    TabSetPanel: TPanel;
    TrayPopupMenu: TPopupMenu;
    TrayPopN1Item: TMenuItem;
    TrayPopExitItem: TMenuItem;
    TrayPopShowMainFormItem: TMenuItem;
    InsertN1Item: TMenuItem;
    InsertConfigAction: TAction;
    InsertConfigItem: TMenuItem;
    InsertN2Item: TMenuItem;
    PopupPickMenuAction: TAction;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormResize(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure LoadFromFileActionExecute(Sender: TObject);
    procedure SaveToFileActionExecute(Sender: TObject);
    procedure PrintActionExecute(Sender: TObject);
    procedure HideActionExecute(Sender: TObject);
    procedure ExitActionExecute(Sender: TObject);
    procedure FindActionExecute(Sender: TObject);
    procedure FindNextActionExecute(Sender: TObject);
    procedure FontActionExecute(Sender: TObject);
    procedure BgColorActionExecute(Sender: TObject);
    procedure WordWrapActionExecute(Sender: TObject);
    procedure InsertLineActionExecute(Sender: TObject);
    procedure InsertDateActionExecute(Sender: TObject);
    procedure InsertLineDateActionExecute(Sender: TObject);
    procedure NewPageActionExecute(Sender: TObject);
    procedure DeletePageActionExecute(Sender: TObject);
    procedure ChgPageTitleActionExecute(Sender: TObject);
    procedure NextPageActionExecute(Sender: TObject);
    procedure PrevPageActionExecute(Sender: TObject);
    procedure StayOnTopActionExecute(Sender: TObject);
    procedure ConfigActionExecute(Sender: TObject);
    procedure ReadmeActionExecute(Sender: TObject);
    procedure HotKeyListActionExecute(Sender: TObject);
    procedure AboutActionExecute(Sender: TObject);
    procedure TrayIconDblClick(Sender: TObject);
    procedure TrayIconMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure ApplicationEventsMessage(var Msg: tagMSG; var Handled: Boolean);
    procedure ApplicationEventsMinimize(Sender: TObject);
    procedure ApplicationEventsRestore(Sender: TObject);
    procedure SaveTimerTimer(Sender: TObject);
    procedure SysHotKeyHotKeys0HotKey(Sender: TObject);
    procedure FindDialogFind(Sender: TObject);
    procedure ReplaceDialogFind(Sender: TObject);
    procedure ReplaceDialogReplace(Sender: TObject);
    procedure ReplaceActionExecute(Sender: TObject);
    procedure TrayPopShowMainFormItemClick(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure TrayPopupMenuPopup(Sender: TObject);
    procedure InsertConfigActionExecute(Sender: TObject);
    procedure InsertMenuClick(Sender: TObject);
    procedure PopupPickMenuActionExecute(Sender: TObject);
  private
    FFindText, FReplaceText: string;
    FSearchOptions: TStringSearchOptions;
    FTabSet: TPadTabSet;

    procedure LoadPages;
    procedure SavePages;
    procedure CreatePage(const PageTitle, PageText: string);
    procedure DestroyPage(PageIndex: Integer);
    procedure AddPage(const PageTitle, PageText: string);
    procedure RemovePage(PageIndex: Integer; RemoveToRecycle: Boolean);
    procedure AddDefaultPage;
    procedure SetAllMemosWordWrap(WordWrap: Boolean);
    procedure LoadWinBounds;
    procedure SaveWinBounds;
    procedure LoadPageIndex;
    procedure SavePageIndex;
    procedure LoadFromFile(const FileName: string);
    procedure SaveAllData;
    procedure DoAppMinimized;
    procedure DoAppRestored;
    procedure AfterLoadConfig;
    procedure AfterChangeConfig;
    procedure SetHotKeyEnabled(Enabled: Boolean);
    procedure UpdateAutoRunOnStartup;
    procedure UpdateHotKey;
    procedure UpdateTrayPopupMenu;
    procedure UpdateInsertMenu;
    procedure FindText;
    procedure ReplaceText;
    procedure ReplaceAllText;
    procedure AdjustAllMemosMargins;
    procedure CreateTabSet;
    procedure InsertTextByCheckingExpr(const S: string);
    function GetActiveMemo: TPadMemo;
    function GetMemoCount: Integer;
    function GetMemo(PageIndex: Integer): TPadMemo;

    procedure DoFileDropMessage(var Msg: TMsg; var Handled: Boolean);
    procedure OnTabSetClick(Sender: TObject);
    procedure OnTabSetDblClick(Sender: TObject);
    procedure OnTabSetTabMoved(Sender: TObject; OldTabIndex, NewTabIndex: Integer);
    procedure OnInsertCustomMenuItemClick(Sender: TObject);
    procedure WMShowMainWindow(var Message: TMessage); message WM_SHOW_MAIN_WIN;
    procedure WMSize(var Message: TWMSize); message WM_SIZE;
    procedure WMQueryEndSession(var Message: TWMQueryEndSession); message WM_QUERYENDSESSION;
  protected
    procedure CreateParams(var Params: TCreateParams); override;
  public
    procedure MouseWheelHandler(var Message: TMessage); override;
  public
    procedure ShowMainForm;
    procedure HideMainForm;
  end;

var
  MainForm: TMainForm;

implementation

uses
  Global, PubUtils, AppUtils, DataManager, AppConfigMgr, MsgBox, ExprParser,
  InputFrm, ConfigFrm, ShortcutsFrm, AboutFrm;

const
  SDefPageTitle = 'Ĭ��ҳ';
  SNewPageTitle = '�½�ҳ';
  SCrLf = #13#10;

type
  TControlAccess = class(TControl);

{$R *.dfm}

procedure TMainForm.FormCreate(Sender: TObject);
begin
  // �������г���ı�� (�������Ƴ���ʵ�����)
  SetProp(Handle, SSoftName, Handle);
  // ���� Win98 ������������������ť������
  HideAppFromTaskBar;

  CreateTabSet;

  DragAcceptFiles(Handle, True);

  LoadPages;
  AfterLoadConfig;
end;

procedure TMainForm.FormDestroy(Sender: TObject);
begin
  SaveAllData;
end;

procedure TMainForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  if not ConfigMgr.MinOnClose then
    ExitAction.Execute;
end;

procedure TMainForm.FormResize(Sender: TObject);
var
  Memo: TPadMemo;
begin
  Memo := GetActiveMemo;
  if Memo <> nil then
    Memo.InitMargins;
end;

procedure TMainForm.FormShow(Sender: TObject);
begin
  UpdateTrayPopupMenu;
end;

procedure TMainForm.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
var
  Index: Integer;
begin
  if Shift = [ssAlt] then
  begin
    case Key of
      Ord('0')..Ord('9'):
        begin
          if Key = Ord('0') then
            Index := 9 else
            Index := Key - Ord('0') - 1;
          if (Index >= 0) and (Index < FTabSet.Tabs.Count) then
            FTabSet.TabIndex := Index;
        end;

      VK_LEFT:
        if FTabSet.Tabs.Count > 0 then
        begin
          if FTabSet.TabIndex <= 0 then
            FTabSet.TabIndex := FTabSet.Tabs.Count - 1 else
            FTabSet.TabIndex := FTabSet.TabIndex - 1;
        end;

      VK_RIGHT:
        if FTabSet.Tabs.Count > 0 then
        begin
          if FTabSet.TabIndex >= FTabSet.Tabs.Count - 1 then
            FTabSet.TabIndex := 0 else
            FTabSet.TabIndex := FTabSet.TabIndex + 1;
        end;

      VK_HOME:
        if FTabSet.Tabs.Count > 0 then
          FTabSet.TabIndex := 0;

      VK_END:
        if FTabSet.Tabs.Count > 0 then
          FTabSet.TabIndex := FTabSet.Tabs.Count - 1;
    end;
  end;
end;

procedure TMainForm.CreateParams(var Params: TCreateParams);
begin
  inherited;
  Params.WndParent := 0;
end;

procedure TMainForm.MouseWheelHandler(var Message: TMessage);
var
  MsPos: TPoint;
begin
  if Message.Result = 0 then
  begin
    MsPos.X := TCMMouseWheel(Message).XPos;
    MsPos.Y := TCMMouseWheel(Message).YPos;

    if PtInRect(Rect(0, 0, FTabSet.Width, FTabSet.Height),
      FTabSet.ScreenToClient(MsPos)) then
    begin
      FTabSet.Perform(CM_MOUSEWHEEL, Message.WParam, Message.LParam);
      Message.Result := 1;
      Exit;
    end;
  end;

  inherited;
end;

procedure TMainForm.LoadPages;
var
  PageItems: TPageItems;
  I: Integer;
begin
  DataMgr.GetPageList(PageItems);
  for I := 0 to Length(PageItems) - 1 do
    CreatePage(PageItems[I].PageTitle, PageItems[I].PageText);

  if FTabSet.Tabs.Count = 0 then
    AddDefaultPage;

  FTabSet.TabIndex := 0;
end;

procedure TMainForm.SavePages;
var
  I: Integer;
  Memo: TPadMemo;
begin
  for I := 0 to GetMemoCount - 1 do
  begin
    Memo := GetMemo(I);
    if Memo.Modified then
    begin
      DataMgr.UpdatePage(I, FTabSet.Tabs[I], Memo.Text);
      Memo.Modified := False;
    end;
  end;
end;

procedure TMainForm.CreatePage(const PageTitle, PageText: string);
var
  Layer: TLayer;
  Memo: TPadMemo;
begin
  FTabSet.Tabs.Add(PageTitle);
  Layer := LayerList.NewLayer;

  Memo := TPadMemo.Create(Self);
  with Memo do
  begin
    Parent := Layer;
    Align := alClient;
    BorderStyle := bsNone;
    WantTabs := True;
    SetMemoWordWrap(WordWrapAction.Checked);
    ParentColor := True;
    HideSelection := False;
    Text := PageText;
    Modified := False;
  end;
  Memo.InitMargins;

  FTabSet.TabIndex := FTabSet.Tabs.Count - 1;
end;

procedure TMainForm.DestroyPage(PageIndex: Integer);
begin
  if (PageIndex >= 0) and (PageIndex < FTabSet.Tabs.Count) then
  begin
    LayerList.Layers[PageIndex].Free;
    FTabSet.Tabs.Delete(PageIndex);
    //OnTabSetClick(nil);
  end;
end;

procedure TMainForm.AddPage(const PageTitle, PageText: string);
begin
  CreatePage(PageTitle, PageText);
  DataMgr.AddPage(PageTitle);
  if Visible then
    GetActiveMemo.SetFocus;
end;

procedure TMainForm.RemovePage(PageIndex: Integer; RemoveToRecycle: Boolean);
begin
  DestroyPage(PageIndex);
  DataMgr.RemovePage(PageIndex, RemoveToRecycle);
end;

procedure TMainForm.AddDefaultPage;
begin
  AddPage(SDefPageTitle, '');
end;

procedure TMainForm.SetAllMemosWordWrap(WordWrap: Boolean);
var
  I: Integer;
  Memo: TPadMemo;
begin
  for I := 0 to GetMemoCount - 1 do
  begin
    Memo := GetMemo(I);
    Memo.SetMemoWordWrap(WordWrap);
  end;
end;

procedure TMainForm.LoadWinBounds;
begin
  Width := DefWinWidth;
  Height := DefWinHeight;
  Left := Screen.WorkAreaRect.Right - Width;
  Top := Screen.WorkAreaRect.Bottom - Height;

  if ConfigMgr.WinMaximized then
  begin
    WindowState := wsMaximized;
  end else
  begin
    if not IsRectEmpty(ConfigMgr.WinBounds) then
    begin
      BoundsRect := ConfigMgr.WinBounds;
      MakeFullyVisible;
    end;
  end;
end;

procedure TMainForm.SaveWinBounds;
begin
  ConfigMgr.WinMaximized := (WindowState = wsMaximized);
  if WindowState = wsNormal then
    ConfigMgr.WinBounds := Self.BoundsRect;
end;

procedure TMainForm.LoadPageIndex;
begin
  if (ConfigMgr.PageIndex >= 0) and (ConfigMgr.PageIndex < FTabSet.Tabs.Count) then
    FTabSet.TabIndex := ConfigMgr.PageIndex
  else
    FTabSet.TabIndex := 0;
end;

procedure TMainForm.SavePageIndex;
begin
  ConfigMgr.PageIndex := FTabSet.TabIndex;
end;

procedure TMainForm.LoadFromFile(const FileName: string);
var
  Memo: TPadMemo;
begin
  NewPageAction.Execute;

  Memo := GetActiveMemo;
  if Memo <> nil then
  begin
    Memo.Lines.LoadFromFile(FileName);
    Memo.Modified := True;
  end;
end;

procedure TMainForm.SaveAllData;
begin
  SavePages;
  SaveWinBounds;
  SavePageIndex;
end;

procedure TMainForm.DoAppMinimized;
begin
  HideMainForm;
end;

procedure TMainForm.DoAppRestored;
begin
  ShowMainForm;
end;

procedure TMainForm.AfterLoadConfig;
begin
  UpdateAutoRunOnStartup;
  UpdateHotKey;

  MemoPanel.Font.Assign(ConfigMgr.TextFont);
  MemoPanel.Color := ConfigMgr.BgColor;
  WordWrapAction.Checked := ConfigMgr.WordWrap;
  StayOnTopAction.Checked := ConfigMgr.StayOnTop;

  SetAllMemosWordWrap(WordWrapAction.Checked);
  SetStayOnTop(Self, StayOnTopAction.Checked);

  LoadWinBounds;
  LoadPageIndex;
end;

procedure TMainForm.AfterChangeConfig;
begin
  UpdateAutoRunOnStartup;
  UpdateHotKey;
end;

procedure TMainForm.SetHotKeyEnabled(Enabled: Boolean);
begin
  if Enabled then
    SysHotKey.SetAllEnabled
  else
    SysHotKey.SetAllDisabled;
end;

procedure TMainForm.UpdateAutoRunOnStartup;
begin
  SetAutoRunOnStartup(ConfigMgr.RunOnStartup, False, SSoftName, SParamMinimize);
end;

procedure TMainForm.UpdateHotKey;
begin
  with SysHotKey.HotKeys[0] do
  begin
    VirtualKey := ConfigMgr.HotKeyBase;
    Modifiers := ConfigMgr.HotKeyModifiers;
  end;
end;

procedure TMainForm.UpdateTrayPopupMenu;
begin
  TrayPopShowMainFormItem.Caption := Iif(Visible, '����������(&S)', '��ʾ������(&S)');
end;

procedure TMainForm.UpdateInsertMenu;
var
  I: Integer;
  S: string;
  MenuItem: TMenuItem;
  StartMenuIdx, EndMenuIdx: Integer;
begin
  StartMenuIdx := InsertMenu.IndexOf(InsertN1Item);
  EndMenuIdx := InsertMenu.IndexOf(InsertN2Item);

  for I := EndMenuIdx - 1 downto StartMenuIdx + 1 do
    InsertMenu.Delete(I);

  for I := 0 to ConfigMgr.InsertCustomList.Count - 1 do
  begin
    S := Trim(SingleLineToMultiLine(ConfigMgr.InsertCustomList[I]));
    S := ReplaceStr(S, #13, #32);
    S := ReplaceStr(S, #10, #32);

    MenuItem := TMenuItem.Create(Self);
    MenuItem.Caption := Format('&%d %s', [I + 1,
      RestrictStrWidth(Copy(S, 1, 100), Canvas, 100)]);
    MenuItem.Tag := I;
    MenuItem.OnClick := OnInsertCustomMenuItemClick;

    InsertMenu.Insert(StartMenuIdx + I + 1, MenuItem);
  end;
end;

procedure TMainForm.FindText;
var
  Memo: TPadMemo;
  I: Integer;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  I := SearchString(Memo.Text, Memo.SelStart, Memo.SelLength,
    FFindText, FSearchOptions);

  if I > 0 then
  begin
    Memo.SelStart := I - 1;
    Memo.SelLength := Length(FFindText);
  end else
    ShowMsgBox(Self, Format('�Ҳ�����%s��', [FFindText]));
end;

procedure TMainForm.ReplaceText;
var
  Memo: TPadMemo;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  if Memo.SelLength = 0 then
  begin
    FindText;
  end else
  begin
    if WideString(Memo.SelText) = FFindText then
      Memo.SetMemoSelText(FReplaceText, True);
    FindText;
  end;
end;

procedure TMainForm.ReplaceAllText;
var
  Memo: TPadMemo;
  OldText, NewText: WideString;
  ReplaceFlags: TReplaceFlags;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  ReplaceFlags := [rfReplaceAll];
  if not (soMatchCase in FSearchOptions) then
    Include(ReplaceFlags, rfIgnoreCase);

  OldText := Memo.Text;
  NewText := StringReplace(OldText, FFindText, FReplaceText, ReplaceFlags);

  if OldText <> NewText then
    Memo.Text := NewText
  else
    ShowMsgBox(Self, Format('�Ҳ�����%s��', [FFindText]));
end;

procedure TMainForm.AdjustAllMemosMargins;
var
  I: Integer;
  Memo: TPadMemo;
begin
  for I := 0 to GetMemoCount - 1 do
  begin
    Memo := GetMemo(I);
    Memo.InitMargins;
  end;
end;

procedure TMainForm.CreateTabSet;
begin
  FTabSet := TPadTabSet.Create(Self);
  FTabSet.Parent := TabSetPanel;
  FTabSet.Align := alClient;
  FTabSet.PopupMenu := TabSetPopupMenu;

  FTabSet.OnClick := OnTabSetClick;
  FTabSet.OnDblClick := OnTabSetDblClick;
  FTabSet.OnTabMoved := OnTabSetTabMoved;

  Mouse.DragImmediate := False;
end;

procedure TMainForm.InsertTextByCheckingExpr(const S: string);
var
  Memo: TPadMemo;
  ExprParser: TExprParser;
  Dest: string;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  ExprParser := TExprParser.Create;
  try
    try
      ExprParser.Execute(S);
      Dest := ExprParser.GetResultAsString;
    except
      Dest := S;
    end;

    Memo.SetMemoSelText(Dest, True);
  finally
    ExprParser.Free;
  end;
end;

function TMainForm.GetActiveMemo: TPadMemo;
begin
  Result := nil;
  if LayerList.ActiveLayer <> nil then
    Result := LayerList.ActiveLayer.Controls[0] as TPadMemo;
end;

function TMainForm.GetMemoCount: Integer;
begin
  Result := LayerList.LayerCount;
end;

function TMainForm.GetMemo(PageIndex: Integer): TPadMemo;
begin
  Assert((PageIndex >= 0) and (PageIndex < GetMemoCount));
  Result := LayerList.Layers[PageIndex].Controls[0] as TPadMemo;
end;

procedure TMainForm.DoFileDropMessage(var Msg: TMsg; var Handled: Boolean);
const
  BufferLength = MAX_PATH;
var
  DroppedFileName: string;
  FileIndex: UINT;
  DroppedFiles: Word;
  FileNameBuffer: array[0..BufferLength] of Char;
begin
  case Msg.Message of
    WM_DROPFILES:
      begin
        FileIndex := $FFFFFFFF;
        DroppedFiles := DragQueryFile(Msg.WParam, FileIndex, FileNameBuffer, BufferLength);

        for FileIndex := 0 to (DroppedFiles - 1) do
        begin
          DragQueryFile(Msg.WParam, FileIndex, FileNameBuffer, BufferLength);
          DroppedFileName := FileNameBuffer;
          LoadFromFile(DroppedFileName);
        end;
        DragFinish(Msg.WParam);
        Handled := True;
      end;
  end;
end;

procedure TMainForm.OnTabSetClick(Sender: TObject);
var
  Memo: TPadMemo;
begin
  LayerList.LayerIndex := FTabSet.TabIndex;

  Memo := GetActiveMemo;
  if Memo <> nil then
    Memo.InitMargins;
end;

procedure TMainForm.OnTabSetDblClick(Sender: TObject);
var
  P: TPoint;
  Index: Integer;
begin
  P := FTabSet.ScreenToClient(GetMouseCursorPos);
  Index := FTabSet.ItemAtPos(P);
  if (Index >= 0) and (Index < FTabSet.Tabs.Count) then
  begin
    case ConfigMgr.DblClickTitleActionType of
      dctDeletePage:
        DeletePageAction.Execute;
      dctChgPageTitle:
        ChgPageTitleAction.Execute;
    end;
  end else
  begin
    NewPageAction.Execute;
  end;
end;

procedure TMainForm.OnTabSetTabMoved(Sender: TObject;
  OldTabIndex, NewTabIndex: Integer);
begin
  LayerList.Layers[OldTabIndex].LayerIndex := NewTabIndex;
  DataMgr.MovePage(OldTabIndex, NewTabIndex);
end;

procedure TMainForm.OnInsertCustomMenuItemClick(Sender: TObject);
var
  I: Integer;
  S: string;
begin
  I := TMenuItem(Sender).Tag;
  S := ConfigMgr.InsertCustomList[I];
  S := SingleLineToMultiLine(S);

  InsertTextByCheckingExpr(S);
end;

procedure TMainForm.WMShowMainWindow(var Message: TMessage);
begin
  ShowMainForm;
end;

procedure TMainForm.WMSize(var Message: TWMSize);
begin
  inherited;
  case Message.Msg of
    WM_SIZE:
      case Message.SizeType of
        SIZE_MINIMIZED:    // Win+D captured
          DoAppMinimized;
      end;
  end;
end;

procedure TMainForm.WMQueryEndSession(var Message: TWMQueryEndSession);
begin
  inherited;

  // D2007��BUG: ��� Application.MainFormOnTaskbar ��Ϊ True��
  // ���ڹػ���ע���û�ʱ��������Ԫ�� finalization �ڲ���ִ�С�
  SaveAllData;
  ConfigMgr.Save;
end;

procedure TMainForm.ShowMainForm;
begin
  if WindowState = wsMinimized then
    ShowWindow(Handle, SW_RESTORE);
  Enabled := True;
  Show;
  SetForegroundWindow(Handle);

  if GetActiveMemo <> nil then
    GetActiveMemo.SetFocus;
end;

procedure TMainForm.HideMainForm;
begin
  Hide;
  Enabled := False;    // ��ֹ��С�������̺���Ȼ�������ȼ�����
  SavePages;

  if ConfigMgr.PromptMinToTray then
  begin
    TrayIcon.BalloonTitle := '��ʾ';
    TrayIcon.BalloonHint := '����˴�ͼ�꼴���ٴδ� FlashPad ���ڡ�';
    TrayIcon.BalloonTimeout := 10;
    TrayIcon.BalloonFlags := bfInfo;
    TrayIcon.ShowBalloonHint;

    ConfigMgr.PromptMinToTray := False;
  end;
end;

procedure TMainForm.LoadFromFileActionExecute(Sender: TObject);
var
  OpenDialog: TOpenDialog;
  Memo: TPadMemo;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  OpenDialog := TOpenDialog.Create(Application);
  try
    OpenDialog.Filter := 'Text Files(*.txt)|*.txt|All Files(*.*)|*.*';
    OpenDialog.Options := [ofHideReadOnly,ofFileMustExist,ofEnableSizing];
    OpenDialog.Title := '��';

    if OpenDialog.Execute then
      LoadFromFile(OpenDialog.FileName);
  finally
    OpenDialog.Free;
  end;
end;

procedure TMainForm.SaveToFileActionExecute(Sender: TObject);
var
  SaveDialog: TSaveDialog;
  Memo: TPadMemo;
begin
  Memo := GetActiveMemo;
  if Memo = nil then Exit;

  SaveDialog := TSaveDialog.Create(Application);
  try
    SaveDialog.DefaultExt := 'txt';
    SaveDialog.Filter := 'Text Files(*.txt)|*.txt|All Files(*.*)|*.*';
    SaveDialog.Options := [ofOverwritePrompt,ofHideReadOnly,ofEnableSizing];
    SaveDialog.Title := '����Ϊ';

    if SaveDialog.Execute then
      Memo.Lines.SaveToFile(SaveDialog.FileName, TEncoding.Unicode);
  finally
    SaveDialog.Free;
  end;
end;

procedure TMainForm.PrintActionExecute(Sender: TObject);
begin
//
end;

procedure TMainForm.HideActionExecute(Sender: TObject);
begin
  HideMainForm;
end;

procedure TMainForm.ExitActionExecute(Sender: TObject);
begin
  Application.Terminate;
end;

procedure TMainForm.FindActionExecute(Sender: TObject);
begin
  if GetActiveMemo <> nil then
    FindDialog.Execute;
end;

procedure TMainForm.FindNextActionExecute(Sender: TObject);
begin
  if GetActiveMemo <> nil then
  begin
    if Length(FFindText) = 0 then
      FindDialog.Execute
    else
      FindText;
  end;
end;

procedure TMainForm.ReplaceActionExecute(Sender: TObject);
begin
  if GetActiveMemo <> nil then
    ReplaceDialog.Execute;
end;

procedure TMainForm.FontActionExecute(Sender: TObject);
var
  Dialog: TFontDialog;
begin
  Dialog := TFontDialog.Create(Self);
  try
    Dialog.Font.Assign(MemoPanel.Font);
    if Dialog.Execute then
    begin
      MemoPanel.Font.Assign(Dialog.Font);
      ConfigMgr.TextFont.Assign(Dialog.Font);
      AdjustAllMemosMargins;
    end;
  finally
    Dialog.Free;
  end;
end;

procedure TMainForm.BgColorActionExecute(Sender: TObject);
var
  Dialog: TColorDialog;
begin
  Dialog := TColorDialog.Create(Self);
  try
    Dialog.Color := MemoPanel.Color;
    if Dialog.Execute then
    begin
      MemoPanel.Color := Dialog.Color;
      ConfigMgr.BgColor := Dialog.Color;
    end;
  finally
    Dialog.Free;
  end;
end;

procedure TMainForm.WordWrapActionExecute(Sender: TObject);
begin
  SetAllMemosWordWrap(WordWrapAction.Checked);
  ConfigMgr.WordWrap := WordWrapAction.Checked;
end;

procedure TMainForm.InsertLineActionExecute(Sender: TObject);
begin
  InsertTextByCheckingExpr(ConfigMgr.InsertLineText);
end;

procedure TMainForm.InsertDateActionExecute(Sender: TObject);
begin
  InsertTextByCheckingExpr(ConfigMgr.InsertDateText);
end;

procedure TMainForm.InsertLineDateActionExecute(Sender: TObject);
begin
  InsertTextByCheckingExpr(ConfigMgr.InsertLineDateText);
end;

procedure TMainForm.InsertConfigActionExecute(Sender: TObject);
begin
  ShowConfigForm(cptInsText);
end;

procedure TMainForm.NewPageActionExecute(Sender: TObject);

  function MakeNewPageTitle: string;
  var
    Exists: Boolean;
    I, Count: Integer;
  begin
    Result := SNewPageTitle;
    Count := 1;
    while True do
    begin
      Exists := False;
      for I := 0 to FTabSet.Tabs.Count - 1 do
        if Result = FTabSet.Tabs[I] then
        begin
          Exists := True;
          Break;
        end;
      if Exists then
      begin
        Result := Format('%s(%d)', [SNewPageTitle, Count]);
        Inc(Count);
      end else
        Break;
    end;
  end;

begin
  AddPage(MakeNewPageTitle, '');
end;

procedure TMainForm.DeletePageActionExecute(Sender: TObject);
var
  R, I: Integer;
  Memo: TPadMemo;
  RemoveToRecycle: Boolean;
begin
  if FTabSet.TabIndex < 0 then Exit;

  Memo := GetActiveMemo;
  RemoveToRecycle := (GetKeyState(VK_SHIFT) >= 0) and (Memo.Lines.Count > 0);

  if Memo.Lines.Count > 0 then
  begin
    R := ShowMsgBox(Self,
      Format('ȷʵɾ��ҳ�� ��%s�� ��', [FTabSet.Tabs[FTabSet.TabIndex]]),
      mtConfirmation, [mbYes, mbNo], mdDefBtn1);
    if R = mrNo then Exit;
  end;

  I := FTabSet.TabIndex;
  RemovePage(I, RemoveToRecycle);

  if FTabSet.Tabs.Count = 0 then
    AddDefaultPage;
end;

procedure TMainForm.ChgPageTitleActionExecute(Sender: TObject);
var
  PageTitle: string;
  PageIndex: Integer;
begin
  if FTabSet.TabIndex < 0 then Exit;

  PageIndex := FTabSet.TabIndex;
  PageTitle := FTabSet.Tabs[FTabSet.TabIndex];

  if ShowInputForm(Self, '�޸�ҳ�����', '����:', PageTitle, False, False) then
  begin
    DataMgr.RenamePage(PageIndex, PageTitle);
    FTabSet.Tabs[FTabSet.TabIndex] := PageTitle;
  end;
end;

procedure TMainForm.NextPageActionExecute(Sender: TObject);
begin
  if FTabSet.Tabs.Count > 0 then
  begin
    if FTabSet.TabIndex >= FTabSet.Tabs.Count - 1 then
      FTabSet.TabIndex := 0 else
      FTabSet.TabIndex := FTabSet.TabIndex + 1;
  end;
end;

procedure TMainForm.PrevPageActionExecute(Sender: TObject);
begin
  if FTabSet.Tabs.Count > 0 then
  begin
    if FTabSet.TabIndex <= 0 then
      FTabSet.TabIndex := FTabSet.Tabs.Count - 1 else
      FTabSet.TabIndex := FTabSet.TabIndex - 1;
  end;
end;

procedure TMainForm.StayOnTopActionExecute(Sender: TObject);
begin
  SetStayOnTop(Self, StayOnTopAction.Checked);
  ConfigMgr.StayOnTop := StayOnTopAction.Checked;
end;

procedure TMainForm.ConfigActionExecute(Sender: TObject);
begin
  SetHotKeyEnabled(False);
  try
    if ShowConfigForm then
    begin
      ConfigMgr.Save;
      AfterChangeConfig;
    end;
  finally
    SetHotKeyEnabled(True);
  end;
end;

procedure TMainForm.ReadmeActionExecute(Sender: TObject);
begin
  ExecuteFile(GetAppPath + SReadmeFileName, '', '', SW_SHOW);
end;

procedure TMainForm.HotKeyListActionExecute(Sender: TObject);
begin
  ShowShortcutsForm(Self);
end;

procedure TMainForm.AboutActionExecute(Sender: TObject);
begin
  ShowAboutForm;
end;

procedure TMainForm.PopupPickMenuActionExecute(Sender: TObject);
begin
  FTabSet.PopupPickMenu;
end;

procedure TMainForm.TrayIconDblClick(Sender: TObject);
begin
  TrayIconMouseDown(Sender, mbLeft, [], 0, 0);
end;

procedure TMainForm.TrayIconMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  if Application.ModalLevel > 0 then Exit;

  if Button = mbLeft then
  begin
    if Visible then
      HideMainForm
    else
      ShowMainForm;
  end;
end;

procedure TMainForm.ApplicationEventsMessage(var Msg: tagMSG;
  var Handled: Boolean);
begin
  case Msg.Message of
    WM_DROPFILES:
      DoFileDropMessage(Msg, Handled);
  end;
end;

procedure TMainForm.ApplicationEventsMinimize(Sender: TObject);
begin
  DoAppMinimized;
end;

procedure TMainForm.ApplicationEventsRestore(Sender: TObject);
begin
  DoAppRestored;
end;

procedure TMainForm.SaveTimerTimer(Sender: TObject);
begin
  SavePages;
end;

procedure TMainForm.SysHotKeyHotKeys0HotKey(Sender: TObject);
begin
  if Application.ModalLevel > 0 then Exit;

  if Visible then
  begin
    if GetForegroundWindow <> Handle then
      ShowMainForm
    else
      HideMainForm;
  end else
    ShowMainForm;
end;

procedure TMainForm.FindDialogFind(Sender: TObject);
begin
  FFindText := FindDialog.FindText;
  FSearchOptions := [];
  if frDown in FindDialog.Options then
    Include(FSearchOptions, soDown);
  if frMatchCase in FindDialog.Options then
    Include(FSearchOptions, soMatchCase);

  FindText;
end;

procedure TMainForm.ReplaceDialogFind(Sender: TObject);
begin
  FFindText := ReplaceDialog.FindText;
  FSearchOptions := [];
  Include(FSearchOptions, soDown);
  if frMatchCase in ReplaceDialog.Options then
    Include(FSearchOptions, soMatchCase);

  FindText;
end;

procedure TMainForm.ReplaceDialogReplace(Sender: TObject);
begin
  FFindText := ReplaceDialog.FindText;
  FReplaceText := ReplaceDialog.ReplaceText;
  FSearchOptions := [];
  Include(FSearchOptions, soDown);
  if frMatchCase in ReplaceDialog.Options then
    Include(FSearchOptions, soMatchCase);

  if frReplace in ReplaceDialog.Options then
    ReplaceText
  else if frReplaceAll in ReplaceDialog.Options then
    ReplaceAllText;
end;

procedure TMainForm.TrayPopShowMainFormItemClick(Sender: TObject);
begin
  if Application.ModalLevel > 0 then Exit;

  if Visible then
    HideMainForm
  else
    ShowMainForm;
end;

procedure TMainForm.TrayPopupMenuPopup(Sender: TObject);
begin
  UpdateTrayPopupMenu;
end;

procedure TMainForm.InsertMenuClick(Sender: TObject);
begin
  UpdateInsertMenu;
end;

end.
