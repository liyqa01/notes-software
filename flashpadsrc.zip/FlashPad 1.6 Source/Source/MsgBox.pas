unit MsgBox;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Consts, Math, ExtCtrls, BaseFrm;

const
  MsgBoxButtonHeight = 23;

type
  TMsgDlgDefBtn = (mdDefBtn1, mdDefBtn2, mdDefBtn3);

// ����Ļ������ʾ��Ϣ�Ի��򣬵ײ����д�����á�
function ShowMsgBox(const Msg: string; DlgType: TMsgDlgType = mtInformation;
  Buttons: TMsgDlgButtons = [mbOK];
  DefButton: TMsgDlgDefBtn = mdDefBtn1): Integer; overload;

// �� OwnerForm ��������ʾ��Ϣ�Ի��򣬵ײ����д�����á�
function ShowMsgBox(OwnerForm: TCustomForm; const Msg: string;
  DlgType: TMsgDlgType = mtInformation; Buttons: TMsgDlgButtons = [mbOK];
  DefButton: TMsgDlgDefBtn = mdDefBtn1): Integer; overload;

var
  MsgBoxCounter: Integer;

implementation

resourcestring
  SMsgDlgWarning      = '����';
  SMsgDlgError        = '����';
  SMsgDlgInformation  = '��ʾ';
  SMsgDlgConfirm      = 'ȷ��';
  SMsgDlgYes          = '��(&Y)';
  SMsgDlgNo           = '��(&N)';
  SMsgDlgOK           = 'ȷ��';
  SMsgDlgCancel       = 'ȡ��';
  SMsgDlgHelp         = '����';
  SMsgDlgAbort        = '��ֹ';
  SMsgDlgRetry        = '����';
  SMsgDlgIgnore       = '����';
  SMsgDlgAll          = 'ȫ��';
  SMsgDlgNoToAll      = 'ȫ����';
  SMsgDlgYesToAll     = 'ȫ����';
  SMsgDlgClose        = '�ر�';

var
  Captions: array[TMsgDlgType] of Pointer = (@SMsgDlgWarning, @SMsgDlgError,
    @SMsgDlgInformation, @SMsgDlgConfirm, nil);
  IconIDs: array[TMsgDlgType] of PChar = (IDI_EXCLAMATION, IDI_HAND,
    IDI_ASTERISK, IDI_EXCLAMATION {IDI_QUESTION}, nil);
  ButtonCaptions: array[TMsgDlgBtn] of Pointer = (
    @SMsgDlgYes, @SMsgDlgNo, @SMsgDlgOK, @SMsgDlgCancel, @SMsgDlgAbort,
    @SMsgDlgRetry, @SMsgDlgIgnore, @SMsgDlgAll, @SMsgDlgNoToAll, @SMsgDlgYesToAll,
    @SMsgDlgHelp, @SMsgDlgClose);
  ModalResults: array[TMsgDlgBtn] of Integer = (
    mrYes, mrNo, mrOk, mrCancel, mrAbort, mrRetry, mrIgnore, mrAll, mrNoToAll,
    mrYesToAll, 0, mrClose);
  ButtonWidths : array[TMsgDlgBtn] of Integer;  // initialized to zero

{ TMessageForm }

type

  TMessageForm = class(TBaseForm)
  private
    MsgLabel: TLabel;
    WinPanel: TPanel;
    procedure HelpButtonClick(Sender: TObject);
  end;

procedure TMessageForm.HelpButtonClick(Sender: TObject);
begin
  Application.HelpContext(HelpContext);
end;

{ Misc Routines }

function GetAveCharSize(Canvas: TCanvas): TPoint;
var
  I: Integer;
  Buffer: array[0..51] of Char;
begin
  for I := 0 to 25 do Buffer[I] := Chr(I + Ord('A'));
  for I := 0 to 25 do Buffer[I + 26] := Chr(I + Ord('a'));
  GetTextExtentPoint(Canvas.Handle, Buffer, 52, TSize(Result));
  Result.X := Result.X div 52;
end;

function CreateMessageDialog(OwnerForm: TCustomForm; const Msg: string;
  DlgType: TMsgDlgType; Buttons: TMsgDlgButtons; DefButton: TMsgDlgDefBtn): TMessageForm;
const
  mcHorzMargin = 8;
  mcVertMargin = 7;
  mcHorzSpacing = 15;
  mcVertSpacing = 10;
  mcButtonWidth = 50;
  mcButtonHeight = 14;
  mcButtonSpacing = 4;
var
  DialogUnits: TPoint;
  HorzMargin, VertMargin, HorzSpacing, VertSpacing, ButtonWidth,
  ButtonHeight, ButtonSpacing, ButtonCount, ButtonGroupWidth,
  IconTextWidth, IconTextHeight, X, ALeft, Index: Integer;
  B, DefaultButton, CancelButton: TMsgDlgBtn;
  IconID: PChar;
  TextRect: TRect;
begin
  Result := TMessageForm.Create(OwnerForm);
  with Result do
  begin
    BiDiMode := Application.BiDiMode;
    BorderStyle := bsDialog;
    BorderIcons := [biSystemMenu];
    Canvas.Font := Font;
    KeyPreview := True;

    WinPanel := TPanel.Create(Result);
    with WinPanel do
    begin
      Parent := Result;
      Align := alClient;
      ParentColor := True;
      BevelOuter := bvNone;
    end;

    DialogUnits := GetAveCharSize(Canvas);
    HorzMargin := MulDiv(mcHorzMargin, DialogUnits.X, 4);
    VertMargin := MulDiv(mcVertMargin, DialogUnits.Y, 8);
    HorzSpacing := MulDiv(mcHorzSpacing, DialogUnits.X, 4);
    VertSpacing := MulDiv(mcVertSpacing, DialogUnits.Y, 8);
    ButtonWidth := MulDiv(mcButtonWidth, DialogUnits.X, 4);
    for B := Low(TMsgDlgBtn) to High(TMsgDlgBtn) do
    begin
      if B in Buttons then
      begin
        if ButtonWidths[B] = 0 then
        begin
          TextRect := Rect(0,0,0,0);
          Windows.DrawText(Canvas.Handle,
            PChar(LoadResString(ButtonCaptions[B])), -1,
            TextRect, DT_CALCRECT or DT_LEFT or DT_SINGLELINE or
            DrawTextBiDiModeFlagsReadingOnly);
          with TextRect do ButtonWidths[B] := Right - Left + 50;
        end;
        if ButtonWidths[B] > ButtonWidth then
          ButtonWidth := ButtonWidths[B];
      end;
    end;
    ButtonHeight := MsgBoxButtonHeight;
    ButtonSpacing := MulDiv(mcButtonSpacing, DialogUnits.X, 4);
    SetRect(TextRect, 0, 0, Screen.Width div 2, 0);
    DrawText(Canvas.Handle, PChar(Msg), Length(Msg)+1, TextRect,
      DT_EXPANDTABS or DT_CALCRECT or DT_WORDBREAK or
      DrawTextBiDiModeFlagsReadingOnly);
    IconID := IconIDs[DlgType];
    IconTextWidth := TextRect.Right;
    IconTextHeight := TextRect.Bottom;
    if IconID <> nil then
    begin
      Inc(IconTextWidth, 32 + HorzSpacing);
      if IconTextHeight < 32 then IconTextHeight := 32;
    end;
    ButtonCount := 0;
    for B := Low(TMsgDlgBtn) to High(TMsgDlgBtn) do
      if B in Buttons then Inc(ButtonCount);
    ButtonGroupWidth := 0;
    if ButtonCount <> 0 then
      ButtonGroupWidth := ButtonWidth * ButtonCount +
        ButtonSpacing * (ButtonCount - 1);
    Result.ClientWidth := Max(IconTextWidth, ButtonGroupWidth) + HorzMargin * 2;
    Result.ClientHeight := IconTextHeight + ButtonHeight + VertSpacing + VertMargin * 2;
    Left := (Screen.Width div 2) - (Width div 2);
    Top := (Screen.Height div 2) - (Height div 2);
    if DlgType <> mtCustom then
      Caption := LoadResString(Captions[DlgType]) else
      Caption := Application.Title;

    if IconID <> nil then
      with TImage.Create(Result) do
      begin
        Parent := WinPanel;
        Picture.Icon.Handle := LoadIcon(0, IconID);
        SetBounds(HorzMargin, VertMargin, 32, 32);
      end;

    TMessageForm(Result).MsgLabel := TLabel.Create(Result);
    with TMessageForm(Result).MsgLabel do
    begin
      Parent := WinPanel;
      Transparent := True;
      WordWrap := True;
      Layout := tlCenter;
      Caption := Msg;
      BoundsRect := TextRect;
      BiDiMode := Result.BiDiMode;
      ALeft := IconTextWidth - TextRect.Right + HorzMargin;
      if UseRightToLeftAlignment then
        ALeft := Result.ClientWidth - ALeft - Width;
      SetBounds(ALeft, VertMargin,
        TextRect.Right, Max(TextRect.Bottom, IconTextHeight));
    end;

    if mbOk in Buttons then DefaultButton := mbOk else
      if mbYes in Buttons then DefaultButton := mbYes else
        DefaultButton := mbRetry;
    if mbCancel in Buttons then CancelButton := mbCancel else
      if mbNo in Buttons then CancelButton := mbNo else
        CancelButton := mbOk;
    X := (ClientWidth - ButtonGroupWidth) div 2;
    Index := 0;
    for B := Low(TMsgDlgBtn) to High(TMsgDlgBtn) do
      if B in Buttons then
        with TButton.Create(Result) do
        begin
          Parent := WinPanel;
          Caption := LoadResString(ButtonCaptions[B]);
          ModalResult := ModalResults[B];
          if B = DefaultButton then Default := True;
          if B = CancelButton then Cancel := True;
          SetBounds(X, IconTextHeight + VertMargin + VertSpacing, ButtonWidth, ButtonHeight);
          Inc(X, ButtonWidth + ButtonSpacing);
          if B = mbHelp then
            OnClick := TMessageForm(Result).HelpButtonClick;
          if Index = Ord(DefButton) then
            TabOrder := 0;
          Inc(Index);
        end;
  end;
end;

function DisplayMsgBox(OwnerForm: TCustomForm; const Msg: string;
  DlgType: TMsgDlgType; Buttons: TMsgDlgButtons; DefButton: TMsgDlgDefBtn;
  HelpCtx: Longint; const HelpFileName: string): Integer;
var
  R: TRect;
  P: TPoint;
  MsgForm: TMessageForm;
begin
  Inc(MsgBoxCounter);
  try
    if (OwnerForm <> nil) and (OwnerForm.WindowState <> wsMinimized) then
    begin
      R := OwnerForm.BoundsRect;
      P := R.TopLeft;
      P := Point(P.X + (R.Right - R.Left) div 2, P.Y + (R.Bottom - R.Top) div 2);
    end else
      P := Point(Screen.Width div 2, Screen.Height div 2);

    MsgForm := CreateMessageDialog(OwnerForm, Msg, DlgType, Buttons, DefButton);
    with MsgForm do
    try
      Position := poDesigned;
      HelpContext := HelpCtx;
      HelpFile := HelpFileName;
      Left := P.X - Width div 2;
      Top := P.Y - Height div 2;

      Result := ShowModal;
      if (Result = mrCancel) and not (mbCancel in Buttons) then
      begin
        if mbNo in Buttons then Result := mrNo
        else if mbAbort in Buttons then Result := mrAbort;
      end;
    finally
      MsgForm.Free;
    end;
  finally
    Dec(MsgBoxCounter);
  end;
end;

function ShowMsgBox(const Msg: string; DlgType: TMsgDlgType;
  Buttons: TMsgDlgButtons; DefButton: TMsgDlgDefBtn): Integer;
begin
  Result := DisplayMsgBox(nil, Msg, DlgType, Buttons, DefButton, 0, '');
end;

function ShowMsgBox(OwnerForm: TCustomForm; const Msg: string; DlgType: TMsgDlgType;
  Buttons: TMsgDlgButtons; DefButton: TMsgDlgDefBtn): Integer;
begin
  Result := DisplayMsgBox(OwnerForm, Msg, DlgType, Buttons, DefButton, 0, '');
end;

end.
