unit PadMemo;

interface

uses
  Windows, Messages, SysUtils, Classes, StdCtrls, Dialogs, StrUtils,
  Forms, ExprParser;

type

  TPadMemo = class(TMemo)
  private
    function GetNearestLineStr: string;
    procedure ProcessCalculator;
  protected
    procedure KeyPress(var Key: Char); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    procedure InitMargins;
    procedure SetMemoSelText(const S: string; CanUndo: Boolean);
    procedure SetMemoWordWrap(Value: Boolean);
  end;

implementation

uses MsgBox, MainFrm;

const
  CrLfChars = [#10, #13];
  SCrLf = #13#10;

var
  FExprParser: TExprParser;

{ TPadMemo }

constructor TPadMemo.Create(AOwner: TComponent);
begin
  inherited;
end;

destructor TPadMemo.Destroy;
begin
  inherited;
end;

function TPadMemo.GetNearestLineStr: string;
var
  S: string;
  CurPos, I: Integer;
begin
  Result := '';
  S := Self.Text;
  if Length(S) > 0 then
  begin
    CurPos := Self.SelStart;
    I := CurPos;
    while (I > 0) and CharInSet(S[I], CrLfChars) do Dec(I);

    while I > 0 do
    begin
      if CharInSet(S[I], CrLfChars) then
      begin
        Inc(I);
        Break;
      end;
      Dec(I);
    end;
    if I <= 0 then I := 1;

    while I <= CurPos do
    begin
      Result := Result + S[I];
      Inc(I);
    end;
  end;
end;

procedure TPadMemo.ProcessCalculator;
var
  OrgExpr, Expr, Result, PrintStr: string;
  HasEquChar: Boolean;
begin
  OrgExpr := GetNearestLineStr;
  Expr := Trim(OrgExpr);
  if Length(Expr) > 0 then
  begin
    HasEquChar := (Expr[Length(Expr)] = '=');
    if HasEquChar then
      Delete(Expr, Length(Expr), 1);

    try
      FExprParser.Execute(Expr);
      Result := FExprParser.GetResultForDisplay;
    except
      on E: Exception do
      begin
        ShowMsgBox(MainForm, E.Message);
        Exit;
      end;
    end;

    PrintStr := '';
    if OrgExpr[Length(OrgExpr)] <> ' ' then
      PrintStr := PrintStr + ' ';
    if not HasEquChar then
      PrintStr := PrintStr + '= ';
    PrintStr := PrintStr + Result + SCrLf;

    SetMemoSelText(PrintStr, True);
  end;
end;

procedure TPadMemo.KeyPress(var Key: Char);
begin
  inherited;

  // Ctrl + Return
  if Key = Char(10) then
  begin
    Key := #0;
    ProcessCalculator;
  end;
end;

procedure TPadMemo.InitMargins;
var
  OldRect, NewRect: TRect;
begin
  FillChar(OldRect, SizeOf(OldRect), 0);
  SendMessage(Handle, EM_GETRECT, 0, LongInt(@OldRect));

  NewRect := Self.ClientRect;
  InflateRect(NewRect, -4, -4);

  if OldRect.Left <> NewRect.Left then
    SendMessage(Handle, EM_SETRECT, 0, LongInt(@NewRect));
end;

procedure TPadMemo.SetMemoSelText(const S: string; CanUndo: Boolean);
begin
  SendMessage(Handle, EM_REPLACESEL, Ord(CanUndo), Longint(PWideChar(S)));
end;

procedure TPadMemo.SetMemoWordWrap(Value: Boolean);
begin
  WordWrap := Value;
  if Value then
    ScrollBars := ssVertical else
    ScrollBars := ssBoth;
  InitMargins;
end;

initialization
  FExprParser := TExprParser.Create;

finalization
  FExprParser.Free;

end.
