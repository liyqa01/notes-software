unit PadTabSet;

interface

uses
  Windows, Messages, SysUtils, Classes, Controls, Forms, Consts,
  Graphics, Menus, ExtCtrls, Math, Dialogs;

const
  TabHeight = 25;
  FirstTabLeft = 26;
  TabTop = 2;
  TabSpace = 2;
  MaxTabWidth = 100;
  PickBtnWidth = 22;
  PickBtnHeight = 18;
  ScrollBtnWidth = 15;
  ScrollBtnHeight = 15;

type

{ Classes }

  TCustomPadTabSet = class;
  TPadTabSet = class;
  TTabList = class;
  TPickButton = class;
  TScrollButton = class;

{ Types }

  TImageState = (isUp, isDown, isHover, isDisabled);
  TScrollBtnType = (sbtLeft, sbtRight);

{ TCustomPadTabSet }

  TTabIndexChangeEvent = procedure(Sender: TObject; NewTab: Integer;
    var AllowChange: Boolean) of object;
  TTabIndexMovedEvent = procedure(Sender: TObject; OldTabIndex: Integer;
    NewTabIndex: Integer) of object;

  TCustomPadTabSet = class(TCustomControl)
  private
    FTabs: TStrings;
    FTabIndex: Integer;
    FFirstTabIndex: Integer;
    FVisibleTabCount: Integer;
    FMouseHoverTabIndex: Integer;
    FDragTabIndex: Integer;
    FPickButton: TPickButton;
    FScrollLeftBtn: TScrollButton;
    FScrollRightBtn: TScrollButton;
    FOnChange: TTabIndexChangeEvent;
    FOnTabMoved: TTabIndexMovedEvent;
  private
    procedure SetTabList(Value: TStrings);
    procedure SetTabIndex(Value: Integer);
    procedure SetFirstTabIndex(Value: Integer);
    function GetTabAreaWidth: Integer;
    function GetMaxTabWidth: Integer;
    function CanChange(NewIndex: Integer): Boolean;
    function GetSkinBitmap(const BitmapName: string): TBitmap;
    function IsTabVisible(Index: Integer): Boolean;
    procedure MakeTabVisible(Index: Integer);
    procedure IncFirstTabIndex;
    procedure DecFirstTabIndex;
    procedure UpdateVisibleTabCount;
    procedure UpdateScrollButtons;
    procedure Rearrange;

    procedure DoDrawBackground(DestCanvas: TCanvas; const DestRect: TRect);
    procedure DoDrawTab(DestCanvas: TCanvas; const DestRect: TRect;
      ImageState: TImageState; const Caption: string);
    procedure DoDrawPickButton(DestCanvas: TCanvas; const DestRect: TRect;
      ImageState: TImageState);
    procedure DoDrawScrollButton(DestCanvas: TCanvas; const DestRect: TRect;
      ImageState: TImageState; ButtonType: TScrollBtnType);
  private
    procedure CMMouseEnter(var Message: TMessage); message CM_MOUSEENTER;
    procedure CMMouseLeave(var Message: TMessage); message CM_MOUSELEAVE;
    procedure WMEraseBkgnd(var Message: TWmEraseBkgnd); message WM_ERASEBKGND;
    procedure WMWindowPosChanged(var Message: TWMWindowPosChanged); message WM_WINDOWPOSCHANGED;
  protected
    procedure CreateParams(var Params: TCreateParams); override;
    procedure WndProc(var Message: TMessage); override;
    procedure Paint; override;
    procedure Loaded; override;
    procedure Resize; override;
    procedure DblClick; override;
    procedure MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure MouseMove(Shift: TShiftState; X, Y: Integer); override;
    function DoMouseWheel(Shift: TShiftState; WheelDelta: Integer; MousePos: TPoint): Boolean; override;
    procedure DoStartDrag(var DragObject: TDragObject); override;
    procedure DragOver(Source: TObject; X, Y: Integer; State: TDragState; var Accept: Boolean); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    procedure Invalidate; override;

    function ItemAtPos(Pos: TPoint): Integer;
    function ItemRect(Index: Integer): TRect;
    function ItemWidth(Index: Integer): Integer;

    procedure PopupPickMenu;

    property Canvas;
    property Tabs: TStrings read FTabs write SetTabList;
    property TabIndex: Integer read FTabIndex write SetTabIndex default -1;
    property FirstTabIndex: Integer read FFirstTabIndex write SetFirstTabIndex default 0;
    property VisibleTabCount: Integer read FVisibleTabCount;

    property OnChange: TTabIndexChangeEvent read FOnChange write FOnChange;
    property OnTabMoved: TTabIndexMovedEvent read FOnTabMoved write FOnTabMoved;
  end;

{ TPadTabSet }

  TPadTabSet = class(TCustomPadTabSet)
  published
    property Tabs;
    property TabIndex;
    property OnChange;
    property OnTabMoved;

    property Align;
    property Anchors;
    property AutoSize;
    property Font;
    property Constraints;
    property DragCursor;
    property DragKind;
    property DragMode;
    property Enabled;
    property ParentColor;
    property ParentFont;
    property ParentShowHint;
    property PopupMenu;
    property ShowHint;
    property Visible;

    property OnClick;
    property OnContextPopup;
    property OnDblClick;
    property OnDragDrop;
    property OnDragOver;
    property OnEndDock;
    property OnEndDrag;
    property OnResize;
    property OnMouseDown;
    property OnMouseMove;
    property OnMouseUp;
    property OnMouseEnter;
    property OnMouseLeave;
    property OnStartDock;
    property OnStartDrag;
  end;

{ TTabList }

  TTabList = class(TStringList)
  private
    FTabSet: TCustomPadTabSet;
  protected
    procedure Put(Index: Integer; const S: string); override;
  public
    constructor Create(const ATabSet: TCustomPadTabSet);
    procedure Insert(Index: Integer; const S: string); override;
    procedure Delete(Index: Integer); override;
    function Add(const S: string): Integer; override;
    procedure Clear; override;
    procedure Move(CurIndex, NewIndex: Integer); override;
    procedure AddStrings(Strings: TStrings); override;
  end;

{ TPickButton }

  TPickButton = class(TCustomControl)
  private
    FTabSet: TCustomPadTabSet;
    FMouseInControl: Boolean;
    FPickMenu: TPopupMenu;
  private
    procedure InitPickMenu;
    procedure OnMenuItemClick(Sender: TObject);
    procedure CMMouseEnter(var Message: TMessage); message CM_MOUSEENTER;
    procedure CMMouseLeave(var Message: TMessage); message CM_MOUSELEAVE;
  protected
    procedure Paint; override;
    procedure MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure MouseMove(Shift: TShiftState; X, Y: Integer); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    procedure PopupPickMenu;
  end;

{ TScrollButton }

  TScrollButton = class(TCustomControl)
  private
    FTabSet: TCustomPadTabSet;
    FButtonType: TScrollBtnType;
    FMouseInControl: Boolean;
  private
    procedure CMMouseEnter(var Message: TMessage); message CM_MOUSEENTER;
    procedure CMMouseLeave(var Message: TMessage); message CM_MOUSELEAVE;
    procedure CMEnabledChanged(var Message: TMessage); message CM_ENABLEDCHANGED;
  protected
    procedure Paint; override;
    procedure MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer); override;
    procedure MouseMove(Shift: TShiftState; X, Y: Integer); override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    property ButtonType: TScrollBtnType read FButtonType;
  end;

implementation

type

  // ͼƬ��Ƭ��ʽ
  TImageSliceMode = (ismHori, ismVert, ismHV);
  // ͼƬ��Ƭ����
  TImageSliceRule = record
  case SliceMode: TImageSliceMode of
    ismHori, ismVert: (
      HeadSize: Integer;
      TailSize: Integer;
      );
    ismHV: (
      HoriHeadSize, HoriTailSize: Integer;
      VertHeadSize, VertTailSize: Integer;
      );
  end;

{ Misc Routines }

//-----------------------------------------------------------------------------
// ����: �൱��C�����е� exp ? v1 : v2
//-----------------------------------------------------------------------------
function Iif(Value: Boolean; Value1, Value2: Variant): Variant;
begin
  if Value then Result := Value1
  else Result := Value2;
end;

//-----------------------------------------------------------------------------
// ����: ���ؾ��� R �Ŀ���
//-----------------------------------------------------------------------------
function GetRectWidth(const R: TRect): Integer;
begin
  Result := R.Right - R.Left;
end;

//-----------------------------------------------------------------------------
// ����: ���ؾ��� R �ĸ߶�
//-----------------------------------------------------------------------------
function GetRectHeight(const R: TRect): Integer;
begin
  Result := R.Bottom - R.Top;
end;

//-----------------------------------------------------------------------------
// ����: ��ͨ����
//-----------------------------------------------------------------------------
procedure DrawNormal(DestCanvas: TCanvas; const DestRect: TRect;
  SrcImage: TBitmap; const SrcRect: TRect);
begin
  DestCanvas.CopyRect(DestRect, SrcImage.Canvas, SrcRect);
end;

//-----------------------------------------------------------------------------
// ����: ƽ�̻���
//-----------------------------------------------------------------------------
procedure DrawTile(DestCanvas: TCanvas; const DestRect: TRect;
  SrcImage: TBitmap; const SrcRect: TRect);
var
  X, Y: Integer;
  SrcWidth, SrcHeight: Integer;
  SR, DR: TRect;
begin
  SrcWidth := SrcRect.Right - SrcRect.Left;
  SrcHeight := SrcRect.Bottom - SrcRect.Top;
  if (SrcWidth <= 0) or (SrcHeight <= 0) then Exit;

  Y := DestRect.Top;
  while Y < DestRect.Bottom do
  begin
    X := DestRect.Left;
    while X < DestRect.Right do
    begin
      DR := Rect(X, Y, X + SrcWidth, Y + SrcHeight);
      if DR.Right > DestRect.Right then DR.Right := DestRect.Right;
      if DR.Bottom > DestRect.Bottom then DR.Bottom := DestRect.Bottom;
      SR := Rect(SrcRect.Left, SrcRect.Top, SrcRect.Left + GetRectWidth(DR), SrcRect.Top + GetRectHeight(DR));

      DestCanvas.CopyRect(DR, SrcImage.Canvas, SR);
      Inc(X, SrcWidth);
    end;
    Inc(Y, SrcHeight);
  end;
end;

//-----------------------------------------------------------------------------
// ����: ��Ƭ����
//-----------------------------------------------------------------------------
procedure DrawSlice(DestCanvas: TCanvas; const DestRect: TRect;
  SrcImage: TBitmap; const SrcRect: TRect; const SliceRule: TImageSliceRule);

  procedure DoDrawSlice(const SrcRect, DestRect: TRect; Tile: Boolean);
  begin
    if Tile then
      DrawTile(DestCanvas, DestRect, SrcImage, SrcRect)
    else
      DrawNormal(DestCanvas, DestRect, SrcImage, SrcRect);
  end;

var
  HoriHeadSize, HoriTailSize: Integer;
  VertHeadSize, VertTailSize: Integer;
  SW, SH, DW, DH: Integer;
  SRect, DRect: TRect;
begin
  SW := GetRectWidth(SrcRect);
  SH := GetRectHeight(SrcRect);
  DW := GetRectWidth(DestRect);
  DH := GetRectHeight(DestRect);

  case SliceRule.SliceMode of
    ismHori:
      begin
        HoriHeadSize := Min(SliceRule.HeadSize, SW);
        HoriTailSize := Min(SliceRule.TailSize, SW);
        // ͷ
        if HoriHeadSize > 0 then
        begin
          SRect := SrcRect;
          SRect.Right := SRect.Left + HoriHeadSize;
          DRect := Rect(0, 0, HoriHeadSize, SH);
          OffsetRect(DRect, DestRect.Left, DestRect.Top);
          DoDrawSlice(SRect, DRect, False);
        end;
        // β
        if HoriTailSize > 0 then
        begin
          SRect := SrcRect;
          SRect.Left := SRect.Right - HoriTailSize;
          DRect := Rect(DW - HoriTailSize, 0, DW, SH);
          OffsetRect(DRect, DestRect.Left, DestRect.Top);
          DoDrawSlice(SRect, DRect, False);
        end;
        // �м�
        SRect := SrcRect;
        SRect.Left := SrcRect.Left + HoriHeadSize;
        SRect.Right := SrcRect.Left + SW - HoriTailSize;
        DRect := Rect(HoriHeadSize, 0, DW - HoriTailSize, SH);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
      end;
    ismVert:
      begin
        VertHeadSize := Min(SliceRule.HeadSize, SH);
        VertTailSize := Min(SliceRule.TailSize, SH);
        // ͷ
        if VertHeadSize > 0 then
        begin
          SRect := SrcRect;
          SRect.Bottom := SRect.Top + VertHeadSize;
          DRect := Rect(0, 0, SW, VertHeadSize);
          OffsetRect(DRect, DestRect.Left, DestRect.Top);
          DoDrawSlice(SRect, DRect, False);
        end;
        // β
        if VertTailSize > 0 then
        begin
          SRect := SrcRect;
          SRect.Top := SRect.Bottom - VertTailSize;
          DRect := Rect(0, DH - VertTailSize, SW, DH);
          OffsetRect(DRect, DestRect.Left, DestRect.Top);
          DoDrawSlice(SRect, DRect, False);
        end;
        // �м�
        SRect := SrcRect;
        SRect.Top := SrcRect.Top + VertHeadSize;
        SRect.Bottom := SrcRect.Top + SH - VertTailSize;
        DRect := Rect(0, VertHeadSize, SW, DH - VertTailSize);
        DoDrawSlice(SRect, DRect, True);
      end;
    ismHV:
      begin
        HoriHeadSize := SliceRule.HoriHeadSize;
        HoriTailSize := SliceRule.HoriTailSize;
        VertHeadSize := SliceRule.VertHeadSize;
        VertTailSize := SliceRule.VertTailSize;

        // ����
        SRect := Rect(0, 0, HoriHeadSize, VertHeadSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(0, 0, HoriHeadSize, VertHeadSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, False);
        // ����
        SRect := Rect(SW - HoriTailSize, 0, SW, VertHeadSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(DW - HoriTailSize, 0, DW, VertHeadSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, False);
        // ����
        SRect := Rect(0, SH - VertTailSize, HoriHeadSize, SH);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(0, DH - VertTailSize, HoriHeadSize, DH);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, False);
        // ����
        SRect := Rect(SW - HoriTailSize, SH - VertTailSize, SW, SH);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(DW - HoriTailSize, DH - VertTailSize, DW, DH);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, False);

        // �ϱ�Ե
        SRect := Rect(HoriHeadSize, 0, SW - HoriTailSize, VertHeadSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(HoriHeadSize, 0, DW - HoriTailSize, VertHeadSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
        // �±�Ե
        SRect := Rect(HoriHeadSize, SH - VertTailSize, SW - HoriTailSize, SH);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(HoriHeadSize, DH - VertTailSize, DW - HoriTailSize, DH);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
        // ���Ե
        SRect := Rect(0, VertHeadSize, HoriHeadSize, SH - VertTailSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(0, VertHeadSize, HoriHeadSize, DH - VertTailSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
        // ���Ե
        SRect := Rect(SW - HoriTailSize, VertHeadSize, SW, SH - VertTailSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(DW - HoriTailSize, VertHeadSize, DW, DH - VertTailSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
        // ����
        SRect := Rect(HoriHeadSize, VertHeadSize, SW - HoriTailSize, SH - VertTailSize);
        OffsetRect(SRect, SrcRect.Left, SrcRect.Top);
        DRect := Rect(HoriHeadSize, VertHeadSize, DW - HoriTailSize, DH - VertTailSize);
        OffsetRect(DRect, DestRect.Left, DestRect.Top);
        DoDrawSlice(SRect, DRect, True);
      end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �����ַ����ĳ�������Ӧ��ʾ����
// ����:
//   S       - �����̵��ַ���.
//   Canvas  - �ַ������ڵ�Canvas.
//   Width   - ������ؿ���
//   Suffix  - ����ַ������ضϣ�������ʲô��׺
// ����:
//   ����֮����ַ���
//-----------------------------------------------------------------------------
function RestrictStrWidth(const S: WideString; Canvas: TCanvas;
  Width: Integer; const Suffix: string = '...'): WideString;
var
  Src: WideString;
begin
  Src := S;
  Result := S;
  while (Canvas.TextWidth(Result) > Width) and (Length(Result) > 0) do
  begin
    if Length(Src) > 1 then
    begin
      Delete(Src, Length(Src), 1);
      Result := Src + Suffix;
    end else
      Delete(Result, Length(Result), 1);
  end;
end;

{ TCustomPadTabSet }

constructor TCustomPadTabSet.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  ControlStyle := [csCaptureMouse, csClickEvents, csDoubleClicks, csOpaque];
  Width := 185;
  Height := 25;
  DragMode := dmAutomatic;
  DoubleBuffered := True;

  FTabs := TTabList.Create(Self);

  FTabIndex := -1;
  FFirstTabIndex := 0;
  FVisibleTabCount := 0;
  FMouseHoverTabIndex := -1;
  FDragTabIndex := -1;

  FPickButton := TPickButton.Create(Self);
  with FPickButton do
  begin
    Parent := Self;
    Left := 2;
    Top := 2;
  end;

  FScrollLeftBtn := TScrollButton.Create(Self);
  with FScrollLeftBtn do
  begin
    Parent := Self;
    FButtonType := sbtLeft;
  end;

  FScrollRightBtn := TScrollButton.Create(Self);
  with FScrollRightBtn do
  begin
    Parent := Self;
    FButtonType := sbtRight;
  end;
end;

destructor TCustomPadTabSet.Destroy;
begin
  FTabs.Free;
  inherited;
end;

procedure TCustomPadTabSet.SetTabList(Value: TStrings);
begin
  FTabs.Assign(Value);
  FTabIndex := -1;
  if FTabs.Count > 0 then TabIndex := 0
  else Invalidate;
end;

procedure TCustomPadTabSet.SetTabIndex(Value: Integer);
var
  F: TCustomForm;
begin
  if Value <> FTabIndex then
  begin
    if (Value < -1) or (Value >= Tabs.Count) then
      raise Exception.CreateRes(@SInvalidTabIndex);
    if CanChange(Value) then
    begin
      if Visible then
      begin
        F := GetParentForm(Self);
        if F <> nil then
          F.SendCancelMode(Self)
        else
          SendCancelMode(Self);
      end;
      FTabIndex := Value;
      Click;
      MakeTabVisible(Value);
      Invalidate;
    end;
  end;
end;

procedure TCustomPadTabSet.SetFirstTabIndex(Value: Integer);
begin
  if (Value >= 0) and (Value < Tabs.Count) then
  begin
    FFirstTabIndex := Value;
    Invalidate;
  end;
end;

function TCustomPadTabSet.GetTabAreaWidth: Integer;
begin
  Result := Width - FirstTabLeft - ((ScrollBtnWidth * 2) + 5);
  if Result < 0 then
    Result := 0;
end;

function TCustomPadTabSet.GetMaxTabWidth: Integer;
begin
  Result := Min(MaxTabWidth, GetTabAreaWidth);
end;

function TCustomPadTabSet.CanChange(NewIndex: Integer): Boolean;
begin
  Result := True;
  if Assigned(FOnChange) then
    FOnChange(Self, NewIndex, Result);
end;

function TCustomPadTabSet.GetSkinBitmap(const BitmapName: string): TBitmap;
begin
  Result := TBitmap.Create;
  try
    Result.LoadFromResourceName(HInstance, BitmapName);
  except
    Result.Free;
    Result := nil;
  end;
end;

function TCustomPadTabSet.IsTabVisible(Index: Integer): Boolean;
begin
  Result := (FTabs.Count > 0) and
    (Index >= FFirstTabIndex) and
    (Index < FFirstTabIndex + FVisibleTabCount);
end;

procedure TCustomPadTabSet.MakeTabVisible(Index: Integer);
begin
  if (Index >= 0) and (Index < FTabs.Count) and
    not IsTabVisible(Index) then
  begin
    while Index >= FFirstTabIndex + FVisibleTabCount do
    begin
      Inc(FFirstTabIndex);
      Rearrange;
    end;

    while Index < FFirstTabIndex do
    begin
      Dec(FFirstTabIndex);
      Rearrange;
    end;

    Invalidate;
  end;
end;

procedure TCustomPadTabSet.IncFirstTabIndex;
begin
  if FTabs.Count > 0 then
  begin
    Inc(FFirstTabIndex);
    if FFirstTabIndex > FTabs.Count - 1 then
      FFirstTabIndex := FTabs.Count - 1;
    Rearrange;
    Invalidate;
  end;
end;

procedure TCustomPadTabSet.DecFirstTabIndex;
begin
  if FTabs.Count > 0 then
  begin
    Dec(FFirstTabIndex);
    if FFirstTabIndex < 0 then
      FFirstTabIndex := 0;
    Rearrange;
    Invalidate;
  end;
end;

procedure TCustomPadTabSet.UpdateVisibleTabCount;
var
  Index: Integer;
  TabAreaWidth: Integer;
  TabWidth: Integer;
  TotalWidth: Integer;
begin
  FVisibleTabCount := 0;
  TotalWidth := 0;
  TabAreaWidth := GetTabAreaWidth;

  for Index := FFirstTabIndex to FTabs.Count - 1 do
  begin
    TabWidth := ItemWidth(Index);
    Inc(TotalWidth, TabWidth + TabSpace);
    if TotalWidth <= TabAreaWidth then
      Inc(FVisibleTabCount)
    else
      Break;
  end;

  if (FTabs.Count > 0) and (FVisibleTabCount = 0) then
    FVisibleTabCount := 1;

  while (FFirstTabIndex > 0) and (FFirstTabIndex + FVisibleTabCount = FTabs.Count) do
  begin
    TotalWidth := 0;
    for Index := FFirstTabIndex - 1 to FFirstTabIndex + FVisibleTabCount do
      Inc(TotalWidth, ItemWidth(Index) + TabSpace);

    if TotalWidth <= TabAreaWidth then
    begin
      Dec(FFirstTabIndex);
      Inc(FVisibleTabCount);
    end else
      Break;
  end;
end;

procedure TCustomPadTabSet.UpdateScrollButtons;
begin
  FScrollLeftBtn.SetBounds(Width - ScrollBtnWidth*2 - 3, 3,
    ScrollBtnWidth, ScrollBtnHeight);
  FScrollRightBtn.SetBounds(Width - ScrollBtnWidth - 3, 3,
    ScrollBtnWidth, ScrollBtnHeight);

  FScrollLeftBtn.Enabled := FFirstTabIndex > 0;
  FScrollRightBtn.Enabled := (FFirstTabIndex + FVisibleTabCount) < FTabs.Count;
end;

procedure TCustomPadTabSet.Rearrange;
begin
  UpdateVisibleTabCount;
  UpdateScrollButtons;
end;

procedure TCustomPadTabSet.DoDrawBackground(DestCanvas: TCanvas;
  const DestRect: TRect);
var
  Bitmap: TBitmap;
begin
  Bitmap := GetSkinBitmap('TabSet_Background');
  if Bitmap <> nil then
  try
    DrawTile(DestCanvas, DestRect, Bitmap,
      Rect(0, 0, Bitmap.Width, Bitmap.Height));
  finally
    Bitmap.Free;
  end;
end;

procedure TCustomPadTabSet.DoDrawTab(DestCanvas: TCanvas; const DestRect: TRect;
  ImageState: TImageState; const Caption: string);
var
  Bitmap: TBitmap;
  SliceRule: TImageSliceRule;
  Text: string;
  TextX, TextY: Integer;
begin
  if ImageState = isDown then
    Bitmap := GetSkinBitmap('TabSet_Tab_Down')
  else if ImageState = isHover then
    Bitmap := GetSkinBitmap('TabSet_Tab_Hover')
  else
    Bitmap := GetSkinBitmap('TabSet_Tab_Up');

  if Bitmap <> nil then
  try
    SliceRule.SliceMode := ismHori;
    SliceRule.HeadSize := 10;
    SliceRule.TailSize := 10;

    DrawSlice(DestCanvas, DestRect, Bitmap,
      Rect(0, 0, Bitmap.Width, Bitmap.Height), SliceRule);
  finally
    Bitmap.Free;
  end;

  Text := Caption;
  if Length(Text) > 0 then
  begin
    Text := RestrictStrWidth(Text, DestCanvas, GetRectWidth(DestRect) - 9);
    TextX := DestRect.Left + (GetRectWidth(DestRect) - DestCanvas.TextWidth(Text)) div 2 + 1;
    TextY := TabTop + 3;

    DestCanvas.Brush.Style := bsClear;
    DestCanvas.TextOut(TextX, TextY, Text);
  end;
end;

procedure TCustomPadTabSet.DoDrawPickButton(DestCanvas: TCanvas;
  const DestRect: TRect; ImageState: TImageState);
var
  Bitmap: TBitmap;
begin
  if ImageState = isHover then
    Bitmap := GetSkinBitmap('TabSet_PickButton_Hover')
  else
    Bitmap := GetSkinBitmap('TabSet_PickButton_Up');

  if Bitmap <> nil then
  try
    DrawNormal(DestCanvas, DestRect, Bitmap, Rect(0, 0, Bitmap.Width, Bitmap.Height));
  finally
    Bitmap.Free;
  end;
end;

procedure TCustomPadTabSet.DoDrawScrollButton(DestCanvas: TCanvas;
  const DestRect: TRect; ImageState: TImageState; ButtonType: TScrollBtnType);
var
  Bitmap: TBitmap;
begin
  if ButtonType = sbtLeft then
  begin
    if ImageState = isDisabled then
      Bitmap := GetSkinBitmap('TabSet_ScrollLeftButton_Disabled')
    else if ImageState = isHover then
      Bitmap := GetSkinBitmap('TabSet_ScrollLeftButton_Hover')
    else
      Bitmap := GetSkinBitmap('TabSet_ScrollLeftButton_Up');
  end else
  begin
    if ImageState = isDisabled then
      Bitmap := GetSkinBitmap('TabSet_ScrollRightButton_Disabled')
    else if ImageState = isHover then
      Bitmap := GetSkinBitmap('TabSet_ScrollRightButton_Hover')
    else
      Bitmap := GetSkinBitmap('TabSet_ScrollRightButton_Up');
  end;

  if Bitmap <> nil then
  try
    DrawNormal(DestCanvas, DestRect, Bitmap, Rect(0, 0, Bitmap.Width, Bitmap.Height));
  finally
    Bitmap.Free;
  end;
end;

procedure TCustomPadTabSet.CMMouseEnter(var Message: TMessage);
begin
  inherited;
end;

procedure TCustomPadTabSet.CMMouseLeave(var Message: TMessage);
begin
  inherited;
  FMouseHoverTabIndex := -1;
  Invalidate;
end;

procedure TCustomPadTabSet.WMEraseBkgnd(var Message: TWmEraseBkgnd);
begin
  // nothing
end;

procedure TCustomPadTabSet.WMWindowPosChanged(var Message: TWMWindowPosChanged);
begin
  inherited;
  Invalidate;
end;

procedure TCustomPadTabSet.CreateParams(var Params: TCreateParams);
begin
  inherited;
  with Params do
  begin
    Style := Style or WS_CLIPCHILDREN;
    WindowClass.style := WindowClass.style and not (CS_HREDRAW or CS_VREDRAW);
  end;
end;

procedure TCustomPadTabSet.WndProc(var Message: TMessage);
begin
  // Ϊ���ÿؼ��� dmAutomatic ״̬��Ҳ�ܽ�����굥��˫���¼�
  if not (csDesigning in ComponentState) and not Dragging and
    ((Message.Msg = WM_LBUTTONDOWN) or (Message.Msg = WM_LBUTTONDBLCLK)) and
    (DragMode = dmAutomatic) and (DragKind = dkDrag) then
  begin
    ControlState := ControlState + [csLButtonDown];
    Dispatch(Message);
  end;

  // ������˫���¼����Ϸ�ϵͳ������رյ����ĶԻ���������Ϊ�Ϸ�״̬
  if Message.Msg <> WM_LBUTTONDBLCLK then
    inherited;
end;

procedure TCustomPadTabSet.Paint;

  procedure DrawBackground(Canvas: TCanvas);
  begin
    DoDrawBackground(Canvas, Rect(0, 0, Width, Height));
  end;

  procedure DrawTabs(Canvas: TCanvas);
  var
    I, Index: Integer;
    TabRect: TRect;
    ImageState: TImageState;
  begin
    for I := 0 to FVisibleTabCount - 1 do
    begin
      Index := I + FFirstTabIndex;
      TabRect := ItemRect(Index);

      if Index = FTabIndex then
        ImageState := isDown
      else if Index = FMouseHoverTabIndex then
        ImageState := isHover
      else
        ImageState := isUp;

      DoDrawTab(Canvas, TabRect, ImageState, Tabs[Index]);
    end;
  end;

begin
  DrawBackground(Canvas);
  DrawTabs(Canvas);
end;

procedure TCustomPadTabSet.Loaded;
begin
  inherited;
  Rearrange;
end;

procedure TCustomPadTabSet.Resize;
begin
  inherited;
  Rearrange;
end;

procedure TCustomPadTabSet.DblClick;
var
  P: TPoint;
begin
  P := ScreenToClient(Mouse.CursorPos);
  if not PtInRect(FPickButton.BoundsRect, P) and
     not PtInRect(FScrollLeftBtn.BoundsRect, P) and
     not PtInRect(FScrollRightBtn.BoundsRect, P) then
  begin
    inherited;
  end;
end;

procedure TCustomPadTabSet.MouseDown(Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var
  I: Integer;
begin
  inherited MouseDown(Button, Shift, X, Y);
  if Button = mbLeft then
  begin
    I := ItemAtPos(Point(X, Y));
    if I <> -1 then
      SetTabIndex(I);
  end;
end;

procedure TCustomPadTabSet.MouseMove(Shift: TShiftState; X, Y: Integer);
var
  I: Integer;
begin
  inherited MouseMove(Shift, X, Y);
  I := ItemAtPos(Point(X, Y));
  if I <> FMouseHoverTabIndex then
  begin
    FMouseHoverTabIndex := I;
    Invalidate;
  end;
end;

function TCustomPadTabSet.DoMouseWheel(Shift: TShiftState;
  WheelDelta: Integer; MousePos: TPoint): Boolean;
begin
  Result := inherited DoMouseWheel(Shift, WheelDelta, MousePos);

  FMouseHoverTabIndex := -1;
  if WheelDelta > 0 then
    DecFirstTabIndex
  else
    IncFirstTabIndex;
end;

procedure TCustomPadTabSet.DoStartDrag(var DragObject: TDragObject);
begin
  inherited;
  FDragTabIndex := ItemAtPos(ScreenToClient(Mouse.CursorPos));
end;

procedure TCustomPadTabSet.DragOver(Source: TObject; X, Y: Integer;
  State: TDragState; var Accept: Boolean);
var
  OverIndex: Integer;
  DragRect, OverRect, NewRect: TRect;
  P: TPoint;
begin
  inherited;
  Accept := (Source = Self) and (FDragTabIndex <> -1);
  if Accept then
  begin
    P := Point(X, Y);
    OverIndex := ItemAtPos(P);
    if (OverIndex >= 0) and (OverIndex <> FDragTabIndex) then
    begin
      DragRect := ItemRect(FDragTabIndex);
      OverRect := ItemRect(OverIndex);
      NewRect := DragRect;

      if OverIndex < FDragTabIndex then
      begin
        NewRect.Left := OverRect.Left;
        NewRect.Right := NewRect.Left + GetRectWidth(DragRect);
      end else
      begin
        NewRect.Right := OverRect.Right;
        NewRect.Left := NewRect.Right - GetRectWidth(DragRect);
      end;

      if PtInRect(NewRect, P) then
      begin
        if Assigned(FOnTabMoved) then
          FOnTabMoved(Self, FDragTabIndex, OverIndex);

        FTabs.Move(FDragTabIndex, OverIndex);
        FTabIndex := OverIndex;
        FDragTabIndex := OverIndex;
        Invalidate;
      end;
    end;
  end;
end;

procedure TCustomPadTabSet.Invalidate;
begin
  inherited Invalidate;

  if FPickButton <> nil then
    FPickButton.Invalidate;
  if FScrollLeftBtn <> nil then
    FScrollLeftBtn.Invalidate;
  if FScrollRightBtn <> nil then
    FScrollRightBtn.Invalidate;
end;

function TCustomPadTabSet.ItemAtPos(Pos: TPoint): Integer;
var
  I: Integer;
begin
  Result := -1;
  for I := 0 to FTabs.Count - 1 do
  begin
    if PtInRect(ItemRect(I), Pos) then
    begin
      Result := I;
      Break;
    end;
  end;
end;

function TCustomPadTabSet.ItemRect(Index: Integer): TRect;
var
  I, X: Integer;
begin
  Result := Rect(0, 0, 0, 0);
  if (Index >= FFirstTabIndex) and (Index < FFirstTabIndex + FVisibleTabCount) then
  begin
    X := FirstTabLeft;
    for I := FFirstTabIndex to Index - 1 do
      Inc(X, ItemWidth(I) + TabSpace);

    Result.Left := X;
    Result.Top := TabTop;
    Result.Right := Result.Left + ItemWidth(Index);
    Result.Bottom := Result.Top + (TabHeight - TabTop);
  end;
end;

function TCustomPadTabSet.ItemWidth(Index: Integer): Integer;
begin
  if (Index >= 0) and (Index < FTabs.Count) then
    Result := Canvas.TextWidth(FTabs[Index]) + 9
  else
    Result := 0;
  Result := Min(Result, GetMaxTabWidth);
end;

procedure TCustomPadTabSet.PopupPickMenu;
begin
  FPickButton.PopupPickMenu;
end;

{ TTabList }

constructor TTabList.Create(const ATabSet: TCustomPadTabSet);
begin
  inherited Create;
  FTabSet := ATabSet;
end;

function TTabList.Add(const S: string): Integer;
begin
  Result := inherited Add(S);
  if FTabSet <> nil then
  begin
    FTabSet.Rearrange;
    FTabSet.Invalidate;
  end;
end;

procedure TTabList.Insert(Index: Integer; const S: string);
begin
  inherited Insert(Index, S);
  if FTabSet <> nil then
  begin
    if Index <= FTabSet.FTabIndex then
      Inc(FTabSet.FTabIndex);

    FTabSet.Rearrange;
    FTabSet.Invalidate;
  end;
end;

procedure TTabList.Delete(Index: Integer);
var
  OldIndex: Integer;
  LastVisibleTab: Integer;
begin
  OldIndex := FTabSet.TabIndex;
  inherited Delete(Index);

  if OldIndex < Count then
    FTabSet.FTabIndex := OldIndex
  else
    FTabSet.FTabIndex := Count - 1;

  if FTabSet.HandleAllocated then
  begin
    { See if we can fit more tabs onto the screen now }
    if Count > 0 then
    begin
      LastVisibleTab := FTabSet.FFirstTabIndex + FTabSet.FVisibleTabCount - 1;
      if (LastVisibleTab = Count - 1) and (FTabSet.FFirstTabIndex > 0) then
        FTabSet.FFirstTabIndex := FTabSet.FFirstTabIndex - 1;
    end;
  end;

  FTabSet.MakeTabVisible(FTabSet.FTabIndex);
  FTabSet.Rearrange;
  FTabSet.Invalidate;
  if OldIndex = Index then
    FTabSet.Click;  { We deleted the selected tab }
end;

procedure TTabList.Put(Index: Integer; const S: string);
begin
  inherited Put(Index, S);
  if FTabSet <> nil then
  begin
    FTabSet.Rearrange;
    FTabSet.Invalidate;
  end;
end;

procedure TTabList.Clear;
begin
  inherited Clear;
  FTabSet.FTabIndex := -1;
  FTabSet.Rearrange;
  FTabSet.Invalidate;
end;

procedure TTabList.Move(CurIndex, NewIndex: Integer);
var
  TempObject: TObject;
  TempString: string;
begin
  if CurIndex <> NewIndex then
  begin
    BeginUpdate;
    try
      TempString := Get(CurIndex);
      TempObject := GetObject(CurIndex);
      inherited Delete(CurIndex);
      inherited InsertObject(NewIndex, TempString, TempObject);
    finally
      EndUpdate;
    end;
  end;
end;

procedure TTabList.AddStrings(Strings: TStrings);
begin
  SendMessage(FTabSet.Handle, WM_SETREDRAW, 0, 0);
  inherited AddStrings(Strings);
  SendMessage(FTabSet.Handle, WM_SETREDRAW, 1, 0);

  FTabSet.Rearrange;
  FTabSet.Invalidate;
end;

{ TPickButton }

constructor TPickButton.Create(AOwner: TComponent);
begin
  Assert(AOwner is TCustomPadTabSet);

  inherited;
  FTabSet := AOwner as TCustomPadTabSet;

  Width := PickBtnWidth;
  Height := PickBtnHeight;

  ShowHint := True;
  Hint := '��ǩ�б�';

  FPickMenu := TPopupMenu.Create(Self);
  FPickMenu.AutoHotkeys := maManual;
end;

destructor TPickButton.Destroy;
begin
  FPickMenu.Free;
  inherited;
end;

procedure TPickButton.InitPickMenu;
var
  I: Integer;
  MenuItem: TMenuItem;
begin
  FPickMenu.Items.Clear;
  for I := 0 to FTabSet.Tabs.Count - 1 do
  begin
    MenuItem := TMenuItem.Create(Self);
    MenuItem.Caption := RestrictStrWidth(FTabSet.Tabs[I], FTabSet.Canvas, 200);
    MenuItem.GroupIndex := 1;
    MenuItem.Tag := I;
    if I = FTabSet.TabIndex then
      MenuItem.Checked := True;
    MenuItem.OnClick := OnMenuItemClick;

    FPickMenu.Items.Add(MenuItem);
  end;
end;

procedure TPickButton.OnMenuItemClick(Sender: TObject);
var
  I: Integer;
begin
  I := TMenuItem(Sender).Tag;
  FTabSet.TabIndex := I;
end;

procedure TPickButton.CMMouseEnter(var Message: TMessage);
begin
  inherited;
end;

procedure TPickButton.CMMouseLeave(var Message: TMessage);
begin
  inherited;
  FMouseInControl := False;
  Invalidate;
end;

procedure TPickButton.Paint;
begin
  FTabSet.DoDrawPickButton(Canvas, Rect(0, 0, Width, Height),
    Iif(FMouseInControl, isHover, isUp));
end;

procedure TPickButton.MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  if (Button = mbLeft) and PtInRect(Rect(0, 0, Width, Height), Point(X, Y)) then
  begin
    PopupPickMenu;
  end;
end;

procedure TPickButton.MouseMove(Shift: TShiftState; X, Y: Integer);
var
  InControl: Boolean;
begin
  inherited;
  InControl := PtInRect(Rect(0, 0, Width, Height), Point(X, Y));
  if InControl <> FMouseInControl then
  begin
    FMouseInControl := InControl;
    Invalidate;
  end;
end;

procedure TPickButton.PopupPickMenu;
var
  Pos: TPoint;
begin
  InitPickMenu;
  Pos := ClientToScreen(Point(0, Height));
  FPickMenu.Popup(Pos.X, Pos.Y);
end;

{ TScrollButton }

constructor TScrollButton.Create(AOwner: TComponent);
begin
  Assert(AOwner is TCustomPadTabSet);

  inherited;
  ControlStyle := [csCaptureMouse, csClickEvents, csDoubleClicks, csOpaque];
  FTabSet := AOwner as TCustomPadTabSet;

  Width := ScrollBtnWidth;
  Height := ScrollBtnHeight;
end;

destructor TScrollButton.Destroy;
begin
  inherited;
end;

procedure TScrollButton.CMMouseEnter(var Message: TMessage);
begin
  inherited;
end;

procedure TScrollButton.CMMouseLeave(var Message: TMessage);
begin
  inherited;
  FMouseInControl := False;
  Invalidate;
end;

procedure TScrollButton.CMEnabledChanged(var Message: TMessage);
begin
  inherited;
end;

procedure TScrollButton.Paint;
var
  ImageState: TImageState;
begin
  if not Enabled then
    ImageState := isDisabled
  else if FMouseInControl then
    ImageState := isHover
  else
    ImageState := isUp;

  FTabSet.DoDrawScrollButton(Canvas, Rect(0, 0, Width, Height),
    ImageState, FButtonType);
end;

procedure TScrollButton.MouseDown(Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  inherited;
  if Button = mbLeft then
  begin
    if FButtonType = sbtLeft then
      FTabSet.DecFirstTabIndex
    else
      FTabSet.IncFirstTabIndex;
  end;
end;

procedure TScrollButton.MouseUp(Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  inherited;
end;

procedure TScrollButton.MouseMove(Shift: TShiftState; X, Y: Integer);
var
  InControl: Boolean;
begin
  inherited;
  InControl := PtInRect(Rect(0, 0, Width, Height), Point(X, Y));
  if InControl <> FMouseInControl then
  begin
    FMouseInControl := InControl;
    Invalidate;
  end;
end;

end.
