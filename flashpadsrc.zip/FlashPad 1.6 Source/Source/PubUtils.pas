
{*************************************************************************}
{ ��Ԫ����: �����������Ԫ                                              }
{ ��    ��: 1.0                                                           }
{ �޸�����: 2007-11-20                                                    }
{*************************************************************************}

unit PubUtils;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  StdCtrls, ShellApi, ShlObj, ComObj, ActiveX, Registry, Dialogs;

// �ַ������
function IsInt(const S: string): Boolean;
function IsFloat(const S: string): Boolean;
function IsEmail(const S: string): Boolean;
function PathWithSlash(const Path: string): string;
function PathWithoutSlash(const Path: string): string;
function CombineFileName(const Path, FileName: string): string;
function FileExtWithDot(const FileExt: string): string;
function FileExtWithoutDot(const FileExt: string): string;
function AddNumberComma(Number: Int64): string;
function ExtractFileMainName(const FileName: string): string;
function ExtractUrlFilePath(const Url: string): string;
function ExtractUrlFileName(const Url: string): string;
function ValidateFileName(const FileName: string): string;
function GetSizeString(Bytes: Int64; const Postfix: string = ' KB'): string;
function GetPercentString(Position, Max: Int64; const Postfix: string = ' %'): string;
function RestrictStrWidth(const S: WideString; Canvas: TCanvas; Width: Integer; const Suffix: string = '...'): WideString;
function RestrictFileNameWidth(const FileName: string; MaxBytes: Integer): string;
function LikeString(Value, Pattern: WideString; CaseInsensitive: Boolean): Boolean;
procedure SplitString(S: string; Delimiter: Char; List: TStrings);
function StartWith(const Source: string; const Left: string): Boolean;
function EndWith(const Source: string; const Right: string): Boolean;

// ϵͳ���
function GetComputerName: string;
function GetWinUserName: string;
function GetWindowsDir: string;
function GetWinTempDir: string;
function GetWinTempFile(const PrefixStr: string = ''): string;
function GetFullFileName(const FileName: string): string;
function GetShortFileName(const FileName: string): string;
function GetLongFileName(const FileName: string): string;
function GetSpecialFolder(FolderID: Integer): string;
function GetQuickLaunchPath: string;
function GetSystemDrivePath: string;
function GetEnvVar(const EnvVar: string): string;
function GetWorkAreaRect: TRect;
function SelectDir(ParentHWnd: HWND; const Caption: string; const Root: WideString; var Path: string): Boolean;
function ExecuteFile(const FileName, Params, DefaultDir: string; ShowCmd: Integer): HWND;
function OpenURL(const URL: string): Boolean;
function OpenEmail(const Email: string): Boolean;
procedure SetStayOnTop(Form : TCustomForm; StayOnTop: Boolean);
procedure HideAppFromTaskBar;
function CheckLangChinesePR: Boolean;
function ShutdownWindows: Boolean;
function GetMouseCursorPos: TPoint;
function CreateShortCut(const OriginalFileName, ShortcutFileName, Arguments,
  WorkingDir, Description: string; ShowCmd: Integer; IsFolderShortcut: Boolean): Boolean;

// �ļ����
function GetFileSize(const FileName: string): Int64;
function GetFileDate(const FileName: string): TDateTime;
function SetFileDate(const FileName: string; CreationTime, LastWriteTime, LastAccessTime: TFileTime): Boolean;
function CopyFileToFolder(FileName, BackupFolder: string): Boolean;
function AutoRenameFileName(const FullName: string): string;
function GetTempFileAtPath(const Path: string; const PrefixStr: string = ''): string;
function IsFileReadOnly(const FileName: string): Boolean;
function DeleteFileToRecycle(const FileName: string): Boolean;
function DeleteDirectory(const Dir: string): Boolean;

// ע������
function SetAutoRunOnStartup(AutoRun, CurrentUser: Boolean; AppTitle: string = ''; AppPara: string = ''): Boolean;
function AssociateFile(const FileExt, FileKey, SoftName, FileDesc: string; IconIndex: Integer = 0; Flush: Boolean = False): Boolean;
function SaveAppPath(const CompanyName, SoftName, Version: string): Boolean;
function ReadAppPath(const CompanyName, SoftName, Version: string; var Path: string): Boolean;

// ����ʱ�����
function FileTimeToLocalSystemTime(FTime: TFileTime): TSystemTime;
function LocalSystemTimeToFileTime(STime: TSystemTime): TFileTime;
function GetDatePart(DateTime: TDateTime): TDate;
function GetTimePart(DateTime: TDateTime): TTime;

// ��������
procedure BeginWait;
procedure EndWait;
function Iif(Value: Boolean; Value1, Value2: Variant): Variant;
function Min(V1, V2: Integer): Integer;
function Max(V1, V2: Integer): Integer;
function TrimValue(Value, Min, Max: Integer): Integer;
procedure Swap(var V1, V2: Integer);
function GetTickDiff(const OldTickCount, NewTickCount: Cardinal): Cardinal;
function RestrictRectInScr(Rect: TRect; AllVisible: Boolean): TRect;
function GetModulePath: string;
function GetModuleSubPath(const SubFolder: string = ''): string;
function GetAppPath: string;
function GetAppSubPath(const SubFolder: string = ''): string;
function GetRectWidth(const R: TRect): Integer;
function GetRectHeight(const R: TRect): Integer;
procedure DrawStrokedText(Canvas: TCanvas; X, Y: Integer; const Text: string;
  FontColor, StrokedColor, SmoothColor: TColor);

implementation

{$WARN SYMBOL_PLATFORM OFF}
{$WARN SYMBOL_DEPRECATED OFF}

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� S �ǲ���һ����������
//-----------------------------------------------------------------------------
function IsInt(const S: string): Boolean;
var
  E, R: Integer;
begin
  Val(S, R, E);
  Result := E = 0;
  E := R; // avoid hints
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� S �ǲ���һ������������
//-----------------------------------------------------------------------------
function IsFloat(const S: string): boolean;
var
  V: Extended;
begin
  Result := TextToFloat(PChar(S), V, fvExtended);
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� S �ǲ���һ�� Email ��ַ
//-----------------------------------------------------------------------------
function IsEmail(const S: string): Boolean;
begin
  Result := True;
  if Pos('@', S) = 0 then Result := False;
  if Pos('.', S) = 0 then Result := False;
end;

//-----------------------------------------------------------------------------
// ����: ��ȫ·���ַ�������� "\"
//-----------------------------------------------------------------------------
function PathWithSlash(const Path: string): string;
begin
  Result := Trim(Path);
  if Length(Result) > 0 then
    Result := IncludeTrailingPathDelimiter(Result);
end;

//-----------------------------------------------------------------------------
// ����: ȥ��·���ַ�������� "\"
//-----------------------------------------------------------------------------
function PathWithoutSlash(const Path: string): string;
begin
  Result := Trim(Path);
  if Length(Result) > 0 then
    Result := ExcludeTrailingPathDelimiter(Result);
end;

//-----------------------------------------------------------------------------
// ����: ��·�����ļ��������һ��
//-----------------------------------------------------------------------------
function CombineFileName(const Path, FileName: string): string;
begin
  Result := PathWithSlash(Path) + FileName;
end;

//-----------------------------------------------------------------------------
// ����: ��ȫ�ļ���չ��ǰ��� "."
//-----------------------------------------------------------------------------
function FileExtWithDot(const FileExt: string): string;
begin
  Result := FileExt;
  if Length(Result) > 0 then
    if Copy(Result, 1, 1) <> '.' then
      Result := '.' + Result;
end;

//-----------------------------------------------------------------------------
// ����: ȥ���ļ���չ��ǰ��� "."
//-----------------------------------------------------------------------------
function FileExtWithoutDot(const FileExt: string): string;
begin
  Result := FileExt;
  if Length(Result) > 0 then
    if Copy(Result, 1, 1) = '.' then
      Delete(Result, 1, 1);
end;

//-----------------------------------------------------------------------------
// ����: �����ּ��Ϸָ�����
// ʾ��: 1234567 -> 1,234,567
//-----------------------------------------------------------------------------
function AddNumberComma(Number: Int64): string;
var
  Temp: Double;
begin
  Temp := Number;
  Result := Format('%.0n', [Temp]);
end;

//-----------------------------------------------------------------------------
// ����: ȡ���ļ��������ļ���
// ʾ��: "C:\test.dat" -> "test"
//-----------------------------------------------------------------------------
function ExtractFileMainName(const FileName: string): string;
var
  Ext: string;
begin
  Ext := ExtractFileExt(FileName);
  Result := ExtractFileName(FileName);
  Result := Copy(Result, 1, Length(Result) - Length(Ext));
end;

//-----------------------------------------------------------------------------
// ����: ����URL�е��ļ�·��
// ʾ��:
//   ExtractUrlFileName('http://www.download.com/file.zip');
//   �˵��ý����� 'http://www.download.com/'.
//-----------------------------------------------------------------------------
function ExtractUrlFilePath(const Url: string): string;
var
  I: Integer;
begin
  I := LastDelimiter('/\:', Url);
  Result := Copy(Url, 1, I);
end;

//-----------------------------------------------------------------------------
// ����: ����URL�е��ļ���
// ʾ��:
//   ExtractUrlFileName('http://www.download.com/file.zip');
//   �˵��ý����� 'file.zip'.
//-----------------------------------------------------------------------------
function ExtractUrlFileName(const Url: string): string;
var
  I: Integer;
begin
  I := LastDelimiter('/\:', Url);
  Result := Copy(Url, I + 1, MaxInt);
end;

//-----------------------------------------------------------------------------
// ����: ȥ���ļ����в��Ϸ����ַ�
// ʾ��: "tes*t.dat?" -> "test.dat"
//-----------------------------------------------------------------------------
function ValidateFileName(const FileName: string): string;
var
  I: Integer;
begin
  Result := '';
  for I := 1 to Length(FileName) do
  begin
    if not (AnsiChar(FileName[I]) in ['\', '/', ':', '*', '?', '"', '<', '>', '|']) and
      not (Ord(FileName[I]) < 32) then
      Result := Result + FileName[I];
  end;
end;

//-----------------------------------------------------------------------------
// ����: ȡ��һ�����������ֽ������ַ���
// ����:
//   Bytes   - �ֽ���
//   Postfix - ��λ��׺��ȱʡΪ " KB"
//-----------------------------------------------------------------------------
function GetSizeString(Bytes: Int64; const Postfix: string): string;
var
  Temp: Double;
begin
  if Bytes > 0 then
  begin
    Temp := Bytes div 1024;
    if Bytes mod 1024 <> 0 then Temp := Temp + 1;
  end else
    Temp := 0;
  Result := Format('%s%s', [Format('%.0n', [Temp]), Postfix]);
end;

//-----------------------------------------------------------------------------
// ����: ȡ��һ�����������ٷֱȵ��ַ���
// ����:
//   Position, Max   - ��ǰֵ �� ���ֵ
//   Postfix         - ��׺�ַ�����ȱʡΪ " %"
//-----------------------------------------------------------------------------
function GetPercentString(Position, Max: Int64; const Postfix: string): string;
begin
  if Max > 0 then
    Result := IntToStr(Trunc((Position / Max) * 100)) + Postfix
  else
    Result := '100' + Postfix;
end;

//-----------------------------------------------------------------------------
// ����: �����ַ����ĳ�������Ӧ��ʾ����
// ����:
//   S       - �����̵��ַ���.
//   Canvas  - �ַ������ڵ�Canvas.
//   Width   - ������ؿ���
//   Suffix  - ����ַ������ضϣ�������ʲô��׺
// ����:
//   ����֮����ַ���
//-----------------------------------------------------------------------------
function RestrictStrWidth(const S: WideString; Canvas: TCanvas;
  Width: Integer; const Suffix: string): WideString;
var
  Src: WideString;
begin
  Src := S;
  Result := S;
  while (Canvas.TextWidth(Result) > Width) and (Length(Result) > 0) do
  begin
    if Length(Src) > 1 then
    begin
      Delete(Src, Length(Src), 1);
      Result := Src + Suffix;
    end else
      Delete(Result, Length(Result), 1);
  end;
end;

//-----------------------------------------------------------------------------
// ����: �����ļ����ĳ�������Ӧ����ֽ�������
// ����:
//   FileName - �����̵��ļ���(���԰���·��)
//   MaxBytes - ����ֽ���
// ����:
//   ����֮����ļ����ַ���
//-----------------------------------------------------------------------------
function RestrictFileNameWidth(const FileName: string;
  MaxBytes: Integer): string;

  function GetBytes(const S: WideString): Integer;
  var
    AnsiStr: string;
  begin
    AnsiStr := S;
    Result := Length(AnsiStr);
  end;

var
  MainName, NewMainName: WideString;
  Ext: string;
  ExtLen: Integer;
begin
  if Length(FileName) <= MaxBytes then
  begin
    Result := FileName;
  end else
  begin
    Ext := ExtractFileExt(FileName);
    MainName := Copy(FileName, 1, Length(FileName) - Length(Ext));
    ExtLen := Length(Ext);

    NewMainName := MainName;
    while (GetBytes(NewMainName) + ExtLen > MaxBytes) and (Length(NewMainName) > 0) do
    begin
      if Length(MainName) > 1 then
      begin
        Delete(MainName, Length(MainName), 1);
        NewMainName := MainName + '...';
      end else
        Delete(NewMainName, Length(NewMainName), 1);
    end;

    Result := NewMainName + Ext;
    if Length(Result) > MaxBytes then
      Result := Copy(Result, 1, MaxBytes);
  end;
end;

//-----------------------------------------------------------------------------
// ����������ͨ�������ʽ��֧��ͨ���'*' �� '?'
// ������
//   Value            - ĸ��
//   Pattern          - �Ӵ�
//   CaseInsensitive  - �Ƿ���Դ�Сд
// ���أ�
//   True  -  ƥ��
//   False -  ��ƥ��
// ʾ����
//   LikeString('abcdefg', 'abc*', True);
//-----------------------------------------------------------------------------
function LikeString(Value, Pattern: WideString; CaseInsensitive: Boolean): Boolean;
const
  MultiWildChar = '*';
  SingleWildChar = '?';
var
  ValuePtr, PatternPtr: PWideChar;
  I: Integer;
  B: Boolean;
begin
  ValuePtr := PWideChar(Value);
  PatternPtr := PWideChar(Pattern);

  while True do
  begin
    if (CompareStringW(LOCALE_USER_DEFAULT, NORM_IGNORECASE + SORT_STRINGSORT,
      PatternPtr, Length(PatternPtr), WideChar(MultiWildChar), 1) - 2 = 0) then
    begin
      Result := True;
      Exit;
    end
    else if (ValuePtr^ = #0) and (PatternPtr^ <> #0) then
    begin
      Result := False;
      Exit;
    end
    else if (ValuePtr^ = #0) then
    begin
      Result := True;
      Exit;
    end else
    begin
      case PatternPtr^ of
        MultiWildChar:
          begin
            for I := 0 to Length(ValuePtr) - 1 do
            begin
              if LikeString(ValuePtr + I, PatternPtr + 1, CaseInsensitive) then
              begin
                Result := True;
                Exit;
              end;
            end;
            Result := False;
            Exit;
          end;
        SingleWildChar:
          begin
            Inc(ValuePtr);
            Inc(PatternPtr);
          end;
      else
        begin
          B := False;
          if CaseInsensitive then
          begin
            if (CompareStringW(LOCALE_USER_DEFAULT, NORM_IGNORECASE + SORT_STRINGSORT,
              PatternPtr, 1, ValuePtr, 1) - 2 = 0) then
              B := True;
          end else
          begin
            if (CompareStringW(LOCALE_USER_DEFAULT, SORT_STRINGSORT,
              PatternPtr, 1, ValuePtr, 1) - 2 = 0) then
              B := True;
          end;

          if B then
          begin
            Inc(ValuePtr);
            Inc(PatternPtr);
          end else
          begin
            Result := False;
            Exit;
          end;
        end;
      end; // case
    end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ָ��ַ���
//-----------------------------------------------------------------------------
procedure SplitString(S: string; Delimiter: Char; List: TStrings);
var
  I: Integer;
begin
  List.Clear;
  while Length(S) > 0 do
  begin
    I := Pos(Delimiter, S);
    if I > 0 then
    begin
      List.Add(Copy(S, 1, I - 1));
      Delete(S, 1, I);
    end else
    begin
      List.Add(S);
      Break;
    end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� Source �ǲ����� Left ��ʼ
//-----------------------------------------------------------------------------
function StartWith(const Source: string; const Left: string): Boolean;
var
  Start: string;
  Len: Integer;
begin
  Len := Length(Left);
  if (Source = '') or (Left = '') or (Length(Source) < Len) then
  begin
    Result := False;
  end else
  begin
    Start := Copy(Source, 1, Len);
    Result := Start = Left;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ж��ַ��� Source �ǲ����� Right ����
//-----------------------------------------------------------------------------
function EndWith(const Source: string; const Right: string): Boolean;
var
  EndStr: string;
  RightLen: Integer;
  SourceLen: Integer;
begin
  RightLen := Length(Right);
  SourceLen := Length(Source);

  if (Source = '') or (Right = '') or (SourceLen < RightLen) then
  begin
    Result := False;
  end else
  begin
    EndStr := Copy(Source, SourceLen - RightLen + 1, RightLen);
    Result := EndStr = Right;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ȡ�ü������
//-----------------------------------------------------------------------------
function GetComputerName: string;
const
  MaxSize = 256;
var
  Buffer: array[0..MaxSize-1] of Char;
  Size: Cardinal;
begin
  Size := MaxSize;
  Windows.GetComputerName(PChar(@Buffer[0]), Size);
  Result := Buffer;
end;

//-----------------------------------------------------------------------------
// ����: ȡ�õ�ǰϵͳ�û���
//-----------------------------------------------------------------------------
function GetWinUserName: string;
const
  Size = 255;
var
  Buffer: array[0..Size] of Char;
  Len: DWord;
begin
  Len := Size;
  GetUserName(Buffer, Len);
  Result := Buffer;
end;

//-----------------------------------------------------------------------------
// ����: ȡ�� Windows Ŀ¼
//-----------------------------------------------------------------------------
function GetWindowsDir: string;
var
  Buffer: array[0..MAX_PATH] of Char;
begin
  GetWindowsDirectory(Buffer, MAX_PATH);
  Result := PathWithSlash(Buffer);
end;

//-----------------------------------------------------------------------------
// ����: ȡ��ϵͳ��ʱ�ļ�Ŀ¼
//-----------------------------------------------------------------------------
function GetWinTempDir: string;
const
  Size = 1024;
var
  Buffer: array[0..Size] of Char;
  LongName: string;
begin
  GetTempPath(Size, Buffer);
  Result := PathWithSlash(Buffer);
  LongName := GetLongFileName(Result);
  if Length(LongName) >= Length(Result) then
    Result := LongName;
end;

//-----------------------------------------------------------------------------
// ����: ȡ��һ����ʱ�ļ���(·��Ϊϵͳ��ʱĿ¼)
// ����:
//   PrefixStr - �ļ���ǰ׺��ǰ�����ַ���Ч
//-----------------------------------------------------------------------------
function GetWinTempFile(const PrefixStr: string): string;
var
  FileName: array[0..MAX_PATH] of Char;
  LongName: string;
begin
  Windows.GetTempFileName(PChar(GetWinTempDir), PChar(PrefixStr), 0, FileName);
  Result := FileName;
  LongName := GetLongFileName(Result);
  if Length(LongName) >= Length(Result) then
    Result := LongName;
end;

//-----------------------------------------------------------------------------
// ����: �ļ���ȫ��(����·��)
// ʾ��:
//   "test.dat" -> "C:\test.dat"
//   "C:\a\..\test.dat" -> "C:\test.dat"
//-----------------------------------------------------------------------------
function GetFullFileName(const FileName: string): string;
const
  Size = 1024;
var
  Buffer: array[0..Size] of Char;
  FileNamePtr: PChar;
  Len: DWord;
begin
  Len := Size;
  GetFullPathName(PChar(FileName), Len, Buffer, FileNamePtr);
  Result := Buffer;
end;

//-----------------------------------------------------------------------------
// ����: ���ļ��� -> ���ļ���(8.3)
// ��ע: FileName ������·����Ҳ�������ļ�����
// ʾ��:
//   "C:\Program Files" -> "C:\PROGRA~1"
//-----------------------------------------------------------------------------
function GetShortFileName(const FileName: string): string;
const
  Size = 1024;
var
  Buffer: array[0..Size] of Char;
begin
  GetShortPathName(PChar(FileName), Buffer, Size);
  Result := Buffer;
end;

//-----------------------------------------------------------------------------
// ����: ���ļ���(8.3) -> ���ļ���
// ��ע: FileName ������·����Ҳ�������ļ�����
// ʾ��:
//   "C:\PROGRA~1\COMMON~1\" -> "C:\Program Files\Common Files\"
//-----------------------------------------------------------------------------
function GetLongFileName(const FileName: string): string;
var
  Name, S: string;
  SearchRec : TSearchRec;
begin
  S := ExcludeTrailingPathDelimiter(FileName);
  if (Length(S) < 3) or (ExtractFilePath(S) = S) then
  begin
    Result := FileName;
    Exit;
  end;

  if FindFirst(S, faAnyFile, SearchRec) = 0 then
    Name := SearchRec.Name
  else
    Name := ExtractFileName(S);
  FindClose(SearchRec);

  Result := GetLongFileName(ExtractFilePath(S)) + Name;
  if Length(S) <> Length(FileName) then Result := Result + '\';
end;

//-----------------------------------------------------------------------------
// ����: ȡ�������ļ���·��
// ����:
//   FolderID -
//      CSIDL_DESKTOP
//      CSIDL_PROGRAMS
//      CSIDL_RECENT
//      CSIDL_SENDTO
//      CSIDL_STARTMENU
//      CSIDL_STARTUP
//      CSIDL_TEMPLATES
//      CSIDL_APPDATA
// ����:
//   ���ɹ������ش����б��(\)��·����
//   ��ʧ�ܣ����ؿ��ַ�����
// ��ע:
//   ��Ҫȡ"��������"��·������:
//   GetSpecialFolder(CSIDL_APPDATA) + 'Microsoft\Internet Explorer\Quick Launch\'.
//-----------------------------------------------------------------------------
function GetSpecialFolder(FolderID: Integer): string;
var
  PidL: PItemIDList;
  Buffer: array[0..MAX_PATH] of Char;
  Malloc: IMalloc;
begin
  Result := '';
  if Failed(SHGetMalloc(Malloc)) then
    Malloc := nil;
  if Succeeded(SHGetSpecialFolderLocation(0, FolderID, PidL)) then
  begin
    if SHGetPathFromIDList(PidL, Buffer) then
      Result := Buffer;
    if Assigned(Malloc) then
      Malloc.Free(PidL);
    Result := PathWithSlash(Result);
  end;
end;

//-----------------------------------------------------------------------------
// ����: ȡ�� "��������" ��·��
//-----------------------------------------------------------------------------
function GetQuickLaunchPath: string;
begin
  Result := GetSpecialFolder(CSIDL_APPDATA) +
    'Microsoft\Internet Explorer\Quick Launch\';
end;

//-----------------------------------------------------------------------------
// ����: ȡ�� SystemDrive ��·��
//-----------------------------------------------------------------------------
function GetSystemDrivePath: string;
begin
  if Win32Platform = VER_PLATFORM_WIN32_NT then
    Result := GetEnvVar('SystemDrive')  {don't localize}
  else
    Result := '';

  if Result = '' then
  begin
    Result := ExtractFileDrive(GetWindowsDir);
    if Result = '' then
      Result := 'C:';
  end;

  Result := PathWithSlash(Result);
end;

//-----------------------------------------------------------------------------
// ����: ȡ�û���������ֵ
//-----------------------------------------------------------------------------
function GetEnvVar(const EnvVar: string): string;

  function AdjustLength(var S: string; const R: Cardinal): Boolean;
  begin
    Result := Integer(R) < Length(S);
    SetLength(S, R);
  end;

const
  MaxSize = 255;
var
  R: DWORD;
begin
  SetLength(Result, MaxSize);
  repeat
    R := GetEnvironmentVariable(PChar(EnvVar), PChar(Result), Length(Result));
    if R = 0 then
    begin
      Result := '';
      Break;
    end;
  until AdjustLength(Result, R);
end;

//-----------------------------------------------------------------------------
// ����: ȡ�������ϳ����������������
//-----------------------------------------------------------------------------
function GetWorkAreaRect: TRect;
begin
  SystemParametersInfo(SPI_GETWORKAREA, 0, @Result, 0);
end;

//-----------------------------------------------------------------------------
// ����: ����ļ��У��ɶ�λ�ļ���
// ����:
//   ParentHWnd - �����ڵľ��
//   Caption    - ����Ի������ʾ����
//   Root       - ��Ŀ¼
//   Path       - ����û�����ѡ���Ŀ¼
// ����:
//   True  - �û�����ȷ��
//   False - �û�����ȡ��
//-----------------------------------------------------------------------------
function SelectDir(ParentHWnd: HWND; const Caption: string;
  const Root: WideString; var Path: string): Boolean;
const
{$WRITEABLECONST ON}
  InitPath: string = '';
{$WRITEABLECONST OFF}
var
  WindowList: Pointer;
  BrowseInfo: TBrowseInfo;
  Buffer: PChar;
  RootItemIDList, ItemIDList: PItemIDList;
  ShellMalloc: IMalloc;
  IDesktopFolder: IShellFolder;
  Eaten, Flags: LongWord;

  function BrowseCallbackProc(hwnd: HWND; uMsg: UINT; lParam: Cardinal; lpData: Cardinal):Integer; stdcall;
  var
    R: TRect;
  begin
    if uMsg = BFFM_INITIALIZED then
    begin
      GetWindowRect(hwnd, R);
      MoveWindow(hwnd,
        (Screen.Width - (R.Right - R.Left)) div 2,
        (Screen.Height - (R.Bottom - R.Top)) div 2,
        R.Right - R.Left,
        R.Bottom - R.Top,
        True);
      Result := SendMessage(hwnd, BFFM_SETSELECTION, Ord(TRUE), Longint(PChar(InitPath)))
    end else
      Result := 1;
  end;

begin
  Result := False;
  InitPath := Path;
  FillChar(BrowseInfo, SizeOf(BrowseInfo), 0);
  if (ShGetMalloc(ShellMalloc) = S_OK) and (ShellMalloc <> nil) then
  begin
    Buffer := ShellMalloc.Alloc(MAX_PATH);
    try
      RootItemIDList := nil;
      if Root <> '' then
      begin
        SHGetDesktopFolder(IDesktopFolder);
        IDesktopFolder.ParseDisplayName(Application.Handle, nil,
          POleStr(Root), Eaten, RootItemIDList, Flags);
      end;
      with BrowseInfo do
      begin
        hwndOwner := ParentHWnd;
        pidlRoot := RootItemIDList;
        pszDisplayName := Buffer;
        lpszTitle := PChar(Caption);
        ulFlags := BIF_RETURNONLYFSDIRS;
        lpfn :=@BrowseCallbackProc;
        lParam :=BFFM_INITIALIZED;
      end;
      WindowList := DisableTaskWindows(0);
      try
        ItemIDList := ShBrowseForFolder(BrowseInfo);
      finally
        EnableTaskWindows(WindowList);
      end;
      Result :=  ItemIDList <> nil;
      if Result then
      begin
        ShGetPathFromIDList(ItemIDList, Buffer);
        ShellMalloc.Free(ItemIDList);
        Path := Buffer;
      end;
    finally
      ShellMalloc.Free(Buffer);
    end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ��ϵͳ Shell ��������һ���ļ�
//-----------------------------------------------------------------------------
function ExecuteFile(const FileName, Params, DefaultDir: string; ShowCmd: Integer): HWND;
begin
  Result := ShellExecute(Application.Handle, nil,
    PChar(FileName), PChar(Params), PChar(DefaultDir), ShowCmd);
end;

//-----------------------------------------------------------------------------
// ����: ��һ�� URL
// ʾ��:
//   OpenURL('http://www.abc.com');
//   OpenURL('www.abc.com');
//   OpenURL('file:///c:\');
//-----------------------------------------------------------------------------
function OpenURL(const URL: string): Boolean;
begin
  Result := ShellExecute(Application.Handle, 'Open', PChar(Trim(URL)), '', '', SW_SHOW) > 32;
end;

//-----------------------------------------------------------------------------
// ����: ��һ�� Email ���Ϳͻ���
//-----------------------------------------------------------------------------
function OpenEmail(const Email: string): Boolean;
const
  SPrefix = 'mailto:';
var
  S: string;
begin
  S := Trim(Email);
  if Pos(SPrefix, S) <> 1 then S := SPrefix + S;
  
  Result := OpenURL(S);
end;

//-----------------------------------------------------------------------------
// ����: �ô��ڱ��������ϲ�
//-----------------------------------------------------------------------------
procedure SetStayOnTop(Form : TCustomForm; StayOnTop: Boolean);
begin
  if StayOnTop Then
    SetWindowPos(Form.Handle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE Or SWP_NOSIZE)
  else
    SetWindowPos(Form.Handle, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE Or SWP_NOSIZE);
end;

//-----------------------------------------------------------------------------
// ����: ����Ӧ�ó������������ϵ�ѡ��ť
//-----------------------------------------------------------------------------
procedure HideAppFromTaskBar;
var
  ExtendedStyle : Integer;
begin
  ExtendedStyle := GetWindowLong(Application.Handle, GWL_EXSTYLE);
  SetWindowLong(Application.Handle, GWL_EXSTYLE,
    (ExtendedStyle or WS_EX_TOOLWINDOW) and not WS_EX_APPWINDOW);
end;

//-----------------------------------------------------------------------------
// ����: ��鵱ǰϵͳ�����Ƿ��������
//-----------------------------------------------------------------------------
function CheckLangChinesePR: Boolean;
const
  // LCID Consts
  LangChinesePR = (SUBLANG_CHINESE_SIMPLIFIED shl 10) or LANG_CHINESE;
begin
  Result := SysLocale.DefaultLCID = LangChinesePR;
end;

//-----------------------------------------------------------------------------
// ����: �ػ�
//-----------------------------------------------------------------------------
function ShutdownWindows: Boolean;
const
  SE_SHUTDOWN_NAME = 'SeShutdownPrivilege';
var
  hToken: THandle;
  tkp: TTokenPrivileges;
  tkpo: TTokenPrivileges;
  Zero: DWORD;
begin
  Result := True;
  if Win32Platform = VER_PLATFORM_WIN32_NT then
  begin
    Zero := 0;
    if not OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY, hToken) then
    begin
      Result := False;
      Exit;
    end;
    if not LookupPrivilegeValue(nil, SE_SHUTDOWN_NAME, tkp.Privileges[0].Luid) then
    begin
      Result := False;
      Exit;
    end;
    tkp.PrivilegeCount := 1;
    tkp.Privileges[0].Attributes := SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken, False, tkp, SizeOf(TTokenPrivileges), tkpo, Zero);
    if Boolean(GetLastError()) then
    begin
      Result := False;
      Exit;
    end else
      ExitWindowsEx(EWX_SHUTDOWN or EWX_POWEROFF, 0);
  end else
    ExitWindowsEx(EWX_SHUTDOWN or EWX_POWEROFF, 0);
end;

//-----------------------------------------------------------------------------
// ����: ȡ���ĵ�ǰλ��
// ע��: Mouse.CursorPos ���ڴ����뱣������������ʱ�׳��쳣��
//-----------------------------------------------------------------------------
function GetMouseCursorPos: TPoint;
begin
  if not Windows.GetCursorPos(Result) then
    Result := Point(0, 0);
end;

//-----------------------------------------------------------------------------
// ����: ������ݷ�ʽ
// ����:
//   OriginalFileName - ԭʼ�ļ�������·�� (����ݷ�ʽָ����ļ�)
//   ShortcutFileName - ��ݷ�ʽ�ļ�������·��������չ��(.lnk)
//   Arguments        - ���в���
//   WorkingDir       - ����Ŀ¼
//   Description      - ��ݷ�ʽ����
//   ShowCmd          - ���з�ʽ (SW_SHOW, SW_MINIMIZE, SW_MAXIMIZE)
//   IsFolderShortcut - �Ƿ��ļ��п�ݷ�ʽ
// ����:
//   True  - �ɹ�
//   False - ʧ��
//-----------------------------------------------------------------------------
function CreateShortCut(const OriginalFileName, ShortcutFileName, Arguments,
  WorkingDir, Description: string; ShowCmd: Integer;
  IsFolderShortcut: Boolean): Boolean;

  function IsWindowsXP: Boolean;
  begin
    Result := (Win32Platform >= VER_PLATFORM_WIN32_NT) and
      (Win32MajorVersion >= 5) and (Win32MinorVersion >= 1);
  end;

const
  CLSID_FolderShortcut: TGUID = (
    D1:$0AFACED1; D2:$E828; D3:$11D1; D4:($91,$87,$B5,$32,$F1,$E9,$57,$5D));
var
  OleResult: HRESULT;
  Obj: IUnknown;
  SL: IShellLink;
  PF: IPersistFile;
  WideFileName: WideString;
begin
  if IsFolderShortcut then
  begin
    try
      Obj := CreateComObject(CLSID_FolderShortcut);
    except
      { Folder shortcuts aren't supported prior to Windows 2000/Me.
        Fall back to creating a normal shell link. }
      Obj := nil;
    end;
  end;
  if Obj = nil then
  begin
    IsFolderShortcut := False;
    Obj := CreateComObject(CLSID_ShellLink);
  end;
  SL := Obj as IShellLink;
  SL.SetPath(PChar(OriginalFileName));
  SL.SetArguments(PChar(Arguments));
  if WorkingDir <> '' then
    SL.SetWorkingDirectory(PChar(WorkingDir));
  SL.SetShowCmd(ShowCmd);
  if Description <> '' then
    SL.SetDescription(PChar(Description));

  PF := SL as IPersistFile;
  { When creating a folder shortcut on 2000/Me, IPersistFile::Save will strip
    off everything past the last '.' in the ShortcutFileName, so we keep the .lnk
    extension on to give it something harmless to strip off. XP doesn't do
    that, so we must remove the .lnk extension ourself. }
  if IsFolderShortcut and IsWindowsXP then
    WideFileName := ChangeFileExt(ShortcutFileName, '')
  else
    WideFileName := ShortcutFileName;
  OleResult := PF.Save(PWideChar(WideFileName), True);
  Result := OleResult = S_OK;
end;

//-----------------------------------------------------------------------------
// ����: ȡ���ļ���С
//-----------------------------------------------------------------------------
function GetFileSize(const FileName: string): Int64;
var
  Handle: THandle;
  FindData: TWin32FindData;
begin
  Result := -1;
  Handle := FindFirstFile(PChar(FileName), FindData);
  if Handle <> INVALID_HANDLE_VALUE then
  begin
    Windows.FindClose(Handle);
    if (FindData.dwFileAttributes and FILE_ATTRIBUTE_DIRECTORY) = 0 then
    begin
      Int64Rec(Result).Lo := FindData.nFileSizeLow;
      Int64Rec(Result).Hi := FindData.nFileSizeHigh;
    end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ȡ���ļ����޸�ʱ��
//-----------------------------------------------------------------------------
function GetFileDate(const FileName: string): TDateTime;
var
  FileDate: Integer;
begin
  FileDate := FileAge(FileName);
  if FileDate = -1 then
    Result := 0
  else
    Result := FileDateToDateTime(FileDate);
end;

//-----------------------------------------------------------------------------
// ����: �����ļ���ʱ��
//-----------------------------------------------------------------------------
function SetFileDate(const FileName: string;
  CreationTime, LastWriteTime, LastAccessTime: TFileTime): Boolean;
var
  FileHandle : Integer;
begin
  FileHandle := FileOpen(FileName, fmOpenWrite or fmShareDenyNone);
  try
    if FileHandle <> Integer(INVALID_HANDLE_VALUE) then
    begin
      SetFileTime(FileHandle, @CreationTime, @LastAccessTime, @LastWriteTime);
      Result := True;
    end else
      Result := False;
  finally
    FileClose(FileHandle);
  end;
end;

//-----------------------------------------------------------------------------
// ����: �����ļ���һ���ļ���
//-----------------------------------------------------------------------------
function CopyFileToFolder(FileName, BackupFolder: string): Boolean;
var
  MainFileName: string;
begin
  BackupFolder := PathWithSlash(BackupFolder);
  MainFileName := ExtractFileName(FileName);
  ForceDirectories(BackupFolder);
  Result := CopyFile(PChar(FileName), PChar(BackupFolder + MainFileName), False);
end;

//-----------------------------------------------------------------------------
// ����: �Զ������ļ�������ֹ�ļ����ظ�
// ����:
//   FullName - �ļ���ȫ·����
// ʾ����
//   NewName := AutoRenameFileName('C:\Downloads\test.dat');
//   ��� "C:\Downloads\" ���Ѿ�����test.dat���������� "C:\Downloads\test(1).dat".
//-----------------------------------------------------------------------------
function AutoRenameFileName(const FullName: string): string;
const
  SLeftSym = '(';
  SRightSym = ')';

  // ��S='test(1)'���򷵻�'(1)'�� ��S='test(a)'���򷵻�''��
  function GetNumberSection(const S: string): string;
  var
    I: Integer;
  begin
    Result := '';
    if Length(S) < 3 then Exit;
    if S[Length(S)] = SRightSym then
    begin
      for I := Length(S) - 2 downto 1 do
        if S[I] = SLeftSym then
        begin
          Result := Copy(S, I, MaxInt);
          Break;
        end;
    end;
    if Length(Result) > 0 then
    begin
      if not IsInt(Copy(Result, 2, Length(Result)-2)) then
        Result := '';
    end;
  end;

var
  Number: Integer;
  Name, Ext, NumSec: string;
begin
  Ext := ExtractFileExt(FullName);
  Result := FullName;
  while FileExists(Result) do
  begin
    Name := Copy(Result, 1, Length(Result) - Length(Ext));
    NumSec := GetNumberSection(Name);
    if Length(NumSec) = 0 then
    begin
      Result := Name + SLeftSym + '1' + SRightSym + Ext;
    end else
    begin
      Number := StrToInt(Copy(NumSec, 2, Length(NumSec)-2));
      Inc(Number);
      Result := Copy(Name, 1, Length(Name) - Length(NumSec)) +
        SLeftSym + IntToStr(Number) + SRightSym + Ext;
    end;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ȡ��һ����ʱ�ļ���
// ����:
//   Path      - ��ʱ�ļ�����·��
//   PrefixStr - �ļ���ǰ׺��ǰ�����ַ���Ч
//-----------------------------------------------------------------------------
function GetTempFileAtPath(const Path: string; const PrefixStr: string): string;
var
  I: Integer;
begin
  I := 1;
  while True do
  begin
    Result := PathWithSlash(Path) + Copy(PrefixStr, 1, 3) + IntToStr(I) + '.tmp';
    if FileExists(Result) then
      Inc(I)
    else
      Break;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ж��ļ��Ƿ����ֻ������
//-----------------------------------------------------------------------------
function IsFileReadOnly(const FileName: string): Boolean;
begin
  Result := (GetFileAttributes(PChar(FileName)) and FILE_ATTRIBUTE_READONLY) <> 0;
end;

//-----------------------------------------------------------------------------
// ����: ɾ���ļ�������վ
//-----------------------------------------------------------------------------
function DeleteFileToRecycle(const FileName: string): Boolean;
var
  OpStruct: TSHFileOpStruct;
begin
  FillChar(OpStruct, SizeOf(OpStruct), 0);
  with OpStruct do
  begin
    Wnd := 0;
    wFunc := FO_DELETE;
    pFrom := PChar(FileName);
    fFlags := FOF_ALLOWUNDO or FOF_NOCONFIRMATION or FOF_SILENT;
  end;
  Result := SHFileOperation(OpStruct) = 0;
end;

//-----------------------------------------------------------------------------
// ����: ɾ���ջ�ǿ�Ŀ¼
//-----------------------------------------------------------------------------
function DeleteDirectory(const Dir: string): Boolean;
var
  FileOp: TSHFileOpStruct;
begin
  FillChar(FileOp, SizeOf(FileOp), 0);
  with FileOp do
  begin
    Wnd := 0;
    wFunc := FO_DELETE;
    pFrom := PChar(Dir + #0);
    pTo := #0#0;
    fFlags := FOF_NOCONFIRMATION + FOF_SILENT;
  end;
  Result := (SHFileOperation(FileOp) = 0);
end;

//-----------------------------------------------------------------------------
// ����: ����������
// ����:
//   AutoRun     - �Ƿ�������
//   CurrentUser - �Ƿ�ֻ�Ե�ǰ�û���Ч
//   AppTitle    - Ӧ�ó���ı��⣬�� "MSN"
//   AppPara     - �������������в������� "/min"
//-----------------------------------------------------------------------------
function SetAutoRunOnStartup(AutoRun, CurrentUser: Boolean;
  AppTitle, AppPara: string): Boolean;
var
  R: TRegistry;
  Key, Value: string;
begin
  Result := True;
  try
    R := TRegistry.Create;
    try
      if CurrentUser then
        R.RootKey := HKEY_CURRENT_USER
      else
        R.RootKey := HKEY_LOCAL_MACHINE;
      Key := '\Software\Microsoft\Windows\CurrentVersion\Run\';

      if AppTitle = '' then AppTitle := Application.Title;
      Value := Application.ExeName;
      if AppPara <> '' then Value := Value + ' ' + AppPara;

      if R.OpenKey(Key, True) then
      begin
        if AutoRun then
          R.WriteString(AppTitle, Value)
        else
          R.DeleteValue(AppTitle);
      end;
    finally
      R.Free;
    end;
  except
    Result := False;
  end;
end;

//-----------------------------------------------------------------------------
// ����: �ļ�����
// ����:
//   FileExt      - �ļ���չ��
//   FileKey      - ���ļ����͵�Ӣ�ķ���
//   SoftName     - ���������� (������ʾ����Դ���������Ҽ��˵���)
//   FileDesc     - �ļ����͵�����
//   IconIndex    - ͼ�����(0-based)
//   Flush        - �Ƿ�ˢ��Windows����
// ʾ��:
//   AssociateFile('.edf', 'EDiaryFile', 'EDiary', '�����ռǱ��ļ�');
//-----------------------------------------------------------------------------
function AssociateFile(const FileExt, FileKey, SoftName, FileDesc: string;
  IconIndex: Integer; Flush: Boolean): Boolean;
var
  R: TRegistry;
begin
  Result := True;
  try  // Win2000�������û�ִ�д˲������ᱨ��
    R := TRegistry.Create;
    try
      R.RootKey := HKEY_CLASSES_ROOT;
      R.OpenKey('\' + FileExt, True);
      R.WriteString('', FileKey);
      R.OpenKey('\' + FileKey, True);
      R.WriteString('', FileDesc);
      R.OpenKey('\' + FileKey + '\Shell\Open\Command', True);
      R.WriteString('', Application.ExeName + ' "%1"');
      R.OpenKey('\' + FileKey + '\Shell\Open with ' + SoftName + '\Command', True);
      R.WriteString('', Application.ExeName + ' "%1"');
      R.OpenKey('\' + FileKey + '\DefaultIcon', True);
      R.WriteString('', Application.ExeName + ',' + IntToStr(IconIndex));
    finally
      R.Free;
    end;
    if Flush then SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nil, nil);
  except
    Result := False;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ��ע����м��³���·��
//-----------------------------------------------------------------------------
function SaveAppPath(const CompanyName, SoftName, Version: string): Boolean;
const
  SPathKey = 'Path'; 
var
  R: TRegistry;
  Key: string;
begin
  Result := True;
  try
    R := TRegistry.Create;
    try
      R.RootKey := HKEY_CURRENT_USER;
      Key := '\Software\' + CompanyName + '\' + SoftName + '\' + Version + '\';
      if R.OpenKey(Key, True) then
        R.WriteString(SPathKey, GetModulePath);
    finally
      R.Free;
    end;
  except
    Result := False;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ��ע����ж�ȡ����·��
//-----------------------------------------------------------------------------
function ReadAppPath(const CompanyName, SoftName, Version: string; var Path: string): Boolean;
const
  SPathKey = 'Path'; 
var
  R: TRegistry;
  Key: string;
begin
  try
    R := TRegistry.Create;
    try
      R.RootKey := HKEY_CURRENT_USER;
      Key := '\Software\' + CompanyName + '\' + SoftName + '\' + Version + '\';
      Result := R.OpenKey(Key, False);
      if Result then
        Path := R.ReadString(SPathKey);
    finally
      R.Free;
    end;
  except
    Result := False;
  end;
end;

//-----------------------------------------------------------------------------
// ����: FileTime -> LocalSystemTime
//-----------------------------------------------------------------------------
function FileTimeToLocalSystemTime(FTime: TFileTime): TSystemTime;
var
  STime: TSystemTime;
begin
  FileTimeToLocalFileTime(FTime, FTime);
  FileTimeToSystemTime(FTime, STime);
  Result := STime;
end;

//-----------------------------------------------------------------------------
// ����: LocalSystemTime -> FileTime
//-----------------------------------------------------------------------------
function LocalSystemTimeToFileTime(STime: TSystemTime): TFileTime;
var
  FTime: TFileTime;
begin
  SystemTimeToFileTime(STime, FTime);
  LocalFileTimeToFileTime(FTime, FTime);
  Result := FTime;
end;

//-----------------------------------------------------------------------------
// ����: ���� TDateTime �е����ڲ���
//-----------------------------------------------------------------------------
function GetDatePart(DateTime: TDateTime): TDate;
begin
  Result := Trunc(DateTime);
end;

//-----------------------------------------------------------------------------
// ����: ���� TDateTime �е�ʱ�䲿��
//-----------------------------------------------------------------------------
function GetTimePart(DateTime: TDateTime): TTime;
begin
  Result := DateTime - Trunc(DateTime);
end;

//-----------------------------------------------------------------------------
// ����: ��ʼ�ȴ�
//-----------------------------------------------------------------------------
procedure BeginWait;
begin
  Screen.Cursor := crHourGlass;
end;

//-----------------------------------------------------------------------------
// ����: ֹͣ�ȴ�
//-----------------------------------------------------------------------------
procedure EndWait;
begin
  Screen.Cursor := crDefault;
end;

//-----------------------------------------------------------------------------
// ����: �൱��C�����е� exp ? v1 : v2
//-----------------------------------------------------------------------------
function Iif(Value: Boolean; Value1, Value2: Variant): Variant;
begin
  if Value then Result := Value1
  else Result := Value2;
end;

//-----------------------------------------------------------------------------
// ����: ȡ V1, V2 �е���Сֵ
//-----------------------------------------------------------------------------
function Min(V1, V2: Integer): Integer;
begin
  if V1 > V2 then Result := V2
  else Result := V1;
end;

//-----------------------------------------------------------------------------
// ����: ȡ V1, V2 �е����ֵ
//-----------------------------------------------------------------------------
function Max(V1, V2: Integer): Integer;
begin
  if V1 > V2 then Result := V1
  else Result := V2;
end;

//-----------------------------------------------------------------------------
// ����: ���� Value��ʹ (Value >= Min) and (Value <= Max)
//-----------------------------------------------------------------------------
function TrimValue(Value, Min, Max: Integer): Integer;
begin
  if Value < Min then Value := Min;
  if Value > Max then Value := Max;
  Result := Value;
end;

//-----------------------------------------------------------------------------
// ����: ���� V1, V2
//-----------------------------------------------------------------------------
procedure Swap(var V1, V2: Integer);
var
  Temp: Integer;
begin
  Temp := V1;
  V1 := V2;
  V2 := Temp;
end;

//-----------------------------------------------------------------------------
// ����: ȡ������ Ticks ֮��
//-----------------------------------------------------------------------------
function GetTickDiff(const OldTickCount, NewTickCount: Cardinal): Cardinal;
begin
  if NewTickCount >= OldTickCount then
  begin
    Result := NewTickCount - OldTickCount;
  end else
  begin
    Result := High(Cardinal) - OldTickCount + NewTickCount;
  end;
end;

//-----------------------------------------------------------------------------
// ����: ���ƾ�������Ҫ������Ļ��Χ
// ����:
//   Rect       - �������ľ�������
//   AllVisible - ���������ǲ���Ҫȫ���ɼ�
// ����:
//   ������ľ������� (�����߲���)
//-----------------------------------------------------------------------------
function RestrictRectInScr(Rect: TRect; AllVisible: Boolean): TRect;
const
  Space = 100;
var
  ScrRect: TRect;
  W, H: Integer;
begin
  ScrRect := Screen.WorkAreaRect;
  W := Rect.Right - Rect.Left;
  H := Rect.Bottom - Rect.Top;

  if AllVisible then
  begin
    if W > (ScrRect.Right - ScrRect.Left) then W := (ScrRect.Right - ScrRect.Left);
    if H > (ScrRect.Bottom - ScrRect.Top) then H := (ScrRect.Bottom - ScrRect.Top);
    if Rect.Right > ScrRect.Right then
      Rect.Left := ScrRect.Right - W;
    if Rect.Bottom > ScrRect.Bottom then Rect.Top := ScrRect.Bottom - H;
    if Rect.Left < ScrRect.Left then Rect.Left := ScrRect.Left;
    if Rect.Top < ScrRect.Top then Rect.Top := ScrRect.Top;
    Rect.Right := Rect.Left + W;
    Rect.Bottom := Rect.Top + H;
  end else
  begin
    if Rect.Left >= ScrRect.Right - Space then
      Rect.Left := ScrRect.Right - Space;
    if Rect.Top >= ScrRect.Bottom - Space then
      Rect.Top := ScrRect.Bottom - Space;
    if Rect.Right <= ScrRect.Left + Space then
      Rect.Left := ScrRect.Left - (Rect.Right - Rect.Left) + Space;
    if Rect.Top < ScrRect.Top then
      Rect.Top := ScrRect.Top;
    Rect.Right := Rect.Left + W;
    Rect.Bottom := Rect.Top + H;
  end;
  Result := Rect;
end;

//-----------------------------------------------------------------------------
// ����: ȡ������ DLL��OCX��EXE ���ڵ�·��
// ע��: �� Application.ExeName �޷�ȡ�� ActiveX ��·����
//-----------------------------------------------------------------------------
function GetModulePath: string;
var
  S: array[0..MAX_PATH] of Char;
begin
  GetModuleFileName(HInstance, S, MAX_PATH);
  Result := PathWithSlash(ExtractFilePath(S));
end;

//-----------------------------------------------------------------------------
// ����: ȡ������ DLL��OCX��EXE ����·������Ŀ¼·��
//-----------------------------------------------------------------------------
function GetModuleSubPath(const SubFolder: string = ''): string;
begin
  Result := GetModulePath + SubFolder;
  Result := PathWithSlash(Result);
end;

//-----------------------------------------------------------------------------
// ����: ȡ������ EXE ����·��
//-----------------------------------------------------------------------------
function GetAppPath: string;
begin
  Result := ExtractFilePath(Application.ExeName);
end;

//-----------------------------------------------------------------------------
// ����: ȡ������ EXE ����·������Ŀ¼·��
//-----------------------------------------------------------------------------
function GetAppSubPath(const SubFolder: string): string;
begin
  Result := GetAppPath + SubFolder;
  Result := PathWithSlash(Result);
end;

//-----------------------------------------------------------------------------
// ����: ���ؾ��� R �Ŀ���
//-----------------------------------------------------------------------------
function GetRectWidth(const R: TRect): Integer;
begin
  Result := R.Right - R.Left;
end;

//-----------------------------------------------------------------------------
// ����: ���ؾ��� R �ĸ߶�
//-----------------------------------------------------------------------------
function GetRectHeight(const R: TRect): Integer;
begin
  Result := R.Bottom - R.Top;
end;

//-----------------------------------------------------------------------------
// ����: �����б߿������
//-----------------------------------------------------------------------------
procedure DrawStrokedText(Canvas: TCanvas; X, Y: Integer; const Text: string;
  FontColor, StrokedColor, SmoothColor: TColor);
var
  SaveStyle: TBrushStyle;
  SaveFontColor: TColor;
begin
  SaveStyle := Canvas.Brush.Style;
  SaveFontColor := Canvas.Font.Color;
  try
    Canvas.Brush.Style := bsClear;

    Canvas.Font.Color := SmoothColor;
    Canvas.TextOut(X - 1, Y - 1, Text);
    Canvas.TextOut(X - 1, Y + 1, Text);
    Canvas.TextOut(X + 1, Y - 1, Text);
    Canvas.TextOut(X + 1, Y + 1, Text);

    Canvas.Font.Color := StrokedColor;
    Canvas.TextOut(X, Y - 1, Text);
    Canvas.TextOut(X, Y + 1, Text);
    Canvas.TextOut(X + 1, Y, Text);
    Canvas.TextOut(X - 1, Y, Text);

    Canvas.Font.Color := FontColor;
    Canvas.TextOut(X, Y, Text);
  finally
    Canvas.Font.Color := SaveFontColor;
    Canvas.Brush.Style := SaveStyle;
  end;
end;

end.
