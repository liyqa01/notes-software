inherited ShortcutsForm: TShortcutsForm
  BorderIcons = [biSystemMenu, biMaximize]
  Caption = #24555#25463#38190#21015#34920
  ClientHeight = 346
  ClientWidth = 352
  Position = poOwnerFormCenter
  OnCreate = FormCreate
  OnResize = FormResize
  OnShow = FormShow
  ExplicitWidth = 360
  ExplicitHeight = 373
  PixelsPerInch = 96
  TextHeight = 12
  object Memo: TMemo
    AlignWithMargins = True
    Left = 2
    Top = 3
    Width = 348
    Height = 341
    Margins.Left = 2
    Margins.Right = 2
    Margins.Bottom = 2
    Align = alClient
    BevelKind = bkTile
    BorderStyle = bsNone
    Color = clBtnFace
    ReadOnly = True
    ScrollBars = ssVertical
    TabOrder = 0
    ExplicitLeft = 0
    ExplicitTop = 0
    ExplicitWidth = 345
    ExplicitHeight = 340
  end
  object ActionList: TActionList
    Left = 24
    Top = 24
    object CloseAction: TAction
      Caption = 'CloseAction'
      ShortCut = 27
      OnExecute = CloseActionExecute
    end
  end
end
